<div style="display:none;"><script type="text/javascript">
(function(w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter<?php echo osc_yandex_metrica_id(); ?> = new Ya.Metrika({id:<?php echo osc_yandex_metrica_id(); ?>, enableAll: true});
        }
        catch(e) { }
    });
})(window, "yandex_metrika_callbacks");
</script></div>
<script src="//mc.yandex.ru/metrika/watch.js" type="text/javascript" defer="defer"></script>
<noscript><div><img src="//mc.yandex.ru/watch/<?php echo osc_yandex_metrica_id(); ?>" style="position:absolute; left:-9999px;" alt="" /></div></noscript>