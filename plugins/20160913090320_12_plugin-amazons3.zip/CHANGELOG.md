Amazon S3 plugin
================

##version 2.0.0 - 13/09/2016

* Updated to AWS official library and signature 4

##version 1.0.3 - 12/06/2013

* First time having a CHANGELOG
* Updated to work fine with Osclass 3.2