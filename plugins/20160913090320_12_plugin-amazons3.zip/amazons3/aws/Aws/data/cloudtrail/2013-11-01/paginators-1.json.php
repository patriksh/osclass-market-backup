<?php
// This file was auto-generated from sdk-root/src/data/cloudtrail/2013-11-01/paginators-1.json
return [ 'pagination' => [ 'DescribeTrails' => [ 'result_key' => 'trailList', ], ],];
