Trezor login
============

##version 1.2.2 - 17/08/2015

* Compatible with firmware 1.3.4

##version 1.2.1 - 05/05/2015

* Minor fixes

##version 1.2.0 - 01/05/2015

* Support for admin login too
* Fixed minor issues

##version 1.1.0 - 30/04/2015

* Now it asks for account password in order to link your TREZOR
* Unlink asks for simple confirmatin
* Affiliate code could be configured in the admin
* Fixed some typos

##version 1.0.0 - 24/04/2015

* First version
