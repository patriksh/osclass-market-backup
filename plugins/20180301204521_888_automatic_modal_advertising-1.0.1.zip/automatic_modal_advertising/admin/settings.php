<?php if (!defined('OC_ADMIN') || OC_ADMIN!==true) exit('Access is not allowed.');?>
<form action="<?php echo osc_admin_render_plugin_url(osc_plugin_folder(__FILE__) . '/admin/settings.php'); ?>" method="post">
    <input type="hidden" name="automatic_modal_advertising_specific_zone" value="settings" />
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"></div>
                <h2 class="render-title"><?php _e('Choose your configuration to subscribe form', 'automatic_modal_advertising'); ?></h2>
                <div class="form-row">
                    <div class="form-label"><?php _e('Alert form', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <div class="indOp"><input class="greencheck" type="checkbox" name="ama-alert-form-box" <?php if(ama_alert_form_box() == '1'){ echo 'checked="yes"';}?> value="1"><?php _e('Enable to display alert form on window modal', 'automatic_modal_advertising');?></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('User logged', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <div class="indOp"><input class="green" type="checkbox" name="ama-user-logged-alert" <?php if(ama_user_logged_alert() === '1'){ echo 'checked="yes"';}?> value="1"><?php _e('If checked users logged do not see window modal to subscrive.', 'automatic_modal_advertising');?></div>
                    </div>
                </div>
                </br>
                <div class="form-label"><?php _e('Search page', 'automatic_modal_advertising'); ?></div>
                <div class="form-controls">
                    <select name="ama-ipage-alert-form">
                        <option value="2" <?php if(ama_ipage_alert_form() == '2'){ echo 'selected="selected"';}?>><?php _e('Page 2','automatic_modal_advertising'); ?></option>
                        <option value="3" <?php if(ama_ipage_alert_form() == '3'){ echo 'selected="selected"';}?>><?php _e('Page 3','automatic_modal_advertising'); ?></option>
                        <option value="4" <?php if(ama_ipage_alert_form() == '4'){ echo 'selected="selected"';}?>><?php _e('Page 4','automatic_modal_advertising'); ?></option>
                        <option value="5" <?php if(ama_ipage_alert_form() == '5'){ echo 'selected="selected"';}?>><?php _e('Page 5','automatic_modal_advertising'); ?></option>
                    </select>
                    <div class="help-box"><?php _e('Take in account, if you not have a pagination with more of 2 pages, is recommended only you use page 2 selected.', 'automatic_modal_advertising'); ?>
                    </div>
                </div>
                </br>
                <div class="form-row">
                    <div class="form-label"><?php _e('Waiting display', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <input type="text" class="xlarge" name="ama-clickit-alert-form"  id="DaysTop" placeholder="<?php echo osc_esc_html(__('Set a value in seconds', 'automatic_modal_advertising'));?>" <?php if(osc_get_preference('ama-clickit-alert-form', 'automatic_modal_advertising') != 0) { ?> value="<?php echo osc_esc_html(osc_get_preference('ama-clickit-alert-form', 'automatic_modal_advertising'));?>"<?php } ?>>
                        <div class="help-box"><?php _e('Set a time in seconds to appears the window modal after loading page.', 'automatic_modal_advertising'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-label"></div>
                <h2 class="render-title"><?php _e('Choose a configuration to banner/embedded code', 'automatic_modal_advertising'); ?></h2>
                <div class="form-row">
                    <div class="form-label"><?php _e('User logged', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <div class="indOp"><input class="green" id="ama-user_logged" type="checkbox" name="ama-user-logged" <?php if(ama_user_logged() === '1'){ echo 'checked="yes"';}?> value="1">
                            <?php _e('If checked users logged do not see window modal to banner / embedded.', 'automatic_modal_advertising');?><br/>
                            <?php _e('Take note, if you select a user dashboard page firstly, leave in blank "users logged" checkbox.', 'automatic_modal_advertising');?>
                        </div>
                    </div>
                </div>
                <div class="form-label"><?php _e('Choose a page', 'automatic_modal_advertising'); ?></div>
                <div class="form-controls">
                    <select name="ama-chosen-page">
                        <option value="" <?php if(ama_chosen_page() == ''){ echo 'selected="selected"';}?>><?php _e('Select a page...','automatic_modal_advertising'); ?></option>
                        <option value="home" <?php if(ama_chosen_page() == 'home'){ echo 'selected="selected"';}?>><?php _e('Home page','automatic_modal_advertising'); ?></option>
                        <option value="profile" <?php if(ama_chosen_page() == 'profile'){ echo 'selected="selected"';}?>><?php _e('Profile page','automatic_modal_advertising'); ?></option>
                        <option value="publish" <?php if(ama_chosen_page() == 'publish'){ echo 'selected="selected"';}?>><?php _e('Publish page','automatic_modal_advertising'); ?></option>
                        <option value="edit" <?php if(ama_chosen_page() == 'edit'){ echo 'selected="selected"';}?>><?php _e('Edit page','automatic_modal_advertising'); ?></option>
                        <option value="item" <?php if(ama_chosen_page() == 'item'){ echo 'selected="selected"';}?>><?php _e('Ad page','automatic_modal_advertising'); ?></option>
                        <option value="search" <?php if(ama_chosen_page() == 'search'){ echo 'selected="selected"';}?>><?php _e('Search page','automatic_modal_advertising'); ?></option>
                        <option value="contact" <?php if(ama_chosen_page() == 'contact'){ echo 'selected="selected"';}?>><?php _e('Contact page','automatic_modal_advertising'); ?></option>
                        <option value="404" <?php if(ama_chosen_page() == '404'){ echo 'selected="selected"';}?>><?php _e('Error page','automatic_modal_advertising'); ?></option>
                        <option value="dashboard-user" <?php if(ama_user_logged() == 1){?> disabled="disabled" <?php }?>class="dashboard-user-page" <?php if(ama_chosen_page() == 'dashboard-user'){ echo 'selected="selected"';}?>><?php _e('Dashboard user page','automatic_modal_advertising'); ?></option>
                        <option value="user-items" <?php if(ama_user_logged() == 1){?> disabled="disabled" <?php }?>class="dashboard-user-page" <?php if(ama_chosen_page() == 'user-items'){ echo 'selected="selected"';}?>><?php _e('User items page','automatic_modal_advertising'); ?></option>
                        <option value="alerts" <?php if(ama_user_logged() == 1){?> disabled="disabled" <?php }?>class="dashboard-user-page" <?php if(ama_chosen_page() == 'alerts'){ echo 'selected="selected"';}?>><?php _e('List alerts page','automatic_modal_advertising'); ?></option>
                    </select>
                    <div class="help-box">
                        <?php _e('Choose the page destination, if you check one of the checkboxes below.', 'automatic_modal_advertising'); ?></br>
                        <?php _e('Be carefull, if you choose search page will make effect in all pages of search, except on the page chosen for the alerts form.', 'automatic_modal_advertising'); ?><br/>
                        <?php _e('If you do it, is better check the checkbox to User logged to enabled. At least, give the opportunity to users escape window, when logged.', 'automatic_modal_advertising'); ?>
                    </div>
                </div>
                </br>
                <div class="form-row">
                    <div class="form-label"><?php _e('Banner image', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <div class="indOp"><input class="greenchecked" type="checkbox" name="ama-banner-image-box" <?php if(ama_banner_image_box() == '1'){ echo 'checked="yes"';}?> value="1"><?php _e('Enable to display banner image on window modal', 'automatic_modal_advertising');?></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Banner URL', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <textarea style="height: 40px; width: 500px;" name="ama-banner-img"><?php echo osc_esc_html( osc_get_preference('ama-banner-img', 'automatic_modal_advertising') ); ?></textarea>
                        <br/><br/>
                        <div class="help-box"><?php _e('Insert only direct URL to banner appears. Do not include HTML code or will not work', 'automatic_modal_advertising'); ?></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Website', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <textarea style="height: 40px; width: 500px;" name="ama-href-banner-img"><?php echo osc_esc_html( osc_get_preference('ama-href-banner-img', 'automatic_modal_advertising') ); ?></textarea>
                        <div class="help-box"><?php _e('Image clicable need a link.', 'automatic_modal_advertising'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-label"><?php _e('Open window', 'automatic_modal_advertising'); ?></div>
                <div class="form-controls">
                    <select name="ama-image-banner-blank">
                        <option value="yes" <?php if(ama_image_banner_blank() == 'yes'){ echo 'selected="selected"';}?>><?php _e('In a new separator','automatic_modal_advertising'); ?></option>
                        <option value="no" <?php if(ama_image_banner_blank() == 'no'){ echo 'selected="selected"';}?>><?php _e('On same separator','automatic_modal_advertising'); ?></option>
                    </select>
                    <div class="help-box"><?php _e('Choose if href of image will open on a new _blank separator or on same.', 'automatic_modal_advertising'); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Waiting display', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <input type="text" class="xlarge" name="ama-clickit-banner-image" placeholder="<?php echo osc_esc_html(__('Set a value in seconds', 'automatic_modal_advertising'));?>" <?php if(osc_get_preference('ama-clickit-banner-image', 'automatic_modal_advertising') != 0) { ?> value="<?php echo osc_esc_html(osc_get_preference('ama-clickit-banner-image', 'automatic_modal_advertising'));?>"<?php } ?>>
                        <div class="help-box"><?php _e('Set a time in seconds to appears the window modal after loading page.', 'automatic_modal_advertising'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Code Embedded', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <div class="indOp"><input class="greenchecked2" type="checkbox" name="ama-embedded-box" <?php if(ama_embedded_box() == '1'){ echo 'checked="yes"';}?> value="1"><?php _e('Enable to display code embedded on window modal', 'automatic_modal_advertising');?></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Own code', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <textarea style="height: 40px; width: 500px;" name="ama-embedded-code"><?php echo osc_esc_html( osc_get_preference('ama-embedded-code', 'automatic_modal_advertising') ); ?></textarea>
                        <br/><br/>
                        <div class="help-box"><?php _e('Insert your own direct code or embedded', 'automatic_modal_advertising'); ?></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-label"><?php _e('Waiting display', 'automatic_modal_advertising'); ?></div>
                    <div class="form-controls">
                        <input type="text" class="xlarge" name="ama-clickit-embedded" placeholder="<?php echo osc_esc_html(__('Set a value in seconds', 'automatic_modal_advertising'));?>" <?php if(osc_get_preference('ama-clickit-embedded', 'automatic_modal_advertising') != 0) { ?> value="<?php echo osc_esc_html(osc_get_preference('ama-clickit-embedded', 'automatic_modal_advertising'));?>"<?php } ?>>
                        <div class="help-box"><?php _e('Set a time in seconds to appears the window modal after loading page.', 'automatic_modal_advertising'); ?>
                        </div>
                    </div>
                </div>
                <div class="form-controls">
                    <select name="ama-custom-css">
                        <option value="no" <?php if(ama_option_custom_css() == 'no'){ echo 'selected="selected"';}?>><?php _e('No','automatic_modal_advertising'); ?></option>
                        <option value="yes" <?php if(ama_option_custom_css() == 'yes'){ echo 'selected="selected"';}?>><?php _e('Yes','automatic_modal_advertising'); ?></option>
                    </select>
                    <div class="help-box"><?php _e('Enable if you need a custom css. You need open custom.css on css folder to edit your own css', 'automatic_modal_advertising'); ?>
                    </div>
                </div>
                <br />
                <div class="form-actions">
                    <input type="submit" value="<?php _e('Save changes', 'automatic_modal_advertising'); ?>" class="btn btn-submit">
                </div>

            </div>
        </div>
    </fieldset>
</form>
<script type="text/javascript">
    $('.greenchecked').change(function(){
        if($('.greenchecked').is(':checked')){
            $('.greenchecked2').attr('disabled',true);
        }
        else{
            $('.greenchecked2').attr('disabled',false);
        }
    });
    $('.greenchecked2').change(function(){
        if($('.greenchecked2').is(':checked')){
            $('.greenchecked').attr('disabled',true);
        }
        else{
            $('.greenchecked').attr('disabled',false);
        }
    });
    $('#ama-user_logged').change(function(){
        if($('#ama-user_logged').is(':checked')){
            $('.dashboard-user-page').attr('disabled',true);
        }
        else{
            $('.dashboard-user-page').attr('disabled',false);
        }
    });
    <?php if(ama_user_logged() == 1 && ama_chosen_page() == ''){?>
    alert('<?php echo osc_esc_js(__('Warning: user dashboard page was not saved. Leave in blank users logged and choose your preferable user dashboard page again.', 'automatic_modal_advertising'));?>');
    <?php }?>
</script>