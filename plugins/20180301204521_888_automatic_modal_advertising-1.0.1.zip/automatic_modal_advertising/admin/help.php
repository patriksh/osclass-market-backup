<?php if (!defined('OC_ADMIN') || OC_ADMIN!==true) exit('Access is not allowed.');?>
<div id="settings_form" style="border: 1px solid #ccc; background: #eee; ">
    <div style="padding: 0 20px 20px;">
        <div>
            <fieldset>
                <legend>
                    <h1><?php _e('Automatic modal advertising', 'automatic_modal_advertising') ; ?></h1>
                </legend>
                <pre>
                    <p><?php _e('This plugin is very easy to use, but feel free to contact us.', 'automatic_modal_advertising') ; ?></p>
                    <p><?php _e('We recommend you use links to your image banner to users contact you about your requirements.', 'automatic_modal_advertising') ; ?></p>
                    <p><?php _e('Example link: http(s):your_site_name/contact/', 'automatic_modal_advertising') ; ?></p>
                    <p><?php _e('On embedded code mode, is not recommended you use javascript (he can be working for you, but javascript need be outside of HTML tags, to following the right rules of HTML markup). For you add your own javascript is better on footer.php file of your theme. Will working better avoiding possible issues.', 'automatic_modal_advertising') ; ?></p>
                </pre>
                <br>
                <br>
                <p>
                    <?php printf(__('You have OSCLASS %s version', 'automatic_modal_advertising'), OSCLASS_VERSION); ?>.
                </p>
            </fieldset>
        </div>
    </div>
</div>