<?php
$iPage = getPreference('ama-ipage-alert-form','automatic_modal_advertising');
$completeSearchUrl = osc_search_show_all_url();
$page2 = substr( $completeSearchUrl, -8 );
$perm_all_page2 = substr( $completeSearchUrl, -7 );
$perm_cat_page2 = substr( $completeSearchUrl, -1 );
if($page2 == '&iPage=$iPage' or $perm_all_page2 == 'iPage,$iPage' or $perm_cat_page2 == $iPage){
    ?>
    <a id="linkModalAlertForm" href="#openModalAlertForm"></a>
    <div id="openModalAlertForm" class="modalDialog" style="display:none">
        <div>
            <a href="#close" title="Close" class="close">X</a>
            <p><strong>&#9993; <?php _e('Receive new publications about your search by email.', 'automatic_modal_advertising');?></strong></p>
            <p>&#10004; <?php _e('You can cancel email alerts at anytime.', 'automatic_modal_advertising');?></p>
            <p><?php osc_alert_form() ; ?></p>
            <p><b><?php _e("Take note this important info", "automatic_modal_advertising");?> : </b></p>
            <p>&#10004; <?php _e("Check your spam box and set our email as: it is not spam.", "automatic_modal_advertising");?></p>
            <p>&#10004; <?php _e('Your email will not be disclosed to third parties. Is 100% safe!', 'automatic_modal_advertising');?></p>
            <?php if(ama_user_logged_alert() == 1 && !osc_is_web_user_logged_in()){?>
                <p></p>
                <div class="ama-login"><?php _e('Sign in to not see this window again', 'automatic_modal_advertising');?></div>
            <?php }?>
        </div>
    </div>
    <script type="text/javascript">
        document.getElementById("openModalAlertForm").style.display = "none";
        <?php if(osc_get_preference('ama-clickit-alert-form', 'automatic_modal_advertising') == ''){?>
        window.setTimeout('clickit()',1000);
        <?php }else{?>
        window.setTimeout('clickit()',<?php echo osc_esc_js(osc_get_preference('ama-clickit-alert-form', 'automatic_modal_advertising'));?>000);
        <?php } ?>
        function clickit(){
            document.getElementById("openModalAlertForm").style.display = "block";
            location.href = document.getElementById("linkModalAlertForm");
        }
    </script>
    <style type="text/css">
        .modalDialog {
            position: fixed;
            font-family: Arial, Helvetica, sans-serif;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0,0,0,0.8);
            z-index: 99999;
            opacity:0;
            -webkit-transition: opacity 400ms ease-in;
            -moz-transition: opacity 400ms ease-in;
            transition: opacity 400ms ease-in;
            pointer-events: none;
        }
        .modalDialog:target {
            opacity:1;
            pointer-events: auto;
        }
        .modalDialog > div {
            position: relative;
            background: #fff;
        }
        .close {
            background: #606061;
            color: #FFFFFF;
            line-height: 25px;
            position: absolute;
            right: -12px;
            text-align: center;
            top: -10px;
            width: 24px;
            text-decoration: none;
            font-weight: bold;
            -webkit-border-radius: 12px;
            -moz-border-radius: 12px;
            border-radius: 12px;
            -moz-box-shadow: 1px 1px 3px #000;
            -webkit-box-shadow: 1px 1px 3px #000;
            box-shadow: 1px 1px 3px #000;
        }
        .close:hover { background: #00d9ff; }
        .modalDialog p{
            font-size: 14px;
            padding : 10px 0 0 0;
            line-height : 20px;
        }
        .modalDialog p b{
            color : rgba(255, 67, 67, 0.85);
        }

        .ama-login{
            background:#000;
            color:#fff;
            padding:5px 0 5px 0;
            text-align:center;
        }
        .modalDialog > div {
            margin: 12% auto;
            max-width: 400px;
            padding: 5px 20px 13px 20px;
            border-radius: 10px;
        }
    </style>
<?php }?>