<?php
$embedded_iPage = getPreference('ama-ipage-alert-form','automatic_modal_advertising');
$embedded_completeSearchUrl = osc_search_show_all_url();
$embedded_page2 = substr( $embedded_completeSearchUrl, -8 );
$embedded_perm_all_page2 = substr( $embedded_completeSearchUrl, -7 );
$embedded_perm_cat_page2 = substr( $embedded_completeSearchUrl, -1 );
if($embedded_page2 == '&iPage=$banner_iPage' or $embedded_perm_all_page2 == 'iPage,$banner_iPage' or $embedded_perm_cat_page2 == $embedded_iPage){
}else{
    ?>
    <a id="linkModalEmbedded" href="#openModalEmbedded"></a>
    <div id="openModalEmbedded" class="modalDialog" style="display:none">
        <div>
            <a href="#close" title="Close" class="close">X</a>
            <?php if(osc_get_preference('ama-embedded-code', 'automatic_modal_advertising')!='') {
                echo osc_get_preference('ama-embedded-code', 'automatic_modal_advertising') . PHP_EOL;
            }?>
            <?php if(ama_user_logged() == 1 && !osc_is_web_user_logged_in()){?>
                <div class="ama-login"><?php _e('Sign in to not see this window', 'automatic_modal_advertising');?></div>
            <?php }?>
        </div>
    </div>
    <script type="text/javascript">
        document.getElementById("openModalEmbedded").style.display = "none";
        <?php if(osc_get_preference('ama-clickit-embedded', 'automatic_modal_advertising') == ''){?>
        window.setTimeout('clickit()',1000);
        <?php }else{?>
        window.setTimeout('clickit()',<?php echo osc_esc_js(osc_get_preference('ama-clickit-embedded', 'automatic_modal_advertising'));?>000);
        <?php } ?>
        function clickit(){
            document.getElementById("openModalEmbedded").style.display = "block";
            location.href = document.getElementById("linkModalEmbedded");
        }
    </script>
    <style type="text/css">
        .modalDialog {
            position: fixed;
            font-family: Arial, Helvetica, sans-serif;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0,0,0,0.8);
            z-index: 99999;
            opacity:0;
            -webkit-transition: opacity 400ms ease-in;
            -moz-transition: opacity 400ms ease-in;
            transition: opacity 400ms ease-in;
            pointer-events: none;
        }
        .modalDialog:target {
            opacity:1;
            pointer-events: auto;
        }
        .modalDialog > div {
            position: relative;
            background: #fff;
        }
        .close {
            background: #606061;
            color: #FFFFFF;
            line-height: 25px;
            position: absolute;
            right: -12px;
            text-align: center;
            top: -10px;
            width: 24px;
            text-decoration: none;
            font-weight: bold;
            -webkit-border-radius: 12px;
            -moz-border-radius: 12px;
            border-radius: 12px;
            -moz-box-shadow: 1px 1px 3px #000;
            -webkit-box-shadow: 1px 1px 3px #000;
            box-shadow: 1px 1px 3px #000;
        }
        .close:hover { background: #00d9ff; }
        .modalDialog p{
            font-size: 14px;
            padding : 10px 0 0 0;
            line-height : 20px;
        }
        .modalDialog p b{
            color : rgba(255, 67, 67, 0.85);
        }

        .ama-login{
            background:#000;
            color:#fff;
            padding:5px 0 5px 0;
            text-align:center;
        }
        .modalDialog > div {
            margin: 12% auto;
            width: 50%;
        }
        .modalDialog > div a img {
            width: 100%;
        }
        @media screen and (max-width:1050px) {
            .modalDialog > div {
                margin: 8% auto;
                width: 90%;
            }
        }
        @media screen and (max-width:600px) {
            .modalDialog > div {
                margin: 33% auto;
                width: 95%;
            }
        }
    </style>
<?php }?>