<script src="https://apis.google.com/js/platform.js" async defer></script>
<h3><strong><?php echo $gpb_title; ?></strong></h3>
<div <?php if($gpb_page_type == 'profile') { ?>class="g-person"<?php } elseif($gpb_page_type == 'page') { ?>class="g-page"<?php } 
elseif($gpb_page_type == 'community') { ?>class="g-community"<?php } ?> data-width="<?php echo $gpb_width; ?>" data-href="<?php echo $gpb_page_url; ?>" data-layout="<?php echo $gpb_layout; ?>" data-theme="<?php echo $gpb_color_scheme; ?>" data-rel="publisher" data-showtagline="<?php echo $gpb_tagline; ?>" data-showcoverphoto="<?php echo $gpb_cover_photo; ?>"></div>
	