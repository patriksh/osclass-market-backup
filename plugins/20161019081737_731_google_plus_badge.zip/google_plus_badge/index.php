<?php
/*
  Plugin Name: Google Plus Badge
  Plugin URI: 
  Description: This plugin allows you to quickly and easily add the Google Plus badge to your Osclass website.
  Version: 1.0.0
  Author: Pratik Maniyar
  Author URI: 
  Short Name: google_plus_badge
  Plugin update URI: google-plus-badge_2
 */
function google_plus_badge_call_after_install() {
  osc_set_preference('gpb_page_type', '', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_title', 'Find us on Google Plus', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_page_url', '', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_width', '300', 'google_plus_badge', 'INTEGER');
  osc_set_preference('gpb_color_scheme', '', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_layout', '', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_cover_photo', 'true', 'google_plus_badge', 'STRING');
  osc_set_preference('gpb_tagline', 'true', 'google_plus_badge', 'STRING');
}

function google_plus_badge_call_after_uninstall() {
  osc_delete_preference('gpb_page_type', 'google_plus_badge');
  osc_delete_preference('gpb_title', 'google_plus_badge');
  osc_delete_preference('gpb_page_url', 'google_plus_badge');
  osc_delete_preference('gpb_width', 'google_plus_badge');
  osc_delete_preference('gpb_color_scheme', 'google_plus_badge');
  osc_delete_preference('gpb_layout', 'google_plus_badge');
  osc_delete_preference('gpb_cover_photo', 'google_plus_badge');
  osc_delete_preference('gpb_tagline', 'google_plus_badge');
}

function google_plus_badge_actions() {
  $option = Params::getParam('gpboption');
  if (Params::getParam('file') != 'google_plus_badge/admin/admin.php') {
    return '';
  }
  if ($option == 'gpbsettings') {
    osc_set_preference('gpb_page_type', Params::getParam("gpb_page_type") ? Params::getParam("gpb_page_type") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_title', Params::getParam("gpb_title") ? Params::getParam("gpb_title") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_page_url', Params::getParam("gpb_page_url") ? Params::getParam("gpb_page_url") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_width', Params::getParam("gpb_width") ? Params::getParam("gpb_width") : '0', 'google_plus_badge', 'INTEGER');
    osc_set_preference('gpb_color_scheme', Params::getParam("gpb_color_scheme") ? Params::getParam("gpb_color_scheme") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_layout', Params::getParam("gpb_layout") ? Params::getParam("gpb_layout") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_cover_photo', Params::getParam("gpb_cover_photo") ? Params::getParam("gpb_cover_photo") : '0', 'google_plus_badge', 'STRING');
    osc_set_preference('gpb_tagline', Params::getParam("gpb_tagline") ? Params::getParam("gpb_tagline") : '0', 'google_plus_badge', 'STRING');        
    osc_add_flash_ok_message(__('Google Plus Badge configuration has been updated', 'google_plus_badge'), 'admin');
    osc_redirect_to(osc_admin_render_plugin_url('google_plus_badge/admin/admin.php'));
  }
}

// HELPER
function get_gpb_page_type() {
  return(osc_get_preference('gpb_page_type', 'google_plus_badge'));
}

function get_gpb_title() {
  return(osc_get_preference('gpb_title', 'google_plus_badge'));
}

function get_gpb_page_url() {
  return(osc_get_preference('gpb_page_url', 'google_plus_badge'));
}

function get_gpb_width() {
  return(osc_get_preference('gpb_width', 'google_plus_badge'));
}

function get_gpb_color_scheme() {
  return(osc_get_preference('gpb_color_scheme', 'google_plus_badge'));
}

function get_gpb_layout() {
  return(osc_get_preference('gpb_layout', 'google_plus_badge'));
}

function get_gpb_cover_photo() {
  return(osc_get_preference('gpb_cover_photo', 'google_plus_badge'));
}

function get_gpb_tagline() {
  return(osc_get_preference('gpb_tagline', 'google_plus_badge'));
}

function google_plus_badge_admin() {
  osc_admin_render_plugin('google_plus_badge/admin/admin.php');
}
    
/**
 * Create a menu on the admin panel
 */
function google_plus_badge_admin_menu() { 
   echo '<h3><a href="#">' . __('Google Plus Badge', 'google_plus_badge') . '</a></h3>
    <ul>
        <li><a href="' . osc_admin_render_plugin_url(osc_plugin_folder(__FILE__) . 'admin/admin.php') . '">&raquo; ' . __('Configure', 'google_plus_badge') . '</a></li>
    </ul>';
}

function google_plus_badge_init_admin_menu()
{
    osc_add_admin_submenu_divider('plugins', 'Google Plus Badge', 'google_plus_badge', 'administrator');
    osc_add_admin_submenu_page('plugins', __('Configure', 'google_plus_badge'), osc_route_admin_url('google-plus-badge-admin-conf'), 'google_plus_badge_settings', 'administrator');
}

/**
 * This function is called every time the page header is being rendered
 */
function google_plus_badge() {
  if (get_gpb_page_url() != '') {
    $gpb_page_type = get_gpb_page_type();
    $gpb_title = get_gpb_title();
    $gpb_page_url = get_gpb_page_url();
    $gpb_width = get_gpb_width();
    $gpb_color_scheme = get_gpb_color_scheme();
    $gpb_layout = get_gpb_layout();
    $gpb_cover_photo = get_gpb_cover_photo();
    $gpb_tagline = get_gpb_tagline();
    require_once(osc_plugins_path() . 'google_plus_badge/code.php');
  }
}
osc_add_route('google-plus-badge-admin-conf', 'google_plus_badge', 'google_plus_badge', osc_plugin_folder(__FILE__).'admin/admin.php'); 

osc_add_hook('init_admin', 'google_plus_badge_actions');
// show menu items
if(osc_version()<310) {
    osc_add_hook('admin_menu', 'google_plus_badge_admin_menu');
} else {
    osc_add_hook('admin_menu_init', 'google_plus_badge_init_admin_menu');
}

// This is a hack to show a Uninstall link at plugins table (you could also use some other hook to show a custom option panel)
osc_add_hook(osc_plugin_path(__FILE__) . "_uninstall", 'google_plus_badge_call_after_uninstall');
osc_add_hook(osc_plugin_path(__FILE__) . "_configure", 'google_plus_badge_admin');


// This is needed in order to be able to activate the plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'google_plus_badge_call_after_install');
?>