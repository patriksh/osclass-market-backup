<?php if (!defined('OC_ADMIN') || OC_ADMIN!==true) exit('Access is not allowed.'); ?>
<style type="text/css">
	#content-page { background:#e5e5e5; }
	.form-container { width:500px; border:2px solid #ddd; background:#fff; }
	.form-container h2 { margin:0; padding:10px 15px; background:#DD4D40; color:#fff;}
	.form-container fieldset { padding:15px; }
	.control-group { margin-bottom:15px; }
	.control-label { margin-bottom:5px; display:block; }
	.form-actions { margin-top:15px; margin-bottom:0;}
	.form-horizontal .form-actions { padding-left:15px;}
	.form-container input[type=text] { padding:10px; width:95%; }
	.form-container input[type=text].swidth { width:30%; }
</style>
<?php $pluginInfo = osc_plugin_get_info('google_plus_badge/index.php');  ?>
<div class="form-container form-horizontal">
<h2 class="render-title"><?php _e('Google Plus Badge Configuration', 'google_plus_badge'); ?></h2>
<form action="<?php echo osc_admin_render_plugin_url('google_plus_badge/admin/admin.php'); ?>" method="post">
  <input type="hidden" name="gpboption" value="gpbsettings" />
  <fieldset>
    <div class="control-group">
  	<label class="control-label"><?php _e('Google Plus Badge Title', 'google_plus_badge'); ?></label>
    <div class="controls">
    	<input type="text" name="gpb_title" value="<?php echo osc_esc_html(get_gpb_title()); ?>">
    </div>
  </div>    
  <div class="control-group">
  	<label class="control-label"><?php _e('Select Page Type', 'google_plus_badge'); ?></label>
    <div class="controls">
        <select name="gpb_page_type" id="gpb_page_type">
            <option value="profile" <?php echo get_gpb_page_type()=="profile"?"selected=selected":""; ?>><?php _e('profile', 'google_plus_badge'); ?></option>
            <option value="page" <?php echo get_gpb_page_type()=="page"?"selected=selected":""; ?>><?php _e('page', 'google_plus_badge'); ?></option>
            <option value="community" <?php echo get_gpb_page_type()=="community"?"selected=selected":""; ?>><?php _e('community', 'google_plus_badge'); ?></option>
        </select>
    </div>
  </div>
    <div class="control-group">
  	<label class="control-label"><?php _e('Google+ Page URL', 'google_plus_badge'); ?></label>
    <div class="controls">
    	<input type="text" name="gpb_page_url" value="<?php echo osc_esc_html(get_gpb_page_url()); ?>">
    </div>
  </div>
  <div class="control-group">
  	<label class="control-label"><?php _e('Width', 'google_plus_badge'); ?></label>
    <div class="controls">
    	<input type="text" class="swidth" name="gpb_width" value="<?php echo osc_esc_html(get_gpb_width()); ?>">
    </div>
  </div>
  <div class="control-group">
  	<label class="control-label"><?php _e('Select Color Scheme', 'google_plus_badge'); ?></label>
    <div class="controls">
        <select name="gpb_color_scheme" id="gpb_color_scheme">
            <option value="light" <?php echo get_gpb_color_scheme()=="light"?"selected=selected":""; ?>><?php _e('light', 'google_plus_badge'); ?></option>
            <option value="dark" <?php echo get_gpb_color_scheme()=="dark"?"selected=selected":""; ?>><?php _e('dark', 'google_plus_badge'); ?></option>
        </select>
    </div>
  </div>
  <div class="control-group">
  	<label class="control-label"><?php _e('Select Layout', 'google_plus_badge'); ?></label>
    <div class="controls">
        <select name="gpb_layout" id="gpb_layout">
            <option value="portrait" <?php echo get_gpb_layout()=="portrait"?"selected=selected":""; ?>><?php _e('portrait', 'google_plus_badge'); ?></option>
            <option value="landscape" <?php echo get_gpb_layout()=="landscape"?"selected=selected":""; ?>><?php _e('landscape', 'google_plus_badge'); ?></option>
        </select>
    </div>
  </div>
  <div class="control-group"> 	
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (get_gpb_cover_photo() ? 'checked="true"' : ''); ?> name="gpb_cover_photo" id="gpb_cover_photo" value="true" />
        <label><?php _e('Cover Photo', 'google_plus_badge'); ?></label>
    </div>
  </div>
  <div class="control-group"> 	
    <div class="controls checkbox">
    	<input type="checkbox" <?php echo (get_gpb_tagline() ? 'checked="true"' : ''); ?> name="gpb_tagline" id="gpb_tagline" value="true" />
        <label><?php _e('Tagline', 'google_plus_badge'); ?></label>
    </div>
  </div>
  </fieldset>
  <div class="form-actions">
    <input type="submit" value="<?php _e('Save changes', 'google_plus_badge'); ?>" class="btn btn-submit">
  </div>
  
</form>
</div>
<br />
<div id="settings_form" style="border: 1px solid #ccc; background: #eee; ">
  <div style="padding: 0 20px 20px;">
    <div>
    	<p><?php _e('Place following code into theme file wherever you need to display.', 'google_plus_badge'); ?></p>
    	<pre>
        &lt;?php
        if(function_exists('google_plus_badge'))
        {
                google_plus_badge(); 
        }
        ?&gt;
        </pre>
      
    </div>
  </div>
</div>