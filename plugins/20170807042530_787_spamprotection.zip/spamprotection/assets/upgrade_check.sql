SELECT `s_reputation` FROM `/*TABLE_PREFIX*/t_spam_protection_users` WHERE 1;
SELECT `pk_i_id` FROM `/*TABLE_PREFIX*/t_spam_protection_global_log` WHERE 1;