<?php
namespace dliCore;

use Defuse\Crypto\Key;
use dliLib\Cache\CacheManager;
use dliLib\CSS\CSSManager;
use dliLib\Html\Fragment;
use dliLib\IO\FileSystem;
use dliLib\Item\Item;
use dliLib\Job\JobManager;
use dliLib\JS\JSManager;
use dliLib\Plugin;
use dliLib\Plugin\Admin\Menu;
use dliLib\Plugin\Admin\Menu\Group as MenuGroup;
use dliLib\Plugin\Admin\Menu\Icon as MenuIcon;
use dliLib\Plugin\Admin\Menu\Item as MenuItem;
use dliLib\Plugin\Admin\Menu\MenuRegistry;
use dliLib\Plugin\Dependency\OsclassDependency;
use dliLib\Plugin\Dependency\PhpDependency;
use dliLib\Plugin\Dependency\PluginDependency;
use dliLib\Plugin\Hook;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Route\AbstractRoute;
use dliLib\Request;
use dliLib\Shell\ProcessManager;
use dliLib\User\User;
use FluentDOM;

/**
 * Core plugin that provides some base functionality like requesting support on plugins etc.
 * @author danlil
 */
class dliCorePlugin extends Plugin
{
    protected $_configAction = 'Admin-index';

    protected $_controllers = [ 'dliCore\Controllers\AdminController',
                                'dliCore\Controllers\JsController',
                                'dliCore\Controllers\SupportController',
                                'dliCore\Controllers\SettingsController',
                                'dliCore\Controllers\CacheController',
                                'dliCore\Controllers\TimeController',
                                'dliCore\Controllers\FileManagerController',
                                'dliCore\Controllers\JobController',
                                'dliCore\Controllers\ProcessController'];

    protected function _init() {
        /* Register Dependencies */
        $this->_registerDependency(new PhpDependency('5.6.0'));
        $this->_registerDependency(new OsclassDependency('3.2.0'));
        //$this->_registerDependency(new PhpExtensionDependency('openssl', '2.0.0'));

        /* Register Preferecnes */
        $this->registerPreference(new Plugin\Preference\StringPreference($this, 'EncryptionKey', 'UNINITIALIZED'));
        if($this->getPreference('EncryptionKey')->getValue() == 'UNINITIALIZED') {
            $this->getPreference('EncryptionKey')->setValue(Key::createNewRandomKey()->saveToAsciiSafeString());
        }

        $this->registerPreference(new Plugin\Preference\StringPreference($this, 'PluginsTempBaseDirectory', sys_get_temp_dir(), __('Plugins Temp Directory', 'dliCore'), __('Base directory for temporary files. Not meant to be public.', 'dliCore')));
        $this->registerPreference(new Plugin\Preference\StringPreference($this, 'PluginsPrivateBaseDirectory', osc_base_path() . 'oc-content/uploads/dliPrivateStorage', __('Plugins Private Storage', 'dliCore'), __('Base directory for private file storage. Should point to a folder not publicly accessible.', 'dliCore')));
        $this->registerPreference(new Plugin\Preference\StringPreference($this, 'PluginsPublicBaseDirectory', osc_base_path() . 'oc-content/uploads/dliPublicStorage', __('Plugins Public Storage', 'dliCore'), __('Base directory for public file storage. Should point to a directory publicly available via the web server.', 'dliCore')));

        /* Register Hooks */
        $this->_registerHook(new Hook('PrePluginsTempBaseDirectoryChanged', 'Called before moving existing plugin files when the base directory for temporary files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));
        $this->_registerHook(new Hook('PrePluginsPrivateBaseDirectoryChanged', 'Called before moving existing plugin files when the base directory for plugins non public files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));
        $this->_registerHook(new Hook('PrePluginsPublicBaseDirectoryChanged', 'Called before moving existing plugin files when the base directory for plugins public files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));

        $this->_registerHook(new Hook('PluginsTempBaseDirectoryChanged', 'Used to move existing plugin files', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path'], true));
        $this->_registerHook(new Hook('PluginsPrivateBaseDirectoryChanged', 'Used to move existing plugin files', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path'], true));
        $this->_registerHook(new Hook('PluginsPublicBaseDirectoryChanged', 'Used to move existing plugin files', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path'], true));

        $this->_registerHook(new Hook('PostPluginsTempBaseDirectoryChanged', 'Called after moving existing plugin files when the base directory for temporary files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));
        $this->_registerHook(new Hook('PostPluginsPrivateBaseDirectoryChanged', 'Called after moving existing plugin files when the base directory for plugins non public files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));
        $this->_registerHook(new Hook('PostPluginsPublicBaseDirectoryChanged', 'Called after moving existing plugin files when the base directory for plugins public files are changed', ['oldPath' => 'String containing old path', 'newPath' => 'String containing new path']));

        $this->_registerHook(new Hook('AdminMenuInjection', 'Called before menu creation.'));

        //$this->_registerHook(new Hook('FinalOutput', 'Allows a plugin to modify output before it\'s sent. Enables plugins to insert needed changes to pages without requiring users to edit their theme files etc.', ['document' => 'FluentDOM\DOMDocument containing the output. All style tags, script tags and specific if IE tags are replaced with place holders and reinserted after FluentDOM is finished so not to confuse and break the DOM since FluentDOM still treats some parts of HTML documents as XML']));
        /* ------------------------------------------- */

        /* Register Tables */
        $this->_registerTable('dliCore\Tables\phpSecTable', 'phpSec');
        $this->_registerTable('dliLib\Email\Table\EmailBatchTable', 'EmailBatchTable');
        $this->_registerTable('dliLib\Email\Table\EmailBatchKeywordsTable', 'EmailBatchKeywordsTable');
        $this->_registerTable('dliLib\Email\Table\EmailBatchRecipientTable', 'EmailBatchRecipientTable');
        $this->_registerTable('dliLib\Email\Table\EmailBatchRecipientKeywordsTable', 'EmailBatchRecipientKeywordsTable');
        $this->_registerTable('dliLib\Email\Table\EmailAddressStatusTable', 'EmailAddressStatusTable');
        $this->_registerTable('dliLib\Job\Table\Jobs', 'JobTable');
        $this->_registerTable('dliLib\Admin\Table\AdminPreferencesTable', 'AdminPreferencesTable');
        $this->_registerTable('dliLib\User\Table\UserPreferencesTable', 'UserPreferencesTable');

        //$this->registerController('dliCore\Controllers\DonationController');
        $this->getThemedAssetUrl('assets/js/pnotify/pnotify.custom.css');

        $this->_enqueueScripts();
        //CacheManager::getInstance()->enableLogging();
    }

    /**
     * Moves any files and folders under the old location to the new location
     *
     * @hook dlicore_plugins_temp_base_directory_changed
     * @hook dlicore_plugins_private_base_directory_changed
     * @hook dlicore_plugins_public_base_directory_changed
     * @param $oldLocation
     * @param $newLocation
     * @throws \Exception
     */
    protected function MoveFolders($oldLocation, $newLocation) {
        $processManagerEnabled  = ProcessManager::getInstance()->isEnabled();
        $jobManagerEnabled      = JobManager::getInstance()->isEnabled();

        ProcessManager::getInstance()->disable();
        JobManager::getInstance()->disable();

        foreach(PluginManager::getInstance()->getAllPlugins() as $plugin) {
            $pluginDataFolder = FileSystem::normalisePath(rtrim($oldLocation, '/\\') . DIRECTORY_SEPARATOR) . $plugin->getName();
            if(FileSystem::dirExists($pluginDataFolder)) {
                FileSystem::recursiveCopy($pluginDataFolder, FileSystem::normalisePath(rtrim($newLocation   , '/\\') . DIRECTORY_SEPARATOR) . $plugin->getName());
                FileSystem::deleteDir($pluginDataFolder);
            }
        }

        if($processManagerEnabled) {
            ProcessManager::getInstance()->enable();
        }
        if($jobManagerEnabled) {
            JobManager::getInstance()->enable();
        }
    }
    
    private function _enqueueScripts() {
        JSManager::getInstance()->registerJSFile('jquery-plugin', $this->getPluginUrl() . 'assets/js/jquery.plugin.js', 'jquery');
        JSManager::getInstance()->enqueueJSFile('jquery-plugin');

        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl().'assets/css/animate.css', 'animate');

        JSManager::getInstance()->registerJSFile('pnotify', $this->getPluginUrl() . 'assets/js/pnotify/pnotify.custom.js', 'jquery-ui');
        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl() . 'assets/js/pnotify/pnotify.custom.css', 'pnotify');
        JSManager::getInstance()->enqueueJSFile('pnotify');

        JSManager::getInstance()->registerJSFile('jquery-validate', $this->getPluginUrl() . 'assets/js/validate/jquery.validate.js', 'jquery-ui');
        JSManager::getInstance()->registerJSFile('jquery-validate-additional-methods', $this->getPluginUrl() . 'assets/js/validate/additional-methods.js', 'jquery-validate');
        JSManager::getInstance()->enqueueJSFile('jquery-validate');
        JSManager::getInstance()->enqueueJSFile('jquery-validate-additional-methods');

        JSManager::getInstance()->registerJSFile('waitMe', $this->getPluginUrl() . 'assets/js/waitMe/waitMe.js', 'jquery-ui');
        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl() . 'assets/js/waitMe/waitMe.css', 'waitMe');
        JSManager::getInstance()->enqueueJSFile('waitMe');

        JSManager::getInstance()->registerJSFile('jquery-datetimepicker', $this->getPluginUrl() . 'assets/js/datetimepicker/jquery.datetimepicker.js', 'jquery');
        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl() . 'assets/js/datetimepicker/jquery.datetimepicker.css', 'jquery-datetimepicker');
        JSManager::getInstance()->enqueueJSFile('jquery-datetimepicker');

        JSManager::getInstance()->registerJSFile('jquery-countdown', $this->getPluginUrl() . 'assets/js/countdown/jquery.countdown.min.js', 'jquery-plugin');
        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl() . 'assets/js/countdown/jquery.countdown.css', 'jquery-countdown');
        JSManager::getInstance()->enqueueJSFile('jquery-countdown');

        JSManager::getInstance()->registerJSFile('jquery-maxlength', $this->getPluginUrl() . 'assets/js/jquery.maxlength/jquery.maxlength.js', 'jquery-plugin');
        CSSManager::getInstance()->registerCSSFile($this->getPluginUrl() . 'assets/js/jquery.maxlength/jquery.maxlength.css', 'jquery.maxlength');
        JSManager::getInstance()->enqueueJSFile('jquery-maxlength');

        // onMutate
        JSManager::getInstance()->registerJSFile('jquery-onmutate', $this->getPluginUrl() . 'assets/js/onmutate/jquery.onmutate.js', 'jquery');
        JSManager::getInstance()->enqueueJSFile('jquery-onmutate');

        JSManager::getInstance()->registerJSFile('dlicore', $this->getThemedAssetUrl('js/dlicore.js'), 'jquery-ui');
        JSManager::getInstance()->enqueueJSFile('dlicore');
    }

    /**
     * Makes sure the Job and Process manager are running if enabled
     */
    private function _initManagers() {
        JobManager::getInstance()->init();
        ProcessManager::init();
    }

    public function getSupportEmail() {
        return 'osc-support@danielliljeberg.se';
    }

    protected function installHook() {
        $this->_initializeStorageFolders();
    }

    protected function updateHook($previousVersion, $newVersion)
    {
        $this->_initializeStorageFolders();
    }

    /**
     * Creates folders for dliCore based plugins to store temporary, private and public data and warns user if there are
     * any issues with the default paths.
     */
    private function _initializeStorageFolders() {
        if(!FileSystem::dirExists($this->getPreference('PluginsPrivateBaseDirectory')->getValue())) {
            @mkdir($this->getPreference('PluginsPrivateBaseDirectory')->getValue());
            @file_put_contents($this->getPreference('PluginsPrivateBaseDirectory')->getDefaultValue() . DIRECTORY_SEPARATOR . '.htaccess', 'order deny,allow
deny from all
Require all denied');
        }

        if(!FileSystem::dirExists($this->getPreference('PluginsPublicBaseDirectory')->getValue())) {
            @mkdir($this->getPreference('PluginsPublicBaseDirectory')->getDefaultValue());
        }

        if(!FileSystem::dirExists($this->getPreference('PluginsTempBaseDirectory')->getValue())) {
            @mkdir($this->getPreference('PluginsTempBaseDirectory')->getDefaultValue());
        }

        $configUrl = AbstractRoute::getRoute('dliCore', 'Settings', 'configure');
        $messages = [];
        if(!FileSystem::isWritable($this->getPreference('PluginsTempBaseDirectory')->getValue())) {
            $messages[] = sprintf(__('%s is not writable.'), $this->getPreference('PluginsTempBaseDirectory')->getValue());
            ProcessManager::getInstance()->disable();
            JobManager::getInstance()->disable();
        }
        if(FileSystem::isPublic($this->getPreference('PluginsPrivateBaseDirectory')->getValue(), true)) {
            $messages[] = sprintf(__('%s is publicly available.'), $this->getPreference('PluginsPrivateBaseDirectory')->getValue());
        }
        if(!FileSystem::isWritable($this->getPreference('PluginsPublicBaseDirectory')->getValue())) {
            $messages[] = sprintf(__('%s is not writable.'), $this->getPreference('PluginsPublicBaseDirectory')->getValue());
        }
        if(!FileSystem::isPublic($this->getPreference('PluginsPublicBaseDirectory')->getValue())) {
            $messages[] = sprintf(__('%s is not publicly available.'), $this->getPreference('PluginsPublicBaseDirectory')->getValue());
        }
        if($messages) {
            osc_add_flash_warning_message(implode(PHP_EOL, $messages) . PHP_EOL . sprintf(__('Configure storage locations <a href="%s">here</a>'), $configUrl), 'admin');
        }
    }

    protected function uninstallHook() {
        // Kill all running processes
        foreach(ProcessManager::getInstance()->getRunningProcesses() as $process) {
            $process->kill();
        }
    }

    // Tracks removed plugins and warns if a dependency has been broken
    public function beforeAdminHtmlHook() {
        $enabledPlugins = \Plugins::listEnabled();
        $prevEnabledPlugins = \Session::newInstance()->_get('dliCore_enabledPlugins');

        if($prevEnabledPlugins != '') {
            $missingPlugins = array_diff(unserialize($prevEnabledPlugins), $enabledPlugins);
            foreach($missingPlugins as $missingPlugin) {
                $missingPluginName = str_replace('/index.php', '', $missingPlugin);
                foreach(PluginManager::getInstance()->getAllPlugins() as $plugin) {
                    foreach($plugin->getDependencies() as $dependency) {
                        if($dependency instanceof PluginDependency && $dependency->getName() == $missingPluginName) {
                            $plugin->deactivate();
                            osc_add_flash_warning_message(sprintf(__('%s will not function correctly without %s and has been disabled.', $plugin->getName(), $missingPluginName)), 'admin');
                            $this->_redirectTo(osc_admin_base_url(true) . '?page=plugins');
                        }
                    }
                }
            }
        }
        \Session::newInstance()->_set('dliCore_enabledPlugins', serialize($enabledPlugins));
    }

    // Show warning when uninstalling plugin that is needed for dependency
    //public function adminFooterHook() {
    public function beforeShowPaginationAdminHook () {
        if(Request::getParam('page') === 'plugins' && Request::getParam('action') === '') {
            $dependencies = array();
            $availableUpdates = array();

            $legacyPlugins = \Plugins::listAll();

            foreach(PluginManager::getInstance()->getAllPlugins() as $plugin) {
                // Filter Plugin from legacy plugins array
                if(($key = array_search($plugin->getPluginOscName(), $legacyPlugins)) !== FALSE) {
                    unset($legacyPlugins[$key]);
                }

                // Check if plugin has update
                /*$updateInfo = $plugin->getUpdateInfo();
                if($updateInfo->isUpdateAvailabe()) {
                    $availableUpdates[] =&$updateInfo;
                }*/

                foreach($plugin->getDependencies() as $dependency) {
                    if($dependency instanceof PluginDependency) {
                        $dependencies[$dependency->getName()][] = $plugin->getName();
                    }
                }
            }

            // Check legacy style plugins for updates
            /*foreach($legacyPlugins as $legacyPlugin) {
                $updateInfo = new LegacyPluginUpdateInfo($legacyPlugin);
                if($updateInfo->isUpdateAvailabe()) {
                    $availableUpdates[] = &$updateInfo;
                }
            }*/

            // Check market if plugin paid during install and warn user?
            $fragment = new Fragment($this, 'beforeShowPaginationAdmin.php');
            $fragment->dependencies = $dependencies;
            JSManager::getInstance()->registerScript($fragment->render(false), JSManager::LOCATION_DOCUMENT_READY);
        }
    }

    /**
     * @priority 0
     * @throws \Exception
     */
    protected function headerHook() {
        $fragment = new Fragment($this, 'header.php');
        $fragment->render();
        $this->_initManagers();
        if(!PluginManager::getInstance()->isShutdownFunctionRegistered()) {
            echo CSSManager::getInstance()->getStyles();
            echo JSManager::getInstance()->getScripts(JSManager::LOCATION_HEADER);
        }
    }

    /** 
     * @priority 0
     * @throws \Exception
     */
    protected function adminHeaderHook() {
        if(Request::getParam('route', false, false) !== 'dliCore-Cache-configure' && CacheManager::getInstance()->getPreference('cacheManagerCache')->getValue() === 'dliLib\Cache\NullCache') {
            osc_add_flash_warning_message(sprintf(__('No cache system is active for dliCore. If you are not running in a developer environment you should activate a cache system <a href="%s">here</a>'), $this->getRoute('Cache', 'configure')->getUrl()), 'admin');
        }
        $fragment = new Fragment($this, 'adminHeader.php');
        $fragment->render();
        $this->_initManagers();
        if(!PluginManager::getInstance()->isShutdownFunctionRegistered()) {
            echo CSSManager::getInstance()->getStyles();
            echo JSManager::getInstance()->getScripts(JSManager::LOCATION_HEADER);
        }
    }

    /**
     * Registers JS files already loaded by Osclass so JSManager knows about them
     * @hook scripts_loaded
     * @hook admin_scripts_loaded
     */
    protected function recordLoadedJSFiles() {
        JSManager::getInstance()->recordLoadedJSFiles();
    }

    /**
     * @priority 10
     * @throws \Exception
     */
    protected function adminFooterHook() {
        /**
         * Adds css to display our menu icons
         */
        $fragment = new Fragment($this, 'adminFooter.php');
        $fragment->menus = MenuRegistry::getInstance()->getAll();
        $fragment->render();
        if(!PluginManager::getInstance()->isShutdownFunctionRegistered()) {
            echo JSManager::getInstance()->getJSFiles();
            echo JSManager::getInstance()->getScripts(JSManager::LOCATION_FOOTER);
        }
    }

    /**
     * @priority 10
     * @throws \Exception
     */
    protected function footerHook() {
        $fragment = new Fragment($this, 'footer.php');
        $fragment->render();
        if(!PluginManager::getInstance()->isShutdownFunctionRegistered()) {
            echo JSManager::getInstance()->getJSFiles();
            echo JSManager::getInstance()->getScripts(JSManager::LOCATION_FOOTER);
        }
    }

    private function _buildMenus() {
        $dliCoreAdminMenu = new Menu('dliCore', __('dliCore', 'dliCore'), 'dliCore-Admin-index', new MenuIcon($this->getPluginUrl().'assets/images/admin_menu.png', $this->getPluginUrl().'assets/images/admin_menu_hover.png'));

        $dliCoreGroup = new MenuGroup('dliCore_Group', __('dliCore', 'dliCore'));
        $dliCoreGroup->addSubItem(new MenuItem('dliCore_Dashboard', __('Dashboard', 'dliCore'), $this->getRoute('Admin')->getName()));
        $dliCoreGroup->addSubItem(new MenuItem('dliCore_Settings', __('Settings', 'dliCore'), $this->getRoute('Settings', 'configure')->getName()));
        $dliCoreAdminMenu->addSubItemGroup($dliCoreGroup);

        $configGroup = new MenuGroup('dliCore_ConfigGroup', __('Configuration', 'dliCore'));
        $configGroup->addSubItem(new MenuItem('dliCore_Cache', __('Cache Manager', 'dliCore'), $this->getRoute('Cache', 'configure')->getName()));
        $dliCoreAdminMenu->addSubItemGroup($configGroup);

        $fileManagerGroup = new MenuGroup('dliCore_FileManagerGroup', __('FileManager', 'dliCore'));
        //$fileManagerGroup->addSubItem(new MenuItem('dliCore_FileManager', __('Open File Manager', 'dliCore'), 'dliCore-FileManager-open'));
        $fileManagerGroup->addSubItem(new MenuItem('dliCore_FileManagerConfig', __('Configure File Manager', 'dliCore'), $this->getRoute('FileManager', 'configure')->getName()));
        $dliCoreAdminMenu->addSubItemGroup($fileManagerGroup);

        $processGroup = new MenuGroup('dliCore_JobsAndProcessGroup', __('Jobs & Processes', 'dliCore'));
        $processGroup->addSubItem(new MenuItem('dliCore_JobsList', __('JobManager', 'dliCore'), $this->getRoute('Job', 'list')->getName()));
        $processGroup->addSubItem(new MenuItem('dliCore_ProcessList', __('Process List', 'dliCore'), $this->getRoute('Process', 'list')->getName()));
        $dliCoreAdminMenu->addSubItemGroup($processGroup);

        $helpGroup = new MenuGroup('dliCore_HelpGroup', __('Help', 'dliCore'));
        $helpGroup->addSubItem(new MenuItem('dliCore_Support', __('Request Support', 'dliCore'), $this->getRoute('Support', 'requestSupport')->getName()));
        $helpGroup->addSubItem(new MenuItem('dliCore_Developer', __('Build plugins with dliCore', 'dliCore'), $this->getRoute('Support', 'howTo')->getName()));
        $helpGroup->addSubItem(new MenuItem('dliCore_phpInfo', __('phpInfo', 'dliCore'), $this->getRoute('Admin', 'phpinfo')->getName()));
        $dliCoreAdminMenu->addSubItemGroup($helpGroup);

        /*$donateGroup = new Group('dliCore_DonateGroup', __('Show some love', 'dliCore'));
        $donateGroup->addSubItem(new Item('dliCore_Donation', __('Donate', 'dliCore'), 'dliCore-Donation-donate'));
        $dliCoreAdminMenu->addSubItemGroup($donateGroup);*/

        MenuRegistry::getInstance()->register($dliCoreAdminMenu, 'dliCore');

        // Build only root to make sure it ends up
        //$dliCoreAdminMenu->build(true);
    }

    protected function adminMenuInitHook()
    {
        $this->_buildMenus();
        $this->runHook('AdminMenuInjection');
        /**
         * @var Menu $menu
         */
        foreach (MenuRegistry::getInstance()->getAll() as $menu) {
            $menu->build();
        }
    }

    public function getDliPlugins() {
        $query = FluentDOM::QueryCss(osc_file_get_contents('http://market.osclass.org/user/profile/665'), 'html');
        $plugins = [];

        $query->find('.grid-listing')->each(function(\DOMElement $node, $index) use(&$plugins) {
            $pluginRow              = FluentDOM::QueryCss($node, 'html');
            $plugin                 = [];
            $plugin['title']        = $pluginRow->find('.claim')->text();
            $plugin['url']          = $pluginRow->find('.claim')->attr('href');
            $plugin['description']  = $pluginRow->find('p')->text();
            $plugin['img']          = $pluginRow->find('.img')->css('background-image:url');
            $plugins[]              = $plugin;
        });

        return $plugins;
    }

    /**
     * Clears caches containing the User
     * @param $userId
     * @throws \Exception
     */
    protected function userEditCompletedHook($userId) {
        $user = User::find($userId);
        if($user) {
            CacheManager::getInstance()->invalidateAllCachesWithMember($user);
        }
    }

    /**
     * Clears caches containing the Item
     * @param $item
     * @throws \Exception
     */
    protected function editedItemHook($item) {
        $item = Item::find($item['pk_i_id']);
        if($item) {
            CacheManager::getInstance()->invalidateAllCachesWithMember($item);
        }
    }
}