<?php
namespace dliCore;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Route\AbstractRoute;
use dliLib\Request;

if(!defined('__OSC_LOADED__')) { die(); }
/*
Plugin Name: dliCore
Plugin URI: http://www.osclass.org/
Description: Core functionality for plugins created using the dliCore framework
Version: 0.5.1
Author: Daniel Liljeberg
Author URI: http://www.danielliljeberg.se/
Short Name: dliCore
Plugin update URI: dlicore
Support URI: /oc-admin/index.php?page=plugins&action=renderplugin&route=dliCore-Support-requestSupport&defaultPlugin=dliCore
*/
if(!defined('__dliCore_LOADED__')) {
    define('DLI_CORE_ROUTE_DELIMITER', '-');
    if(defined('OSC_DEBUG')) {
        define('DLICORE_DEBUG', true);
    }
    /**
     * Registers a namespace to the autoloader
     * @param $namespace
     * @param $path
     */
    function dliCore_createAutoloader($namespace, $path)
    {
        static $loader = null;
        if (!($loader)) {
            $loader = require_once('vendor/autoload.php');
        }

        $path = rtrim(rtrim($path, '\\'), '/');

        $loader->add($namespace, $path);

        $classMap = $path . DIRECTORY_SEPARATOR . $namespace . DIRECTORY_SEPARATOR . 'autoloaderClassMap.php';
        $composerClassMap = $path . DIRECTORY_SEPARATOR . $namespace . DIRECTORY_SEPARATOR . 'vendor' . DIRECTORY_SEPARATOR . 'composer' . DIRECTORY_SEPARATOR . 'autoload_classmap.php';

        // Include classmap file if it exists for added performance
        if ($namespace != __NAMESPACE__) {
            if (file_exists($classMap)) {
                $classMap = include_once($classMap);
                $loader->addClassMap($classMap);
            }
            if (file_exists($composerClassMap)) {
                $classMap = include_once($composerClassMap);
                $loader->addClassMap($classMap);
            }
        }
    }

    // Register base plugin
    dliCore_createAutoloader(__NAMESPACE__, osc_plugins_path());

    PluginManager::getInstance()->registerPlugin(__NAMESPACE__ . '\\' . __NAMESPACE__ . 'Plugin');

    function phpsec_get_psl()
    {
        static $psl = null;

        if (!($psl instanceof \phpSec\Core)) {
            $psl = new \phpSec\Core();
            $psl['store'] = $psl->share(function ($psl) {
                $dsn = 'mysql:' .
                    'dbname=' . DB_NAME . ';' .
                    'table=' . DB_TABLE_PREFIX . 't_dli_phpsec;' .
                    'host=' . DB_HOST . ';' .
                    'username=' . DB_USER . ';' .
                    'password=' . DB_PASSWORD;
                return new \phpSec\Store\Pdo($dsn, $psl);
            });
        }

        return $psl;
    }

    /***
     * Hook to run plugins based on the route
     *
     * @throws \Exception
     * @throws \ReflectionException
     */
    function dliCore_controller()
    {
         AbstractRoute::init();
         $route = Request::getRoute();
         if($route) {
             $route->execute();
         }
    }

    osc_add_hook('custom_controller', 'dliCore\dliCore_controller');
    osc_add_hook('renderplugin_controller', 'dliCore\dliCore_controller');

    // Special case to have the controllers run if called using ajax
    if (Request::getParam('page') == 'ajax') {
        osc_add_hook('init', 'dliCore\dliCore_controller');
    }
}

define('__dliCore_LOADED__', 1);