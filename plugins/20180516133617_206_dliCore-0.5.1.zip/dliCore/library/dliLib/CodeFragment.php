<?php
namespace dliLib;
use dliLib\IO\FileSystem;
use dliLib\Plugin;

/**
 * Class CodeFragment
 * Allows for small fragments of code to run and be different depending on the theme used
 *
 * @package dliLib\Html
 */
class CodeFragment
{
    protected $_data            = [];
    protected $_fragmentFile    = '';
    protected $_basePath        = '';

    const DYNAMIC_THEME = 'dynamic';
    const DEFAULT_THEME = 'default';

    /***
     *
     * @param string|Plugin $basePath Base path to use when looking for fragments and theme specific fragments. An instance of a Plugin or a string to a path. If for instance __FILE__ is used the path that __FILE__ resides in will be used.
     * @param string $filename Filename of the fragment
     * @param string $theme Use specific named theme. DEFAULT_THEME can be used to force the default fragments to be used and DYNAMIC_THEME makes theme specific fragments be used first and default as a fallback
     * @throws \Exception
     */
    public function __construct($basePath, $filename, $theme = CodeFragment::DYNAMIC_THEME) {
        if($basePath instanceof Plugin) {
            $this->_data['plugin'] = $basePath;
            $this->_basePath = $basePath->getPluginPath();
        }
        else {
            if(is_file($basePath)) {
                $this->_basePath = dirname($basePath);
            }
            else {
                $this->_basePath = $basePath;
            }
        }

        if(file_exists($this->_basePath)) {
            $this->_basePath = rtrim(rtrim($this->_basePath, '\\'), '/');
            $this->_basePath = FileSystem::normalisePath($this->_basePath);
        }

        switch($theme) {
            case CodeFragment::DEFAULT_THEME:
                $this->_fragmentFile = $this->_basePath . DIRECTORY_SEPARATOR . 'codeFragments' . DIRECTORY_SEPARATOR . $filename;
                if(!file_exists($this->_fragmentFile)) {
                    throw new \Exception('Unknown code fragment' . ' ' . $this->_fragmentFile);
                }
                break;
            case CodeFragment::DYNAMIC_THEME:
                $themeName = \WebThemes::newInstance()->getCurrentTheme();
                $this->_fragmentFile = $this->_basePath . DIRECTORY_SEPARATOR . 'themes' . DIRECTORY_SEPARATOR . $themeName . DIRECTORY_SEPARATOR . 'codeFragments' . DIRECTORY_SEPARATOR . $filename;

                if(!file_exists($this->_fragmentFile)) {
                    $this->_fragmentFile = $this->_basePath . DIRECTORY_SEPARATOR . 'codeFragments' . DIRECTORY_SEPARATOR . $filename;
                    if(!file_exists($this->_fragmentFile)) {
                        throw new \Exception('Unknown code fragment' . ' ' . $this->_fragmentFile);
                    }
                }
                break;
            default:
                $this->_fragmentFile = $this->_basePath . DIRECTORY_SEPARATOR . $theme . DIRECTORY_SEPARATOR . 'codeFragments' . DIRECTORY_SEPARATOR . $filename;
                if(!file_exists($this->_fragmentFile)) {
                    throw new \Exception('Unknown code fragment' . ' ' . $this->_fragmentFile);
                }
        }
    }

    public function __get($name) {
        if(isset($this->_data[$name])) {
            return $this->_data[$name];
        }
        if($name == 'plugin') {
            $this->_data[$name] = Plugin\Manager\PluginManager::getInstance()->getPluginOwningFile(__FILE__);
            return $this->_data[$name];
        }
        throw new \InvalidArgumentException($name . ' is not registered to the code fragment');
    }

    public function __set($name, $value) {
        $this->_data[$name] = $value;
    }

    /**
     * Makes it possible to add a callable function to the CodeFragment
     *
     * @param $method
     * @param $args
     * @return bool|mixed
     */
    public function __call($method, $args) {
        if(isset($this->_data[$method])) {
            if(is_callable($this->_data[$method])) {
                return call_user_func_array($this->_data[$method], $args);
            }
        }
        return false;
    }

    public function execute() {
        try {
            return (include($this->_fragmentFile));
        }
        catch(\Exception $e) {
            throw $e;
        }
    }
}
