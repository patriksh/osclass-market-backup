<?php
namespace dliLib;
/**
 * Class to wrap string and provide some functions for manpulating them
 *
 * @author danlil
 *
 */
class dliString
{
    private $_string;

    public function __construct($string = '') {
        $this->set((string)$string);
    }

    public function set($string) {
        if (!is_string($string)) {
            throw new \InvalidArgumentException();
        }
        $this->_string = $string;
    }

    /**
     * Checks if the string starts with the given string.
     * If a string is passed the result is true or false.
     * If an array of strings are passed the result is the matching string or false
     *
     * @param string|string[] $string
     * @return bool|string|false
     */
    public function startsWith($string) {
        if(is_array($string)) {
            foreach($string as $str) {
                if (substr($this->_string, 0, strlen($str)) != $str) {
                }
                else {
                    return $str;
                }
            }

            return false;
        }
        else {
            if (substr($this->_string, 0, strlen($string)) != $string) {
                return false;
            }
            return true;
        }
    }

    /**
     * Checks if the string ends with the given string.
     * If a string is passed the result is true or false.
     * If an array of strings are passed the result is the matching string or false
     *
     * @param string|string[] $string
     * @return bool|string|false
     */
    public function endsWith($string) {
        if(is_array($string)) {
            foreach($string as $str) {
                if (substr($this->_string, -strlen($str)) != $str) {
                }
                else {
                    return $str;
                }
            }

            return false;
        }
        else {
            if (substr($this->_string, -strlen($string)) != $string) {
                return false;
            }
            return true;
        }
    }

    /**
     * Removes the given string from the end of the string
     *
     * If an array is passed then any matching string of the array will be removed from the end.
     *
     * @param string|string[] $string
     * @return $this
     */
    public function removeFromEnd($string) {
        if(!is_array($string)) {
            $string = [$string];
        }

        $string = $this->endsWith($string);

        if($string !== false) {
            $this->_string = substr($this->_string, 0, strlen($this->_string) - strlen($string));
        }

        return $this;
    }

    /**
     * Removes the given string from the start of the string
     *
     * If an array is passed then any matching string of the array will be removed from the start.
     *
     * @param string|string[] $string
     * @return $this
     */
    public function removeFromStart($string) {
        if(!is_array($string)) {
            $string = [$string];
        }

        $string = $this->startsWith($string);

        if($string !== false) {
            $this->_string = substr($this->_string, -strlen($this->_string) + strlen($string));
        }

        return $this;
    }

    /**
     * Trims the string with the supplied list of characters
     * @see trim()
     * @param $charList
     * @return $this
     */
    public function trim($charList) {
        $this->_string = trim($this->_string, $charList);
        return $this;
    }

    /**
     * Trims the string with the supplied list of characters
     * @see trim()
     * @param $charList
     * @return $this
     */
    public function ltrim($charList) {
        $this->_string = ltrim($this->_string, $charList);
        return $this;
    }

    /**
     * Trims the string with the supplied list of characters
     * @see trim()
     * @param $charList
     * @return $this
     */
    public function rtrim($charList) {
        $this->_string = rtrim($this->_string, $charList);
        return $this;
    }

    /**
     * Returns under_score string as camelCase string
     * @return string
     */
    public function asCamelCase() {
        $result = '';
        $stringParts = explode('_', $this->_string);

        foreach ($stringParts as $stringPart) {
            $result .= ($result == '' ? $stringPart : ucfirst($stringPart));
        }

        return $result;
    }

    /**
     * Converts under_score string to camelCase string
     * @return $this
     */
    public function toCamelCase() {
        $this->_string = $this->asCamelCase();
        return $this;
    }

    public function asUnderScoreCase() {
        $matches = [];
        preg_match_all('!([A-Z][A-Z0-9]*(?=$|[A-Z][a-z0-9])|[A-Za-z][a-z0-9]+)!', $this->_string, $matches);
        $ret = $matches[0];
        foreach ($ret as &$match) {
            $match = $match == strtoupper($match) ? strtolower($match) : lcfirst($match);
        }
        unset($match);

        return implode('_', $ret);
    }

    /**
     * Converts
     * @return $this
     */
    public function toUnderScoreCase() {
        $this->_string = $this->asUnderScoreCase();
        return $this;
    }

    /**
     * Returns crc32 hash of the string
     * @return string
     */
    public function crc32() {
        return hash("crc32b", $this->_string);
    }

    /**
     * Truncates string
     *
     * @param $maxLength
     * @param string $fill
     * @return $this
     */
    public function truncate($maxLength, $fill = "...") {
        if(strpos($this->_string, "\n") != 0 && strpos($this->_string, "\n") < $maxLength) {
            $maxLength = strpos($this->_string, "\n");
        }

        if($this->_string[$this->length()-1] == ".") {
            $maxLength = $maxLength - 1;
        }

        if($this->length() > $maxLength) {
            $this->_string = mb_substr($this->_string, 0, $maxLength, 'utf-8') . $fill;
        }
        return $this;
    }

    public function trimUntil($char) {
        $this->_string = substr($this->_string, strpos($this->_string, $char));
        return $this;
    }

    public function trimFrom($char) {
        $this->_string = substr($this->_string, 0, strpos($this->_string, $char));
        return $this;
    }

    /**
     * Splits string by line
     * @return array
     */
    public function toArray() {
        return preg_split ('/$\R?^/m', (string)$this->_string);
    }

    public function __toString()
    {
        return (string)$this->_string;
    }

    /**
     * Returns length of string
     * @return int
     */
    public function length() {
        return (int)strlen($this->_string);
    }

    /**
     * Replaces occurrences of $search with $replace in the string
     * @param $search
     * @param $replace
     * @return $this
     */
    public function replace($search, $replace) {
        $this->_string = str_replace($search, $replace, $this->_string);
        return $this;
    }

    public function contains($search) {
        return (strpos($this->_string, $search) !== false);
    }

    public function isValidEmailAddress() {
        return (bool)osc_validate_email($this->_string);
    }

    public function isValidIpAddress() {
        return (bool)preg_match('/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/', $this->_string);
    }

    public function isValidIpAddressWithPort() {
        return (bool)preg_match('/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(:[0-9]+)?$/', $this->_string);
    }

    public function isValidHostname() {
        return (bool)preg_match('/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/', $this->_string);
    }

    public function isValidHostnameWithPort() {
        return (bool)preg_match('/^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])(:[0-9]+)?$/', $this->_string);
    }

    public function isValid952Hostname() {
        return (bool)preg_match('/^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])$/', $this->_string);
    }

    public function isValid952HostnameWithPort() {
        return (bool)preg_match('/^(([a-zA-Z]|[a-zA-Z][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)*([A-Za-z]|[A-Za-z][A-Za-z0-9\-]*[A-Za-z0-9])(:[0-9]+)?$/', $this->_string);
    }
}
