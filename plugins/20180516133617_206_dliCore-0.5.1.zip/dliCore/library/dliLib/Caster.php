<?php
namespace dliLib;

/**
 * Class Caster
 * @package dliLib
 */
class Caster
{
    /**
     * Convert an object to a specific class.
     *
     * Usage: $object = Caster::cast($object, 'NewObjectType');
     *
     * @param object $object
     * @param string $className The class to cast the object to
     * @return object
     * @throws \Exception
     */
    public static function cast($object, $className) {
        if($object === false) return false;
        if(class_exists($className)) {
            $serializedObject   = serialize($object);
            $objectNameLength   = strlen(get_class($object));
            $start              = $objectNameLength + strlen($objectNameLength) + 6;
            $newObject          = 'O:' . strlen($className) . ':"' . $className . '":';
            $newObject          .= substr($serializedObject, $start);
            $newObject          = unserialize($newObject);
            /**
             * The new object is of the correct type but
             * is not fully initialized throughout its graph.
             * To get the full object graph (including parent
             * class data, we need to create a new instance of
             * the specified class and then assign the new
             * properties to it.
             */
            $graph = new $className;
            foreach($newObject as $prop => $val) {
                $graph->$prop = $val;
            }
            return $graph;
        } else {
            throw new \Exception("Unknown class type $className");
        }
    }
}