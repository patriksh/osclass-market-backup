<?php
namespace dliLib\Admin\Preference;

class ArrayAdminPreference extends AbstractAdminPreference {
    protected $_type = 'STRING';

    public function setValue($value) {
        if(!is_array($value)) {
            throw new \InvalidArgumentException();
        }
        parent::setValue(serialize($value));
    }

    public function getValue() {
        return unserialize($this->_value);
    }
}