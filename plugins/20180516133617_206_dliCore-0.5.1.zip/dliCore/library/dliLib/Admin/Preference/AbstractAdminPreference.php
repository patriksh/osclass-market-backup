<?php
namespace dliLib\Admin\Preference;

use dliLib\Plugin;
use dliLib\Plugin\Preference\AbstractPreference;
use dliLib\Admin\Model\AdminPreference;
use dliLib\Admin\Admin;

/**
 * Manages preferences for admins
 *
 * As long as the value of the preference is not altered from the default value no data is saved to the database
 *
 * @author danlil
 *
 */
abstract class AbstractAdminPreference extends AbstractPreference
{
    protected $_name;
    protected $_admin;
    protected $_defaultValue;
    protected $_value;
    protected $_type;
    protected $_plugin;
    protected $_preference  = null;

    protected $_title       = null;
    protected $_description = null;

    /**
     * AbstractAdminPreference constructor.
     *
     * Passing null as Admin causes the current logged in admin to be used
     *
     * @param Plugin $plugin
     * @param $name
     * @param $defaultValue
     * @param Admin|null $admin
     * @param null $title
     * @param null $description
     */
    public function __construct(Plugin $plugin, $name, $defaultValue, Admin $admin = null, $title = null, $description = null)
    {
        $this->_admin           = $admin;
        $this->_name            = $name;
        $this->_defaultValue    = $defaultValue;
        $this->_plugin          = $plugin;

        $this->_title           = $title;
        $this->_description     = $description;

        if(!$this->_admin)
        {
            $this->_admin = Admin::getCurrentLoggedInAdmin();
        }

        if(!$this->_admin) {
            $this->_value = $defaultValue;
        }
        else {
            $this->_preference = AdminPreference::fetchForAdminAndPlugin($this->_admin, $this->_plugin, $this->_name);

            if (!$this->_preference) {
                $this->setValue($defaultValue);
            } else {
                $this->_value = $this->_preference->getValue();
            }
        }
    }

    public function getTitle() {
        if($this->_title === null) {
            return $this->_name;
        }
        else {
            return $this->_title;
        }
    }

    public function getDescription() {
        return $this->_description;
    }

    public function deleteValue() {
        $this->_value = null;

        if(!$this->_admin || !$this->_preference) {
            return;
        }

        $preference = AdminPreference::fetchForAdminAndPlugin($this->_admin, $this->_plugin, $this->_name);
        if($preference) {
            AdminPreference::delete($preference);
        }
    }

    public function setValue($value) {
        $oldValue = $this->_value;
        $this->_value = $value;

        if(!$this->_admin || $this->_value == $oldValue) {
            return;
        }

        //$preference = AdminPreference::fetchForAdminAndPlugin($this->_admin, $this->_plugin, $this->_name);
        if(!$this->_preference) {
            $this->_preference = new AdminPreference();
        }

        $this->_preference->setAdminId($this->_admin->getId());
        $this->_preference->setSection($this->_plugin->getName());
        $this->_preference->setName($this->_name);
        $this->_preference->setValue($this->_value);
        $this->_preference->setType($this->_type);
        $this->_preference->save();
    }

    public function getValue() {
        return $this->_value;
    }

    /*public function getType(){
        return $this->_type;
    }*/

    public function getName() {
        return $this->_name;
    }

    public function refresh() {
        if(!$this->_admin) {
            return;
        }

        $preference = AdminPreference::fetchForAdminAndPlugin($this->_admin, $this->_plugin, $this->_name);
        if(!$preference) {
            $this->setValue($this->_defaultValue);
        }
        else {
            $this->_value = $preference->getValue();
        }
    }
}