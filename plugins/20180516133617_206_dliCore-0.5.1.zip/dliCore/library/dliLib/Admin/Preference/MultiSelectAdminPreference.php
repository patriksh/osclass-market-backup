<?php
namespace dliLib\Admin\Preference;

use dliLib\Plugin;

/***
 * Class MultiSelectPreference
 *
 * Stores value as serialized array and also contains a list of valid options. This can then be used by Html\Form\Element\Preference
 * to create a multi select box.
 *
 * @see dliLib\Html\Form\Element\Preference
 * @package dliLib\Plugin\Preference
 */
class MultiSelectAdminPreference extends AbstractAdminPreference {
    protected $_type    = 'STRING';
    protected $_options = null;

    public function __construct(Plugin $plugin, $name, $defaultValue, array $options, $title = null, $description = null) {
        $this->_options = $options;
        parent::__construct($plugin, $name, $defaultValue, $title, $description);
    }

    public function getOptions() {
        return $this->_options;
    }

    public function setValue($values) {
        $valuesToStore = [];
        if(!is_array($values)) {
            $values = [$values];
        }

        foreach($values as $value) {
            if (array_key_exists($value, $this->_options)) {
                $valuesToStore[] = $value;
            } else {
                throw new \InvalidArgumentException("Invalid value");
            }
        }

        parent::setValue(serialize($valuesToStore));
    }

    public function getValue() {
        return unserialize($this->_value);
    }
}