<?php
namespace dliLib\Admin\Preference;

class BooleanAdminPreference extends AbstractAdminPreference {
    protected $_type = 'BOOLEAN';
}