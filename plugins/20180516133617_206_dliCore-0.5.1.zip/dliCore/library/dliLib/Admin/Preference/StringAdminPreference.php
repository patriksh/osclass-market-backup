<?php
namespace dliLib\Admin\Preference;

class StringAdminPreference extends AbstractAdminPreference {
    protected $_type = 'STRING';
}