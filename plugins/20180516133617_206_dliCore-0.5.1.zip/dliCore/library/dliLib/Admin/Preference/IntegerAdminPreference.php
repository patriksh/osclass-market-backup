<?php
namespace dliLib\Admin\Preference;

class IntegerAdminPreference extends AbstractAdminPreference {
    protected $_type = 'INTEGER';

    public function getValue()
    {
        return (int)parent::getValue();
    }
}