<?php
namespace dliLib\Admin\Preference;

use dliLib\Plugin;

/***
 * Class SelectPreference
 *
 * Stores value as string but also contains a list of valid options. This can then be used by Html\Form\Element\Preference
 * to create a select box.
 *
 * @see dliLib\Html\Form\Element\Preference
 * @package dliLib\Plugin\Preference
 */
class SelectAdminPreference extends AbstractAdminPreference {
    protected $_type = 'STRING';
    protected $_options = null;

    public function __construct(Plugin $plugin, $name, $defaultValue, array $options, $title = null, $description = null) {
        $this->_options = $options;
        parent::__construct($plugin, $name, $defaultValue, $title, $description);
    }

    public function getOptions() {
        return $this->_options;
    }

    public function setValue($value) {
        if(in_array($value, array_values($this->_options))) {
            parent::setValue($value);
        }
        else {
            throw new \InvalidArgumentException("Invalid value");
        }
    }
}