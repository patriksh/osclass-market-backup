<?php
namespace dliLib\Admin\Model;

use dliLib\Admin\Admin;
use dliLib\Model\DbModel;
use dliLib\Plugin;

/**
 * Hold receipient information used by an EmailBatch
 *
 * @author danlil
 * @see EmailBatch
 */
class AdminPreference extends DbModel
{
    protected static $_dbTableClass = 'dliLib\Admin\Table\AdminPreferencesTable';

    /**
     * @var AbstractPreference[][]
     */
    protected static $_userPreferences = [];

    protected $_adminId  = null;
    protected $_section = null;
    protected $_name    = null;
    protected $_value   = null;
    protected $_type    = null;

    /**
     * @return null
     */
    public function getAdminId()
    {
        return $this->_adminId;
    }

    /**
     * @param null $adminId
     * @return AdminPreference
     */
    public function setAdminId($adminId)
    {
        $this->_adminId = $adminId;
        return $this;
    }

    /**
     * @return null
     */
    public function getSection()
    {
        return $this->_section;
    }

    /**
     * @param null $section
     * @return static
     */
    public function setSection($section)
    {
        $this->_section = $section;
        return $this;
    }

    /**
     * @return null
     */
    public function getName()
    {
        return $this->_name;
    }

    /**
     * @param null $name
     * @return static
     */
    public function setName($name)
    {
        $this->_name = $name;
        return $this;
    }

    /**
     * @return null
     */
    public function getValue()
    {
        return $this->_value;
    }

    /**
     * @param null $value
     * @return static
     */
    public function setValue($value)
    {
        $this->_value = $value;
        return $this;
    }

    /**
     * @return null
     */
    public function getType()
    {
        return $this->_type;
    }

    /**
     * @param null $type
     * @return static
     */
    public function setType($type)
    {
        $this->_type = $type;
        return $this;
    }

    /**
     * @param Admin $admin
     * @return AdminPreference[]
     * @throws \Exception
     */
    public static function fetchAllForAdmin(Admin $admin) {
        if(!array_key_exists($admin->getId(), static::$_adminPreferences)) {
            if(!isset(static::$_adminPreferences[$admin->getId()])) {
                static::$_adminPreferences[$admin->getId()] = static::_fetchAll(static::getDbTable()->selectConditions()->where('fk_i_admin_id', $admin->getId())->orderBy('s_section'));
            }
        }

        return static::$_adminPreferences[$admin->getId()];
    }

    /**
     * @param Admin $admin
     * @param Plugin $plugin
     * @return AdminPreference[]
     */
    public static function fetchAllForUserAndPlugin(Admin $admin, Plugin $plugin) {
        $adminPluginPreferences = [];
        foreach(static::fetchAllForAdmin($admin) as $preference) {
            if($preference->getSection() == $plugin->getName()) {
                $adminPluginPreferences[] = $preference;
            }
        }

        return $adminPluginPreferences;
    }

    /**
     * @param Admin $user
     * @param Plugin $plugin
     * @param $name
     * @return AdminPreference|null
     */
    public static function fetchForUserAndPlugin(Admin $user, Plugin $plugin, $name) {
        foreach(static::fetchAllForAdmin($user) as $preference) {
            if($preference->getSection() == $plugin->getName() && $preference->getName() == $name) {
                return $preference;
            }
        }

        return null;
    }

    /**
     * Deletes all user preferences for a plugin
     * @param Plugin $plugin
     */
    public static function deleteAllForPlugin(Plugin $plugin) {
        AdminPreference::deleteWhere(['s_section' => $plugin->getName()]);
    }
}