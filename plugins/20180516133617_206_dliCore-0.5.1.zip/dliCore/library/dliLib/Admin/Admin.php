<?php
namespace dliLib\Admin;

use dliLib\Model\OscModel;
use dliLib\Plugin;
use dliLib\Admin\Model\AdminPreference;

/**
 * Admin object in the Osclass DB
 * @author danlil
 *
 */
class Admin extends OscModel
{
    protected static $_dbTableClass = 'dliLib\Admin\Table\AdminTable';

    protected $_id          = null;
    protected $_name        = null;
    protected $_username    = null;
    protected $_password    = null;
    protected $_email       = null;
    protected $_secret      = null;
    protected $_moderator   = null;

    protected static $_currentLoggedInAdmin = null;

    public function getId()
    {
        return $this->_id;
    }

    public function setId($_id)
    {
        $this->_id = $_id;
        return $this;
    }

    public function getName()
    {
        return $this->_name;
    }

    public function setName($_name)
    {
        $this->_name = $_name;
        return $this;
    }

    public function getUsername()
    {
        return $this->_username;
    }

    public function setUsername($_username)
    {
        $this->_username = $_username;
        return $this;
    }

    public function getPassword()
    {
        return $this->_password;
    }

    public function setPassword($_password)
    {
        $this->_password = $_password;
        return $this;
    }

    public function getSecret()
    {
        return $this->_secret;
    }

    public function setSecret($_secret)
    {
        $this->_secret = $_secret;
        return $this;
    }

    public function getEmail()
    {
        return $this->_email;
    }

    public function setEmail($_email)
    {
        $this->_email = $_email;
        return $this;
    }

    public function isAdmin() {
        return (bool)$this->_moderator;
    }

    public function setModerator($isModerator) {
        $this->_moderator = (int)(bool)$isModerator;
    }

    public function getPreference($name, Plugin $plugin = null) {
        if(!$plugin) {
            $plugin = Plugin\Manager\PluginManager::getInstance()->getCurrentPlugin();
        }

        return AdminPreference::fetchForUserAndPlugin($this, $plugin, $name);
    }

    /**
     * @return Admin
     * @throws \Exception
     */
    public static function getCurrentLoggedInAdmin() {
        if(osc_logged_admin_id()) {
            if(!static::$_currentLoggedInAdmin) {
                static::$_currentLoggedInAdmin = static::find(osc_logged_admin_id());
            }
            return static::$_currentLoggedInAdmin;
        }
        else {
            return null;
        }
    }

    /**
     * Find a Admin based on their email address
     *
     * @param $email
     * @return null|static
     * @throws \Exception
     */
    public static function findByEmail($email) {
        return static::_fetchRow(static::getDbTable()->selectConditions()->where('s_email', $email));
    }

    /**
     * Find a Admin based on their username
     *
     * @param $username
     * @return null|static
     * @throws \Exception
     */
    public static function findByUsername($username) {
        return static::_fetchRow(static::getDbTable()->selectConditions()->where('s_username', $username));
    }
}