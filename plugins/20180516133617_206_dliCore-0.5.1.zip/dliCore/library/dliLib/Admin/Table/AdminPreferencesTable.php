<?php
namespace dliLib\Admin\Table;

use dliLib\Db\AbstractTable;

/**
 *
 * Table to hold User preferences
 * @author danlil
 *
 */
class AdminPreferencesTable extends AbstractTable
{
    protected $_tableName = 't_dli_core_admin_preferences';

    protected function _init() {
        $this->_struct =
            "CREATE TABLE IF NOT EXISTS /*TABLE_NAME*/ (
            fk_i_admin_id INT(10) UNSIGNED NOT NULL,
            s_section VARCHAR(40) NOT NULL,
            s_name varchar(40) NOT NULL,
            s_value longtext NOT NULL,
            e_type enum('STRING', 'INTEGER', 'BOOLEAN') NOT NULL,
            UNIQUE KEY (fk_i_admin_id, s_section, s_name),
            FOREIGN KEY (fk_i_admin_id) REFERENCES /*TABLE_PREFIX*/t_admin (pk_i_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';";
    }
}
