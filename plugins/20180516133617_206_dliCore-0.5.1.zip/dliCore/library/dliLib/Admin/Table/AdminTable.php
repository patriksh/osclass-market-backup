<?php
namespace dliLib\Admin\Table;

use dliLib\Db\AbstractTable;

/**
 * Special structless table used as a glue between Admin and the db
 * @author danlil
 *
 */
class AdminTable extends AbstractTable
{
    protected $_tableName = 't_admin';
}