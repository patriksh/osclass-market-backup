<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-08
 * Time: 15:54
 */

namespace dliLib\Html;

/**
 * Class Decorator
 *
 * Used to 'decorate'/style a piece of html code.
 * Accepted by html Elements such as forms etc.
 *
 * @package dliLib\Html
 */
abstract class Decorator {
    /**
     * @param string $html
     * @return string decorated html
     */
    abstract public function decorate($html);
}