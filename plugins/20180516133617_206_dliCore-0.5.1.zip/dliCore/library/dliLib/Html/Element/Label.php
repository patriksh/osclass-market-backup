<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:00
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;

class Label extends Element {
    public function __construct($id = null, array $attributes = array()) {
        parent::__construct(Element::LABEL, $id, $attributes);
    }
}