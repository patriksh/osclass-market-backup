<?php
namespace dliLib\Html\Element;

use dliLib\CSS\CSSManager;
use dliLib\JS\JSManager;
use dliLib\JS\JSWrapper;
use dliLib\Plugin\Manager\PluginManager;

class DataTable extends Table {
    protected $_options = [];

    public function __construct($id = null, array $attributes = []) {
        parent::__construct($id, $attributes);

        $this->addOption('language', ['lengthMenu' => __('Show _MENU_ entries', 'dliCore')]);
    }

    public function setData($data, $extractorFunc) {
        $dataArr = [];
        if(is_array($data)) {
            foreach($data as $index => $entry) {
                if(is_object($entry)) {
                    if ($extractorFunc == null) {
                        throw new \Exception('Extractor function needs to be supplied');
                    }

                    $dataArr[] = $extractorFunc($entry);
                    if (!is_array(end($dataArr))) {
                        throw new \Exception('Data array not returned from extractor function');
                    }
                }
                else {
                    $dataArr[] = $entry;
                }
            }
        }
        else if(is_object($data)) {
            if($extractorFunc == null) {
                throw new \Exception('Extractor function needs to be supplied');
            }

            $dataArr = $extractorFunc($data);
            if(!is_array($data)) {
                throw new \Exception('Data array not returned from extractor function');
            }
        }
        else if(!is_array($data)) {
            throw new \Exception('Data array not supplied');
        }

        if(count($dataArr) > 0) {
            $this->addOption('data', $dataArr);
        }
    }

    public function addOption($name, $value) {
        $this->_options[(string)$name] = $value;
        return $this;
    }

    private function _interpretOption($name, $value) {
        if(is_bool($value)) {
            $value = ($value ? 'true' : 'false');
        }
        else if(is_array($value)) {
            $valueStr = '';

            $firstItr = true;
            $namedKeys = false;
            foreach($value as $valName => $val) {
                if($firstItr) {
                    if (is_string($valName)) {
                        $namedKeys = true;
                        if ($firstItr) {
                            $valueStr .= '{';
                        }
                    } else {
                        if ($firstItr) {
                            $valueStr .= '[';
                        }
                    }

                    //$valueStr .= PHP_EOL;
                }
                else {
                    $valueStr .= ', ';
                }

                $valueStr .= $this->_interpretOption($valName, $val);
                $firstItr = false;
            }

            if($namedKeys) {
                $valueStr .= '}';
            }
            else {
                $valueStr .= ']';
            }
            //$valueStr .= PHP_EOL;
            $value = $valueStr;
        }
        else if(is_string($value)) {
            $value = json_encode(utf8_encode($value));
        }
        else if(is_null($value)) {
            $value = 'null';
        }
        else if($value instanceof JSWrapper) {
        }
        return (is_string($name) ? "\"$name\"" . ': ' : '') . $value;
    }

    protected function _build()
    {
        static $doInit = true;
        if($doInit) {
            JSManager::getInstance()->registerJSFile('datatables', PluginManager::getInstance()->getCorePlugin()->getPluginUrl() . 'assets/js/datatables/datatables.js', 'jquery');
            CSSManager::getInstance()->registerCSSFile(PluginManager::getInstance()->getCorePlugin()->getPluginUrl() . 'assets/js/datatables/datatables.css', 'datatables');
            CSSManager::getInstance()->registerCSSFile(PluginManager::getInstance()->getCorePlugin()->getPluginUrl() . 'assets/js/datatables/Buttons-1.4.0/css/buttons.dataTables.css', 'datatables-buttons');
            JSManager::getInstance()->enqueueJSFile('datatables');
            $doInit = false;
        }

        $colData = [];
        foreach($this->_columns as $index => $column) {
            if(!is_int($column)) {
                $colData[] = ['data' => $column, 'targets' => $index];
            }
        }

        if($colData) {
            if (!isset($this->_options['columnDefs'])) {
                $this->addOption('columnDefs', $colData);
            } else {
                $this->_options['columnDefs'] = array_merge($colData, $this->_options['columnDefs']);
            }
        }

        JSManager::getInstance()->enqueueJSFile('datatables');
        CSSManager::getInstance()->registerStyle('
        table.dataTable tr th.select-checkbox.selected::after {
            content: "✔";
            margin-top: -11px;
            margin-left: -4px;
            text-align: center;
            text-shadow: rgb(176, 190, 217) 1px 1px, rgb(176, 190, 217) -1px -1px, rgb(176, 190, 217) 1px -1px, rgb(176, 190, 217) -1px 1px;
        }
        ', 'data-table-select-all');


        JSManager::getInstance()->registerScript('
    $.fn.dataTable.ext.order["sort-value"] = function  ( settings, col )
    {
        return this.api().column( col, {order:"index"} ).nodes().map( function ( td, i ) {
            return $(td).attr("sort-value");
        } );
    }
    
    var '.$this->getAttribute('id').' = $("#'.$this->getAttribute('id').'").DataTable('.$this->_interpretOption(null, $this->_options).');
    
    '.$this->getAttribute('id').'.on("click", "th.select-checkbox", function() {
                if ($("th.select-checkbox").hasClass("selected")) {
                    '.$this->getAttribute('id').'.rows().deselect();
                    $("th.select-checkbox").removeClass("selected");
                } else {
                    '.$this->getAttribute('id').'.rows({search: "applied"}).select();
                    $("th.select-checkbox").addClass("selected");
                }
            }).on("select deselect", function() {
                ("Some selection or deselection going on")
                if ('.$this->getAttribute('id').'.rows({
                        selected: true
                    }).count() !== '.$this->getAttribute('id').'.rows().count()) {
                    $("th.select-checkbox").removeClass("selected");
                } else {
                    $("th.select-checkbox").addClass("selected");
                }
            });
', JSManager::LOCATION_DOCUMENT_READY);

        return parent::_build();
    }
}