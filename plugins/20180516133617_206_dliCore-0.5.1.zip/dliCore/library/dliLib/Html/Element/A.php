<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:00
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;

class A extends Element {
    public function __construct($id = null, $text = null, $link = null, array $attributes = []) {
        parent::__construct(Element::A, $id, $attributes);
        if($text) {
            $this->setInnerHtml($text);
        }
        if($link) {
            $this->setAttribute('href', $link);
        }
    }

    public function setText($text) {
        $this->setInnerHtml($text);
    }

    public function setHref($link) {
        $this->setAttribute('href', $link);
    }
}