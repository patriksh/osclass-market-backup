<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:29
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;

class Script extends Element {
    public function __construct() {
        parent::__construct(Element::SCRIPT);
    }
}