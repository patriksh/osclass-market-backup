<?php
namespace dliLib\Html\Element;

use dliLib\Html\Element;

class Table extends Element {
    protected $_heading;
    protected $_body;
    protected $_columns;
    protected $_numRows = 0;

    public function __construct($id = null, array $attributes = []) {
        parent::__construct(Element::TABLE, $id, $attributes);
        $this->_heading = new Element\Table\Head(($id ? $id . '_heading' : ''));
        $this->addChild($this->_heading);

        $this->_body = new Element\Table\Body(($id ? $id . '_body' : ''));
        $this->addChild($this->_body);
    }

    public function setTitle($title) {
        $this->setAttribute('title', $title);
        return $this;
    }

    public function getTitle() {
        return $this->getAttribute('title');
    }

    public function addColumn($text, $columnName = null)
    {
        $columnName = ($columnName ? $columnName : count($this->_columns));
        $this->_columns[] = $columnName;

        $thId = ($this->getAttribute('id') ? $this->getAttribute('id') . '_heading_' . $columnName : null);
        $th = new Element\Table\Heading($thId, $text);
        $th->setAttribute('column-name', $columnName);
        $this->_heading->addColumn($th);
        return $this;
    }

    public function setColumns(array $columns) {
        $this->_heading->clearColumns();

        $this->_columns = [];

        foreach($columns as $index => $column) {
            $this->addColumn($column, is_string($index) ? $index : null);
        }
        return $this;
    }

    /**
     * Adds a row to the Table
     * Either you can add a Table\Row or you can add an array of strings
     * Returns the added row so that alterations can be done to it
     *
     * @param $row
     * @return Table\Row
     */
    public function addRow($row) {
        if($row instanceof Element\Table\Row) {
            foreach ($row->getChildren() as $index => $cell) {
                if ($cell instanceof Element\Table\Data) {
                    $cell->setAttribute('column-name', $this->_columns[$index]);
                }
            }
            $this->_body->addChild($row);
        }
        else if(is_array($row)) {
            $r = new Element\Table\Row();
            foreach($row as $index => $cell) {
                $thId = ($this->getAttribute('id') ? $this->getAttribute('id') . '_data_' . $this->_columns[$index] : null);
                $td = new Element\Table\Data($thId);
                $td->setAttribute('column-name', $this->_columns[$index]);
                $td->setInnerHtml($cell);
                $r->addChild($td);
            }

            for($i = 0; $i < count($this->_columns) - count($row); $i++) {
                $r->addTd('');
            }
            $this->_body->addChild($r);
            $row = $r;
        }
        else {
            throw new \InvalidArgumentException();
        }

        ++$this->_numRows;

        return $row;
    }

    public function setAttributeToColumn($columnName, $attribute, $value = Element::ATTRIBUTE_NO_VALUE)
    {
        foreach($this->_heading->getChildren() as $row) {
            foreach ($row->getChildren() as $cell) {
                if ($cell instanceof Element\Table\Heading) {
                    if ($cell->getAttribute('column-name') == $columnName) {
                        $cell->setAttribute($attribute, $value);
                    }
                }
            }
        }

        foreach($this->_body->getChildren() as $row) {
            foreach ($row->getChildren() as $cell) {
                if ($cell instanceof Element\Table\Data) {
                    if ($cell->getAttribute('column-name') == $columnName) {
                        $cell->setAttribute($attribute, $value);
                    }
                }
            }
        }
        return $this;
    }

    //public function addColumn($columnName) {
        //echo '<ul class="showing-results"><li><span>'.osc_pagination_showing((Params::getParam('iPage')-1)*$aData['iDisplayLength']+1, ((Params::getParam('iPage')-1)*$aData['iDisplayLength'])+count($aData['aRows']), $aData['iTotalDisplayRecords'], $aData['iTotalRecords']).'</span></li></ul>';
    //}
}