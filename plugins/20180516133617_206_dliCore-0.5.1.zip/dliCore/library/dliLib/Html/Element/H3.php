<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:00
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;

class H3 extends Element {
    public function __construct($id = null, $text = null, array $attributes = array()) {
        parent::__construct(Element::H3, $id, $attributes);
        if($text) {
            $this->setInnerHtml($text);
        }
    }
}