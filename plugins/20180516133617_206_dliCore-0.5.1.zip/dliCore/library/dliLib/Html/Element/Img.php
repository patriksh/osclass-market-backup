<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:00
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;

class Img extends Element {
    public function __construct($id = null, $src = null, array $attributes = array()) {
        parent::__construct(Element::IMG, $id, $attributes);
        if($src) {
            $this->setAttribute('src', $src);
        }
    }
}