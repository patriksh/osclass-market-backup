<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-05
 * Time: 01:00
 */

namespace dliLib\Html\Element;


use dliLib\Html\Element;
use dliLib\Html\Fragment;

/**
 * Class FragmentElement
 * Special Element type that can contain a fragment
 * @package dliLib\Html\Element
 */
class FragmentContainer extends Element {
    /***
     * @var Fragment|null
     */
    private $_fragment = null;

    public function __construct(Fragment $fragment, $id = null, array $attributes = []) {
        $this->_fragment = $fragment;
        parent::__construct(Element::DIV, $id, $attributes);
    }

    protected function _build()
    {
        try {
            $this->appendInnerHtml($this->_fragment->render(false));
        }
        catch(\Exception $e) {
            echo $e->getMessage() . '<br/>';
            echo $e->getFile() . '<br/>';
            echo $e->getLine() . '<br/>';
            echo $e->getTraceAsString() . '<br/>';
        }
        return parent::_build();
    }
}