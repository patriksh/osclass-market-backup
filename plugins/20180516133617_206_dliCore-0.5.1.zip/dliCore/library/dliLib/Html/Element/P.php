<?php
namespace dliLib\Html\Element;


use dliLib\Html\Element;

class P extends Element {
    public function __construct($id = null, $text = null, array $attributes = array()) {
        parent::__construct(Element::P, $id, $attributes);
        if($text) {
            $this->setInnerHtml($text);
        }
    }
}