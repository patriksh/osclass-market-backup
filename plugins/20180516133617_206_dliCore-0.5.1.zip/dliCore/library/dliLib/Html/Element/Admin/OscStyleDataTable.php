<?php
namespace dliLib\Html\Element;

class OscStyleDataTable extends DataTable {
    protected $_options = [];

    public function __construct($id = null, array $attributes = []) {
        parent::__construct($id, $attributes);
    }

    protected function _build()
    {
        return parent::_build();
    }
}