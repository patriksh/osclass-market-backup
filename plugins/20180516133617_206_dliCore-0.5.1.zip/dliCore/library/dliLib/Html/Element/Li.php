<?php
namespace dliLib\Html\Element;


use dliLib\Html\Element;

class Li extends Element {
    public function __construct($id = null, array $attributes = []) {
        parent::__construct(Element::LI, $id, $attributes);
    }
}