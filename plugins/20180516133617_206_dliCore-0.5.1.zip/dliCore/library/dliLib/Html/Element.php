<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2015-04-04
 * Time: 22:36
 */

namespace dliLib\Html;


class Element {
    const H1 = 'h1';
    const H2 = 'h2';
    const H3 = 'h3';
    const H4 = 'h4';

    const TABLE = 'table';
    const TABLE_ROW = 'tr';
    const TABLE_HEAD = 'thead';
    const TABLE_HEADING = 'th';
    const TABLE_BODY = 'tbody';
    const TABLE_DATA = 'td';

    const FORM = 'form';

    const FIELDSET = 'fieldset';

    const UL = 'ul';
    const LI = 'li';

    const A = 'a';
    const P = 'p';

    const SELECT = 'select';
    const OPTION = 'option';

    const INPUT = 'input';
    const IMG = 'img';
    const HR = 'hr';
    const BR = 'br';
    const META = 'meta';
    const LINK = 'link';

    const DIV = 'div';
    const SPAN = 'span';

    const LABEL = 'label';

    const BUTTON = 'button';
    const CAPTCHA = 'captcha';
    const CHECKBOX = 'checkbox';
    const COLLECTION = 'collection';
    const COLOR = 'color';
    const CSRF = 'csrf';
    const DATE = 'date';
    const DATESELECT = 'dateselect';
    const DATETIME = 'datetime';
    const DATETIMELOCAL = 'datetimelocal';
    const DATETIMESELECT = 'datetimeselect';
    const EMAIL = 'email';
    const FILE = 'file';
    const HIDDEN = 'hidden';
    const IMAGE = 'image';
    const MONTH = 'month';
    const MONTHSELECT = 'monthselect';
    const MULTICHECKBOX = 'multicheckbox';
    const NUMBER = 'number';
    const PASSWORD = 'password';
    const RADIO = 'radio';
    const RANGE = 'range';
    const SUBMIT = 'submit';
    const TEXT = 'text';
    const TEXTAREA = 'textarea';
    const TIME = 'time';
    const URL = 'url';
    const WEEK = 'week';
    const SCRIPT = 'script';

    const ATTRIBUTE_NO_VALUE = '__ATTRIBUTE__NO__VALUE__';

    protected $_type        = null;
    protected $_unaryTypes  = [Element::INPUT, Element::IMG, Element::HR, Element::BR, Element::META, Element::LINK];
    protected $_attributes  = [];
    protected $children     = [];
    protected $_innerHtml   = '';

    protected $_elements    = [];

    protected $_decorators  = [];

    /**
     * Adds a decorator to decorate the Form with
     * If a FragmentDecorator is used it will override all other decorators
     *
     * @param Decorator $decorator
     * @return Element
     */
    public function addDecorator(Decorator $decorator) {
        if($decorator instanceof FragmentDecorator) {
            unset($this->_decorators);
        }
        $this->_decorators[] = $decorator;
        return $this;
    }

    public function setDecorators(array $decorators) {
        foreach($decorators as $decorator) {
            if($decorator instanceof FragmentDecorator) {
                unset($this->_decorators);
                $this->_decorators = $decorator;
                return;
            }
            $this->_decorators[] = $decorator;
        }
        return $this;
    }

    public function __construct($type, $id = null, array $attributes = []) {
        if(!defined(__CLASS__.'::'.$type)) {
            //throw new \InvalidArgumentException('Invalid tag type');
        }

        $this->_type = $type;
        $this->setAttributes($attributes);

        if($id) {
            $this->setAttribute('id', $id);
            $this->setAttribute('name', $id);
            $this->setAttribute('uid', uniqid());
        }
    }

    public function getType() {
        return $this->_type;
    }

    /**
     * @return Element[]
     */
    public function &getChildren() {
        return $this->_elements;
    }

    public function getChildByName($name) {
        foreach($this->_elements as &$element) {
            if($element->getAttribute('name') == $name) {
                return $element;
            }
        }

        return null;
    }

    public function prependChild(Element $element) {
        array_unshift($this->_elements, $element);
        return $this;
    }

    public function addChild(Element $element) {
        array_push($this->_elements, $element);
        return $this;
    }

    public function clearChildren() {
        $this->_elements = [];
    }

    public function setInnerHtml($html) {
        $this->_innerHtml = $html;
        return $this;
    }

    public function appendInnerHtml($html) {
        $this->_innerHtml .= $html;
        return $this;
    }

    public function getInnerHtml() {
        return $this->_innerHtml;
    }


    /**
     * Set html element attribute
     *
     * @param $attribute
     * @param $value
     * @return Element
     */
    public function setAttribute($attribute, $value = Element::ATTRIBUTE_NO_VALUE) {
        $this->_attributes[$attribute] = $value;
        return $this;
    }

    /**
     * Set multiple html element attributes
     *
     * @param array $attributes
     * @return Element
     */
    public function setAttributes(array $attributes) {
        $this->_attributes = array_merge($this->_attributes, $attributes);
        return $this;
    }

    public function attributeExists($attribute) {
        return array_key_exists($attribute, $this->_attributes);
    }

    public function getAttribute($attribute) {
        if(array_key_exists($attribute, $this->_attributes)) {
            return $this->_attributes[$attribute];
        }
        return null;
    }

    /**
     * Remove html element attribute
     * @param $attribute
     * @return Element
     */
    public function removeAttribute($attribute) {
        if(array_key_exists($attribute, $this->_attributes)) {
            unset($this->_attributes[$attribute]);
        }
        return $this;
    }

    /**
     * Removes all html element attributes
     */
    public function clearAttributes() {
        $this->_attributes = array();
        return $this;
    }

    public function getStartTag() {
        $element = '<'.$this->_type;

        // Add attributes
        if(count($this->_attributes)) {
            foreach($this->_attributes as $key => $value) {
                if($value === Element::ATTRIBUTE_NO_VALUE) {
                    $element .= ' ' . $key;
                }
                else {
                    $element .= ' ' . $key . '="' . $value . '"';
                }
            }
        }

        // Close the element
        if(!in_array($this->_type, $this->_unaryTypes)) {
            $element.= '>';
        }

        return $element;
    }

    public function getCloseTag() {
        if(!in_array($this->_type, $this->_unaryTypes)) {
            $element = $this->_innerHtml.'</'.$this->_type.'>';
        }
        else {
            $element = '/>';
        }

        return $element;
    }

    protected function _build() {
        if(count($this->_decorators) == 1 && $this->_decorators[0] instanceof FragmentDecorator) {
            $element = $this->_decorators[0]->decorate($this);
        }
        else {
            foreach ($this->_elements as &$childElement) {
                $this->_innerHtml .= $childElement;
            }
            // Start the tag
            $element = $this->getStartTag();
            $element .= $this->getCloseTag();

            foreach($this->_decorators as $decorator) {
                $element = $decorator->decorate($element);
            }

            return $element;
        }
    }

    public function __toString() {
        return $this->_build();
    }

    public function getTidy() {
        $tidy = new \tidy();
        return $tidy->repairString($this->__toString(), ['show-body-only' => true, 'drop-empty-paras' => false, 'output-xhtml' => true]);
    }
}