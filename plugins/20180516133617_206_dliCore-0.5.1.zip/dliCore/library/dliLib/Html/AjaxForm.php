<?php
namespace dliLib\Html;

use dliLib\Html\Element;
use dliLib\Html\Form\Element as FormElement;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Request;

class AjaxForm extends Form
{
    protected $_ajaxSubmitText      = null;
    protected $_ajaxDoneText        = null;
    protected $_ajaxErrorText        = null;
    protected $_jsonResponseData    = [];
    protected $_formIdentifier      = null;

    protected $_onSuccessEchoSelf   = false;

    /**
     * @type SubForm[]
     */
    protected $_subForms = [];

    public function useJsValidation($bool) {
        $this->_useJsValidation = $bool;
    }

    public function setAjaxSubmitText($text) {
        $this->_ajaxSubmitText = $text;
    }

    public function setAjaxDoneText($text) {
        $this->_ajaxDoneText = $text;
    }

    public function setAjaxErrorText($text) {
        $this->_ajaxErrorText = $text;
    }

    public function addJsonResponseData($section, $data, $appendIfExists = true) {
        if($appendIfExists && array_key_exists($this->_jsonResponseData, $section)) {
            $this->_jsonResponseData[$section] = $data;
        }
        else {
            $this->_jsonResponseData[$section] = $data;
        }
    }

    /**
     * Utility function that calls
     * isSubmitted -> populate -> validate -> store
     *
     * If form is using ajax and the form is stored execution is halted and reply returned
     * else true is returned if form was stored, else false
     *
     * @return bool
     */
    public function process() {
        if(parent::process()) {
            header('Content-Type: text/html');
            echo (string)$this;
            exit;
        }
        return false;
    }


    /**
     * Validate all form elements
     *
     * Form should be populated first
     * Returns json encoded response with errors if validation fails and halts execution
     *
     * @return bool
     */
    public function validate() {
        if(!parent::validate()) {
            header('Content-Type: application/json');
            echo json_encode(['errors' => $this->_errors]);
            exit(0);
        }
        return true;
    }

    /**
     * Used to store submitted form data.
     *
     * If a callback has been set using setStoreDataCallbackFunction() a call to store() will
     * trigger the callback so that can handle the storing of data.
     */
    public function store() {
        if ($this->_storeDataCallbackFunction) {
            call_user_func($this->_storeDataCallbackFunction, $this);
        }

        header('Content-Type: text/html');
        echo (string)$this;
        exit(0);
    }

    public function getCloseTag()
    {
        $submitHandler = '';
        $jsValidatorName = $this->getAttribute('id').'validator';

        $action = $this->getAttribute('action');
        if(!$action) {
            /*$action = 'http';
            if (Request::isSSL()) {$action .= "s";}
            $action .= "://";
            if ((!Request::isSSL() && $_SERVER["SERVER_PORT"] != "80") ||
                (Request::isSSL() && $_SERVER["SERVER_PORT"] != "443")) {
                $action .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
            } else {
                $action .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
            }*/

            $action = osc_base_url() . substr($_SERVER["REQUEST_URI"], 1);

            if(Request::isAdmin()) {
                $action = str_ireplace('page=plugins', 'page=ajax', $action);
                $action = str_ireplace('action=renderplugin', 'action=custom', $action);
            }
            else {
                $action = str_ireplace('page=custom', 'page=ajax&action=custom', $action);
            }
        }

        $submitHandler .= '
                var url = "'.$action.'";
                var loaderOverlay = null;

                $.ajax({
                        type: "POST",
                        url: url,
                        data: $(form).serialize(),
                        beforeSend: function() {
                            $(form).waitMe({effect: "bounce", text: "'.htmlentities($this->_ajaxSubmitText).'", bg: "rgba(255,255,255,0.7)"});
                        },
                        complete: function() {
                            $(".waitMe_progress", form).hide();                                  
                        },
                        success: function(data)
                        {                        
                            try {
                                if (typeof data === "object") {
                                    if("errors" in data) {
                                        $(".waitMe_text", form).html("<strong style=\"color: red\">'.htmlentities($this->_ajaxErrorText).'</strong>");
                                        $(".waitMe_text", form).addClass("animated fadeIn");
    
                                        setTimeout(function(){
                                            $(".waitMe", form).addClass("animated fadeOut");
                                            $(".waitMe_text", form).addClass("animated zoomOut");
                                            setTimeout(function(){
                                                $(form).waitMe("hide");
                                            }, 500);
                                        }, 2000);
                                        '.$jsValidatorName.'.showErrors(data.errors);
                                    }
                                    else {
                                        $(".waitMe_text", form).html("'.htmlentities($this->_ajaxDoneText).'");
                                        $(".waitMe_text", form).addClass("animated fadeIn");
    
                                        setTimeout(function(){
                                            $(".waitMe", form).addClass("animated fadeOut");
                                            $(".waitMe_text", form).addClass("animated zoomOut");
                                            setTimeout(function(){
                                                $(form).waitMe("hide");
                                            }, 500);
                                        }, 800);
                                    }
                                    
                                    if("contents" in data) {
                                        for (index = 0; index < data.contents.length; ++index) {                                        
                                            var contents = data.contents[index];
                                            $(form).replaceWith(contents.content);
                                        }                                                                        
                                    }
                                }
                                else {
                                    if(data !== "") {
                                        $(form).replaceWith(data);
                                    }
                                }
                            } catch (e) {       
                                // not json
                                
                            }                                                                                    
                        },
                        error: function(data) {
                            $(".waitMe_text", form).html("'.htmlentities($this->_ajaxErrorText).'");
                            $(".waitMe_text", form).addClass("animated fadeIn");

                            setTimeout(function(){
                                $(".waitMe", form).addClass("animated fadeOut");
                                $(".waitMe_text", form).addClass("animated zoomOut");
                                setTimeout(function(){
                                    $(form).waitMe("hide");
                                }, 800);
                            }, 2000);
                        }
                });';

        $this->_useJsValidation = true;
        $html = parent::getCloseTag();
        $html = str_replace('form.submit();', $submitHandler, $html);
        return $html;
    }
}
