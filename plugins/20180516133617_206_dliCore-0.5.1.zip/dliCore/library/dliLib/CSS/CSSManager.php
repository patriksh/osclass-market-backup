<?php
namespace dliLib\CSS;

use dliLib\Html\Fragment;
use dliLib\Singleton;

/**
 * Class CSSManager
 *
 * Manages css files and small css snippets in the "free" and allows for them to be grouped at a given location
 *
 * @package dliLib\JS
 */
class CSSManager extends Singleton
{
    private $_styles        = [];
    private $_cssFiles      = [];

    /**
     * Registers a style snippet to a given location
     * @param string|Fragment $style
     * @param null $name
     */
    public function registerStyle($style, $name = null) {
        if ($name) {
            $this->_styles[$name]   = $style;
        } else {
            $this->_styles[]        = $style;
        }
    }

    /**
     * Registers a css file
     * @param string|Fragment $cssFile
     * @param null $name
     */
    public function registerCSSFile($cssFile, $name = null) {
        if ($name) {
            $this->_cssFiles[$name]   = $cssFile;
        } else {
            $this->_cssFiles[]        = $cssFile;
        }
    }

    /**
     * Returns string with link and style tags
     * @return string
     * @throws \Exception
     */
    public function getStyles() {
        $styles     = '';
        $cssFiles   = '';
        foreach($this->_styles as $css) {
            if($css instanceof Fragment) {
                $css = $css->render(false);
                $css = str_replace('</style>', '', str_replace('<style>', '', $css));
            }
            $styles .= $css;
        }

        foreach($this->_cssFiles as $cssFile) {
            $cssFiles .= '<link href="' . osc_apply_filter('style_url', $cssFile) . '" rel="stylesheet" type="text/css" />' . PHP_EOL;
        }

        return $cssFiles . '<style>' . $styles . '</style>';
    }
}

?>