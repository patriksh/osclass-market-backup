<?php
namespace dliLib\Cache;

/**
 * Class NullCache
 *
 * Caching backend that never stores or retrieves any values.
 * This enables plugins to be coded like there will always be a caching backend available and don't have to check
 * each time they wish to retrieve a value etc.
 *
 * @package dliLib\Cache
 */
class NullCache extends AbstractCache {
    protected $_name = 'None';

    protected function _fetch($key) {
        return false;
    }

    protected function _store($key,$data,$ttl) {
        return true;
    }

    protected function _delete($key) {
        return true;
    }

    protected function _flush() {
        return true;
    }
}