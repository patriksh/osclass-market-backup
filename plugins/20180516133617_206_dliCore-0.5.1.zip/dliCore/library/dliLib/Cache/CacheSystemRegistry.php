<?php
namespace dliLib\Cache;

use dliLib\AbstractObjectRegistry;

/**
 * Registry of Caching back ends
 *
 * @author danlil
 *
 */
class CacheSystemRegistry extends AbstractObjectRegistry
{
    protected $_acceptedObjectClasses = array('dliLib\Cache\AbstractCache');
}

?>