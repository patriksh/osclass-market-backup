<?php
namespace dliLib\Cache;

use dliLib\dliString;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Preference\StringPreference;
class MemCache extends AbstractCache {
    protected $_name = 'MemCache';

    // Memcache object
    /***
     * @var \Memcache
     */
    public  $_memcache;

    public function __construct() {
        // Register default preferences for cache and tie them to the core plugin so they are removed if the core plugin is uninstalled
        $memcacheServerPref = new StringPreference(PluginManager::getInstance()->getCorePlugin(), 'cacheManagerMemCacheServer', 'localhost:11211', 'Server address');
        $this->registerPreference($memcacheServerPref);
    }

    protected function _init() {
        if(!$this->getPreference('cacheManagerMemCacheServer')) {
            throw new \Exception('No MemCache server address set');
        }
        else {
            $serverAddress = new dliString($this->getPreference('cacheManagerMemCacheServer')->getValue());
            if($serverAddress->isValidIpAddressWithPort() || $serverAddress->isValid952HostnameWithPort()) {
                $this->_memcache = new \Memcache();

                $serverAddress = explode(':', $serverAddress);

                if(isset($serverAddress[1])) {
                    $this->_memcache->addserver($serverAddress[0], $serverAddress[1]);
                }
                else {
                    $this->_memcache->addserver($serverAddress[0]);
                }
            }
            else {
                throw new \Exception('Invalid Memcache server address');
            }
        }
    }

    protected function _store($key, $data, $ttl) {
        return $this->_memcache->set($key, $data, 0, $ttl);
    }

    protected function _fetch($key) {
        return $this->_memcache->get($key);
    }

    protected function _delete($key) {
        return $this->_memcache->delete($key);
    }

    protected function _flush() {
        return $this->_memcache->flush();
    }

    public function addServer($host, $port = 11211, $weight = 10) {
        $this->_memcache->addserver($host, $port, true, $weight);
    }

    public function isSupported()
    {
        if (!class_exists('Memcache') ) {
            return false;
        }
        return true;
    }
}
