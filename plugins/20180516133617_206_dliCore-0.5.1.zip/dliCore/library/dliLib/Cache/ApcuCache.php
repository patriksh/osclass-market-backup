<?php
namespace dliLib\Cache;
use dliLib\Html\AjaxForm;
use dliLib\Html\Element\A;
use dliLib\Plugin\Route\AbstractRoute;

/**
 * Class ApcuCache
 *
 * @package dliLib\Cache
 */
class ApcuCache extends AbstractCache {
    protected $_name = 'APCu Cache';

    protected function _fetch($key) {
        return apcu_fetch(WEB_PATH.$key);
    }

    protected function _store($key,$data,$ttl) {
        return apcu_store(WEB_PATH.$key,$data,$ttl);
    }

    protected function _delete($key) {
        return apcu_delete(WEB_PATH.$key);
    }

    protected function _flush() {
        return apcu_clear_cache();
    }

    public function isSupported()
    {
        if (!extension_loaded('apcu')) {
            return false;
        }
        return true;
    }

    public function getConfigForm() {
        if($this->isSupported() === false) {
            return null;
        }

        $cacheSystemConfigForm = new AjaxForm(str_replace(' ', '', $this->_name));
        $cacheSystemConfigForm->setTitle($this->_name);
        $cacheSystemConfigForm->setAjaxSubmitText(sprintf(__('Saving %s settings...', 'dliCore'), $this->_name));
        $cacheSystemConfigForm->setAjaxDoneText(sprintf(__('%s settings Saved', 'dliCore'), $this->_name));
        $cacheSystemConfigForm->setAjaxErrorText(sprintf(__('An error occurred while saving %s settings', 'dliCore'), $this->_name));

        $flushButton = new A(null, sprintf(__('Flush %s', 'dliCore'), $this->_name), AbstractRoute::getRoute('dliCore', 'Cache', 'flush')->getUrl(['cache' => static::class]));
        $flushButton->setAttribute('class', 'btn btn-red');
        $flushButton->setAttribute('style', 'position: relative; top: -30px; left: 200px;; margin-bottom: 10px;');
        $cacheSystemConfigForm->addChild($flushButton);

        return $cacheSystemConfigForm;
    }

    public function getConfigSubForm() {
        return parent::getConfigForm();
    }
}