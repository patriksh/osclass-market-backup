<?php
namespace dliLib\Cache;

use dliLib\Cache\Interfaces\MultiCacheMember;
use dliLib\Html\AjaxForm;
use dliLib\Html\Form;
use dliLib\Html\Form\Element\Preference as PreferenceElement;
use dliLib\Plugin\Preference\SelectPreference;
use dliLib\Singleton;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Preference\BooleanPreference;
use dliLib\Plugin\Preference\AbstractPreference;
use ReflectionClass;

/**
 * Class CacheManager
 *
 * Used as gateway to cache back ends. External plugins can register new cache back ends here and they will be available
 * to every plugin using dliCore.
 *
 * @package dliLib\Cache
 */
class CacheManager extends Singleton
{
    /**
     * @type CacheSystemRegistry|null
     */
    private $_cacheSystems              = null;
    /**
     * @type AbstractCache
     */
    private $_cache                     = null;
    /**
     * If true the NullCache will be used instead of throwing exceptions when a caching backend fails.
     *
     * @type bool
     */
    private $_defaultToNullCacheOnError = false;
    /**
     * @type \dliLib\Plugin\Preference\AbstractPreference[]
     */
    private $_preferences               = [];

    private $_keys                      = [];

    private $_debug                     = false;
    private $_debugObjects              = [];

    private $_logHits                   = false;
    private $_log                       = [];

    /**
     * @throws \Exception
     */
    protected function __construct() {
        $this->_cacheSystems = new CacheSystemRegistry();

        /* Register default cache systems */
        $this->registerCacheSystem('dliLib\Cache\NullCache', 'dliLib\Cache\NullCache');
        $this->registerCacheSystem('dliLib\Cache\FileCache', 'dliLib\Cache\FileCache');
        $this->registerCacheSystem('dliLib\Cache\ApcCache', 'dliLib\Cache\ApcCache');
        $this->registerCacheSystem('dliLib\Cache\ApcuCache', 'dliLib\Cache\ApcuCache');
        $this->registerCacheSystem('dliLib\Cache\MemCache', 'dliLib\Cache\MemCache');

        /* Caching preferences */
        $defaultToNullCacheOnErrorPref  = new BooleanPreference(PluginManager::getInstance()->getCorePlugin(), 'cacheManagerDefaultToNullCacheOnError', true, 'Suppress errors');

        foreach($this->getAllCacheSystems() as $cacheSystem) {
            if($cacheSystem->isSupported()) {
                $validValues[$cacheSystem->getName()] = get_class($cacheSystem);
            }
        }

        $cacheManagerCachePref = new SelectPreference(PluginManager::getInstance()->getCorePlugin(), 'cacheManagerCache', 'dliLib\Cache\NullCache', $validValues, __('Current cache', 'dliCore'));
        $this->registerPreference($defaultToNullCacheOnErrorPref);
        $this->registerPreference($cacheManagerCachePref);

        if(!$defaultToNullCacheOnErrorPref) {
            $this->_defaultToNullCacheOnError = false;
        }
        else {
            $this->_defaultToNullCacheOnError = $defaultToNullCacheOnErrorPref->getValue();
        }

        if(!$cacheManagerCachePref) {
            $this->_initNullOrThrowException('No cache system configured');
        }
        else {
            $cacheName = $cacheManagerCachePref->getValue();

            try {
                $this->_cache = $this->getCacheSystem($cacheName);

                if(!$this->_cache) {
                    throw new \Exception($cacheName . ' is not a valid cache system');
                }
            }
            catch(\Exception $e) {
                $this->_initNullOrThrowException($e->getMessage());
            }
        }
    }

    public function __destruct()
    {
        if ($this->_logHits) {
            $output = '';
            $hits = 0;
            $misses = 0;
            foreach ($this->_log as $name => $data) {
                $output .= $name . ': ' . $data['hits'] . ' hits ' . ($data['misses'] ? '/ ' . $data['misses'] . ' misses<br/>' : '<br/>');
                $hits += $data['hits'];
                $misses += ($data['misses'] ? $data['misses'] : 0);
            }
            echo "CacheManager:    Hits: " . $hits . " Misses: " . $misses . " <br/>";
            echo $output;
        }
    }

    public function enableDebug() {
        $this->_debug = true;
    }

    public function addDebugObject(&$object, $name) {
        $this->_debugObjects[spl_object_hash($object)] = $name;
    }

    public function enableLogging() {
        $this->_logHits = true;
    }

    public function disableLogging() {
        $this->_logHits = false;
    }

    /**
     * @param AbstractPreference $preference
     */
    public function registerPreference(AbstractPreference &$preference) {
        $this->_preferences[$preference->getName()] = $preference;
    }

    /**
     * @param $name
     * @return null
     */
    public function &getPreference($name) {
        if(!isset($this->_preferences[$name])) {
            return null;
        }
        else {
            return $this->_preferences[$name];
        }
    }

    /**
     * @return array
     */
    public function &getAllPreferences() {
        return $this->_preferences;
    }

    /**
     * @param $message
     * @throws \Exception
     */
    private function _initNullOrThrowException($message) {
        if($this->_defaultToNullCacheOnError) {
            $this->_cache = new NullCache();
        }
        else {
            throw new \Exception($message);
        }
    }

    /**
     * @param string|\dliLib\Cache\AbstractCache $class
     * @param string $name
     * @throws \Exception
     */
    public function registerCacheSystem($class, $name) {
        $this->_cacheSystems->register($class, $name);
    }

    /**
     * @param string $name
     * @return null
     * @throws \Exception
     */
    public function getCacheSystem($name) {
        return $this->_cacheSystems->get($name);
    }

    /**
     * @return \dliLib\Cache\AbstractCache[]
     */
    public function getAllCacheSystems() {
        return $this->_cacheSystems->getAll();
    }

    /**
     * Fetches a cached value by key
     * @param $key
     * @return mixed
     */
    public function fetch($key) {
        if($this->_logHits) {
            $res = $this->_cache->fetch($key);

            if(!key_exists($key, $this->_log)) {
                $this->_log[$key] = ['hits' => 0, 'misses' => 0];
            }

            if($res === false) {
                $this->_log[$key]['misses'] += 1;
            }
            else {
                $this->_log[$key]['hits'] += 1;
            }
            return $res;
        }
        else {
            return $this->_cache->fetch($key);
        }
    }

    // @todo: Why do I clone data here? Save Reflection class for later use and perhaps keep one global instance of phpDocumentor

    /**
     * Removes data tagged with nocache from objects
     *
     * @param $data
     * @throws \ReflectionException
     */
    private function _removeNoCacheData(&$data) {
        if(is_object($data)) {
            $data = clone($data);
            $dataRef = new ReflectionClass($data);
            foreach($dataRef->getProperties() as $prop) {
                $docStr = $prop->getDocComment();
                if ($docStr) {
                    try {
                        $docBlockFactory = \phpDocumentor\Reflection\DocBlockFactory::createInstance();
                        $docBlock = $docBlockFactory->create($docStr);
                    } catch (\Exception $e) {
                        $docBlock = null;
                    }

                    if ($docBlock) {
                        if($docBlock->getTagsByName('nocache')) {
                            $isAccessible = $prop->isPublic();
                            if (!$isAccessible) {
                                $prop->setAccessible(true);
                            }

                            $defaults = $dataRef->getDefaultProperties();
                            $prop->setValue($data, $defaults[$prop->getName()]);

                            if (!$isAccessible) {
                                $prop->setAccessible(false);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Stores a cached value and ties it to a key
     *
     * @param $key
     * @param $data
     * @param int $ttl
     * @return mixed
     */
    public function store($key, $data, $ttl = 3600) {
        if(is_array($data)) {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveArrayIterator($data),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($iterator as $member) {
                if(is_object($member)) {
                    $member = clone($member);
                    $this->_removeNoCacheData($member);
                }
            }
        }
        elseif($data instanceof MultiCacheMember) {
            if(is_object($data)) {
                $member = clone($data);
                $this->_removeNoCacheData($member);
            }
        }

        // If object check for nocache directives
        /*if(is_object($data)) {
            $data = clone($data);
            $dataRef = new ReflectionClass($data);
            foreach($dataRef->getProperties() as $prop) {
                $docStr = $prop->getDocComment();
                if ($docStr) {
                    try {
                        $docBlockFactory = \phpDocumentor\Reflection\DocBlockFactory::createInstance();
                        $docBlock = $docBlockFactory->create($docStr);
                    } catch (\Exception $e) {
                        $docBlock = null;
                    }

                    if ($docBlock) {
                        if($docBlock->getTagsByName('nocache')) {
                            $isAccessible = $prop->isPublic();
                            if (!$isAccessible) {
                                $prop->setAccessible(true);
                            }

                            $defaults = $dataRef->getDefaultProperties();
                            $prop->setValue($data, $defaults[$prop->getName()]);

                            if (!$isAccessible) {
                                $prop->setAccessible(false);
                            }
                        }
                    }
                }
            }
        }*/

        $result = $this->_cache->store($key, $data, $ttl);
        if($result) {
            if(is_array($data)) {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveArrayIterator($data),
                    \RecursiveIteratorIterator::SELF_FIRST
                );
                foreach ($iterator as $member) {
                    if($member instanceof MultiCacheMember) {
                        $this->_tieMemberToCache($member, $key);
                    }
                }
            }
            elseif($data instanceof MultiCacheMember) {
                $this->_tieMemberToCache($data, $key);
            }
        }

        return $result;
    }

    public function getCachesMemberOf(MultiCacheMember $member) {
        $memberUid = $member->getUid();
        $memberCacheListKey = get_class($member).'_'.(is_array($memberUid) ? implode(':', $memberUid) : $memberUid).'CacheMemoryList';

        $cacheMemoryList = $this->fetch($memberCacheListKey);

        if(!$cacheMemoryList) {
            $cacheMemoryList = [];
        }

        return $cacheMemoryList;
    }

    /**
     * Keep track of which caches a model is a member of
     *
     * @param MultiCacheMember $member
     * @param $cacheKey
     */
    protected function _tieMemberToCache(MultiCacheMember $member, $cacheKey) {
        // Members list of caches
        $memberUid = $member->getUid();
        $memberCacheListKey = get_class($member).'_'.(is_array($memberUid) ? implode(':', $memberUid) : $memberUid).'CacheMemoryList';

        $cacheMemoryList = $this->fetch($memberCacheListKey);

        if(!$cacheMemoryList) {
            $cacheMemoryList = [];
        }
        if(isset($cacheMemoryList[$cacheKey])) {
            return;
        }
        $cacheMemoryList[$cacheKey] = $cacheKey;

        if(array_key_exists(spl_object_hash($member), $this->_debugObjects)) {
            echo "Tying object: <strong>" . $this->_debugObjects[spl_object_hash($member)] . "</strong><br/>Cache key: <strong>{$cacheKey}</strong><br/>Member Cache list key: <strong>{$memberCacheListKey}</strong><br/><br/>";
        }

        $this->store($memberCacheListKey, $cacheMemoryList);

        // Cache members
        /*$cacheMembersKey = $cacheKey.'CacheMembers';
        $cacheMembers = $this->fetch($cacheMembersKey);
        if(!$cacheMembers) {
            $cacheMembers = [];
        }
        $cacheMembers[$memberCacheListKey] = $memberCacheListKey;
        static $i = 0;
        if(++$i == 500) {
            var_dump($cacheMembers);
        }
        $this->store($cacheMembersKey, $cacheMembers);*/
    }
    
    public function invalidateAllCachesWithMember(MultiCacheMember $member) {
        $memberUid = $member->getUid();
        $memberCacheListKey = get_class($member).'_'.(is_array($memberUid) ? implode(':', $memberUid) : $memberUid).'CacheMemoryList';

        $memberCacheList = $this->fetch($memberCacheListKey);
        if(!$memberCacheList) {
            $memberCacheList = [];
        }

        foreach($memberCacheList as $cache) {
            if(array_key_exists(spl_object_hash($member), $this->_debugObjects)) {
                echo "Invalidating cache: <strong>{$cache}</strong><br/>Object: <strong>" . $this->_debugObjects[spl_object_hash($member)] . "</strong><br/>Throuch cachelist key: <strong>{$memberCacheListKey}</strong><br/><br/>";
            }
            $this->delete($cache);
        }
        $this->delete($memberCacheListKey);
    }

    /**
     * Deletes a stored value by key
     *
     * @param $key
     * @return mixed
     */
    public function delete($key) {
        return $this->_cache->delete($key);
    }

    /**
     * Flushes the cache
     */
    public function flush() {
        return $this->_cache->flush();
    }

    /**
     * Returns a SubForm containing the configuration options of the CacheManager
     * @return AjaxForm
     * @throws \Exception
     */
    public function getConfigForm() {
        // Create form
        $cacheManagerForm = new AjaxForm('cacheManagerForm');
        $cacheManagerForm->setTitle(__('Cache Manager', 'dliCore'));
        $cacheManagerForm->setAjaxSubmitText(__('Saving settings...', 'dliCore'));
        $cacheManagerForm->setAjaxDoneText(__('Settings Saved', 'dliCore'));
        $cacheManagerForm->setAjaxErrorText(__('An error occurred while saving settings', 'dliCore'));

        foreach($this->getAllPreferences() as $cacheManagerPreference) {
            $prefElement = new PreferenceElement($cacheManagerPreference);
            $prefElement->setLabel($cacheManagerPreference->getTitle());

            $cacheManagerForm->addChild($prefElement);
        }
        $cacheManagerForm->addChild(new Form\Element\Submit(null, __('Save Settings', 'dliCore')));
        $cacheManagerForm->setStoreDataCallbackFunction([$this, '_storeConfigForm']);

        return $cacheManagerForm;
    }

    public function _storeConfigForm($form) {
        foreach($form->getAllFormElements() as $element) {
            if($element instanceof Form\Element\Preference) {
                $element->storeValue();
            }
        }

        $this->flush();
    }
}