<?php
namespace dliLib\Cache;

use dliLib\Html\Form\Element\Preference;
use dliLib\IO\FileSystem;
use dliLib\Plugin\Preference\StringPreference;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\dliString;
use dliLib\Validator\WritableFolder;

/**
 * Class FileCache
 *
 * Caching backend to store cached values in files
 *
 * @package dliLib\Cache
 */
class FileCache extends AbstractCache {
    protected $_name = 'File Cache';

    private $_cacheStorageLocation = null;

    public function __construct($cacheStorageLocation = null) {
        // Register default preferences for cache and tie them to the core plugin so they are removed if the core plugin is uninstalled
        $fileCacheStorageLocationPref = new StringPreference(PluginManager::getInstance()->getCorePlugin(), 'cacheManagerFileCacheStorageLocation', PluginManager::getInstance()->getCorePlugin()->getTempDir('cache'), __('Cache files location', 'dliCore'));
        $this->registerPreference($fileCacheStorageLocationPref);

        $this->_cacheStorageLocation = $cacheStorageLocation;
    }

    protected function _init() {
        $fileCacheStorageLocationPref = null;

        $this->_cacheStorageLocation = FileSystem::normalisePath($this->_cacheStorageLocation);

        if(!$this->_cacheStorageLocation) {
            $fileCacheStorageLocationPref = $this->getPreference('cacheManagerFileCacheStorageLocation');
            if(!$fileCacheStorageLocationPref) {
                throw new \Exception('No FileCache storage location set');
            }

            $this->_cacheStorageLocation = $fileCacheStorageLocationPref->getValue();
        }

        $path = new dliString($this->_cacheStorageLocation);
        if(!$path->endsWith(DIRECTORY_SEPARATOR)) {
            $this->_cacheStorageLocation .= DIRECTORY_SEPARATOR;
        }

        $this->_cacheStorageLocation .= 'dliCoreCache' . DIRECTORY_SEPARATOR;

        if(FileSystem::dirExists($this->_cacheStorageLocation) && FileSystem::isWritable($this->_cacheStorageLocation)) {
            return;
        }
        else {
            // If folder does not exist we try to create it
            $path = new dliString($this->_cacheStorageLocation);
            $pathPieces = explode(DIRECTORY_SEPARATOR, $path);

            $path = '';

            foreach($pathPieces as $pathPiece) {
                $path .= $pathPiece . DIRECTORY_SEPARATOR;
                if(!FileSystem::dirExists($path)) {
                    $this->_createAndProtectFolder($path);
                }
            }

            if(FileSystem::isWritable($this->_cacheStorageLocation)) {
                return;
            }
            else {
                throw new \Exception('FileCache storage location is not writable');
            }
        }
    }

    private function _createAndProtectFolder($folder) {
        $success = mkdir($folder);

        if(!$success) {
            throw new \Exception('Unable to create storage location ' . $folder);
        }

        file_put_contents($folder.DIRECTORY_SEPARATOR.'.htaccess', 'Deny from all', LOCK_EX);
    }

    protected function _store($key, $data, $ttl) {
        // Opening the file in read/write mode
        $h = fopen($this->_getFileName($key),'a+');

        if (!$h) {
            return false;
        }

        flock($h,LOCK_EX); // exclusive lock, will get released when the file is closed

        fseek($h,0); // go to the beginning of the file

        // truncate the file
        ftruncate($h,0);

        // Serializing along with the TTL
        $data = serialize(array(time()+$ttl,$data));
        if (fwrite($h,$data)===false) {
            return false;
        }
        fclose($h);

        return true;
    }

    private function _getFileName($key) {
        return $this->_cacheStorageLocation . md5($key) . '.cache';
    }

    protected function _fetch($key) {
        $filename = $this->_getFileName($key);
        if (!file_exists($filename)) return false;
        $h = fopen($filename,'r');

        if (!$h) {
            return false;
        }

        // Getting a shared lock
        flock($h,LOCK_SH);

        //$data = fread($h, filesize($filename));
        $data = file_get_contents($filename);
        fclose($h);

        $data = @unserialize($data);
        if (!$data) {
            // If unserializing somehow didn't work out, we'll delete the file
            unlink($filename);
            return false;
        }

        if (time() > $data[0]) {
            // Unlinking when the file was expired
            unlink($filename);
            return false;
        }
        return $data[1];
    }

    protected function _delete($key) {
        $filename = $this->_getFileName($key);
        if (FileSystem::fileExists($filename)) {
            return unlink($filename);
        } else {
            return false;
        }
    }

    public function _flush() {
        $leave_files = array('.htaccess', 'index.php');

        foreach(glob($this->_cacheStorageLocation . '*.cache') as $file) {
            if(!in_array(basename($file), $leave_files) ) {
                @unlink($file);
            }
        }
    }

    public function getConfigSubForm() {
        $cacheSystemConfigForm = parent::getConfigForm();
        if($cacheSystemConfigForm) {
            $cacheSystemConfigForm->getFormElementByName('cacheManagerFileCacheStorageLocation')->addValidator(new WritableFolder());
        }
        return $cacheSystemConfigForm;
    }

    /**
     * Overriden storage function to make sure the FileCache can flush
     * @param $form
     * @throws \Exception
     */
    public function _storeConfigForm($form) {
        foreach($form->getAllFormElements() as $element) {
            if($element instanceof Preference) {
                if($element->getAttribute('id') == 'cacheManagerFileCacheStorageLocation' && $element->isValueChanged()) {
                    // Flush and remove the old cache folder
                    $this->flush();
                    FileSystem::deleteDir($this->_cacheStorageLocation);
                }
                $element->storeValue();
            }
        }
    }
}