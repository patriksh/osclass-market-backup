<?php
namespace dliLib\Cache;

/**
 * Class ApcCache
 *
 * @package dliLib\Cache
 */
class ApcCache extends AbstractCache {
    protected $_name = 'APC Cache';

    protected function _fetch($key) {
        return apc_fetch(WEB_PATH.$key);
    }

    protected function _store($key,$data,$ttl) {
        return apc_store(WEB_PATH.$key,$data,$ttl);
    }

    protected function _delete($key) {
        return apc_delete(WEB_PATH.$key);
    }

    protected function _flush() {
        return apc_clear_cache('user');
    }

    public function isSupported()
    {
        if (!extension_loaded('apc') || ini_get('apc.enabled') != "1") {
            return false;
        }
        return true;
    }
}