<?php
namespace dliLib\Cache\Interfaces;


/***
 * Enables the CachingManager to keep track of multiple caches an object might be part of and invalidate all of them when
 * needed.
 *
 * Interface MultiCacheMember
 * @package dliLib\Cache\Interfaces
 */
interface MultiCacheMember
{
    /**
     * Returns a unique identification for the given object
     * @return mixed
     */
    public function getUid();
}