<?php
namespace dliLib\Cache;

use dliLib\Html\AjaxForm;
use dliLib\Html\Element\A;
use dliLib\Html\Form;
use dliLib\Plugin\Preference\AbstractPreference;
use dliLib\Html\Form\Element\Preference as PreferenceElement;
use dliLib\Plugin\Route\AbstractRoute;

/**
 * Class AbstractCache
 *
 * Base class for cache back ends
 * A cache back end registers his own preferences. But it should be done to 'dliCore' if the cache is supposed to have
 * its preferences removed if dliCore is uninstalled.
 *
 * @package dliLib\Cache
 */
abstract class AbstractCache {
    protected $_name        = null;
    protected $_preferences = array();
    protected $_initialized = false;

    static private $_corePlugin  = null;

    public function getName() {
        if($this->_name) {
            return $this->_name;
        }
        else {
            return static::class;
        }
    }

    public function registerPreference(AbstractPreference &$preference) {
        $this->_preferences[$preference->getName()] = $preference;
    }

    public function &getPreference($name) {
        if(!isset($this->_preferences[$name])) {
            return null;
        }
        else {
            return $this->_preferences[$name];
        }
    }

    public function &getAllPreferences() {
        return $this->_preferences;
    }

    /***
     * Function to handle needed initialzation of cache system. Like connecting to servers, creating folders etc.
     *
     *  Donm't do this in the constructor since doing it here allows us to only do it when needed
     */
    protected function _init() {

    }

    public function fetch($key) {
        if(!$this->_initialized) {
            $this->_init();
            $this->_initialized = true;
        }
        return $this->_fetch($key);
    }

    public function store($key, $data, $ttl) {
        if(!$this->_initialized) {
            $this->_init();
            $this->_initialized = true;
        }
        return $this->_store($key, $data, $ttl);
    }

    public function delete($key) {
        if(!$this->_initialized) {
            $this->_init();
            $this->_initialized = true;
        }
        return $this->_delete($key);
    }

    public function flush() {
        if(!$this->_initialized) {
            $this->_init();
            $this->_initialized = true;
        }
        return $this->_flush();
    }

    public function getConfigForm() {
        if(!$this->_preferences || $this->isSupported() === false) {
            return null;
        }

        $cacheSystemConfigForm = new AjaxForm(str_replace(' ', '', $this->_name));
        $cacheSystemConfigForm->setTitle($this->_name);
        $cacheSystemConfigForm->setAjaxSubmitText(sprintf(__('Saving %s settings...', 'dliCore'), $this->_name));
        $cacheSystemConfigForm->setAjaxDoneText(sprintf(__('%s settings Saved', 'dliCore'), $this->_name));
        $cacheSystemConfigForm->setAjaxErrorText(sprintf(__('An error occurred while saving %s settings', 'dliCore'), $this->_name));

        $flushButton = new A(null, sprintf(__('Flush %s', 'dliCore'), $this->_name), AbstractRoute::getRoute('dliCore', 'Cache', 'flush')->getUrl(['cache' => static::class]));
        $flushButton->setAttribute('class', 'btn btn-red');
        $flushButton->setAttribute('style', 'position: relative; top: -30px; left: 200px;; margin-bottom: 10px;');
        $cacheSystemConfigForm->addChild($flushButton);

        foreach ($this->_preferences as $cacheSystemPreference) {
            $prefElement = new PreferenceElement($cacheSystemPreference);
            $prefElement->setLabel($cacheSystemPreference->getTitle());
            $cacheSystemConfigForm->addChild($prefElement);
        }

        $cacheSystemConfigForm->addChild(new Form\Element\Submit(null, sprintf(__('Save %s Settings', 'dliCore'), $this->_name)));
        $cacheSystemConfigForm->setStoreDataCallbackFunction([$this, '_storeConfigForm']);

        return $cacheSystemConfigForm;
    }

    public function _storeConfigForm($form) {
        foreach($form->getAllFormElements() as $element) {
            if($element instanceof Form\Element\Preference) {
                $element->storeValue();
            }
        }
    }

    public function isSupported() {
        return true;
    }

    abstract protected function _fetch($key);
    abstract protected function _store($key, $data, $ttl);
    abstract protected function _delete($key);
    abstract protected function _flush();
}
