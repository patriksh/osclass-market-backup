<?php
namespace dliLib\Cache;

use dliLib\dliString;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Preference\StringPreference;
class RedisCache extends AbstractCache {
    protected $_name = 'RedisCache';

    // Memcache object
    /***
     * @var \Memcache
     */
    public  $_redis;

    public function __construct() {
        // Register default preferences for cache and tie them to the core plugin so they are removed if the core plugin is uninstalled
        $memcacheServerPref = new StringPreference(PluginManager::getInstance()->getCorePlugin(), 'cacheManagerRedisServer', 'localhost:11211', 'Server address');
        $this->registerPreference($memcacheServerPref);
    }

    protected function _init() {
        if(!$this->getPreference('cacheManagerRedisServer')) {
            throw new \Exception('No Redis server address set');
        }
        else {
            $serverAddress = new dliString($this->getPreference('cacheManagerRedisServer')->getValue());
            if($serverAddress->isValidIpAddressWithPort() || $serverAddress->isValid952HostnameWithPort()) {
                $this->_redis = new \Redis();

                $serverAddress = explode(':', $serverAddress);

                if(isset($serverAddress[1])) {
                    $this->_redis->addserver($serverAddress[0], $serverAddress[1]);
                }
                else {
                    $this->_redis->addserver($serverAddress[0]);
                }
            }
            else {
                throw new \Exception('Invalid Redis server address');
            }
        }
    }

    protected function _store($key, $data, $ttl) {
        return $this->_redis->set($key, $data, 0, $ttl);
    }

    protected function _fetch($key) {
        return $this->_redis->get($key);
    }

    protected function _delete($key) {
        return $this->_redis->delete($key);
    }

    protected function _flush() {
        return $this->_redis->flush();
    }

    public function addServer($host, $port = 11211, $weight = 10) {
        $this->_redis->addserver($host, $port, true, $weight);
    }

    public function isSupported()
    {
        if (!class_exists('Memcache') ) {
            return false;
        }
        return true;
    }
}
