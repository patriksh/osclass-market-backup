<?php
namespace dliLib\Email;

use dliLib\AbstractObjectRegistry;

class EmailRegistry extends AbstractObjectRegistry
{
    protected $_acceptedObjectClasses = array('dliLib\Email\AbstractEmail');
}

?>