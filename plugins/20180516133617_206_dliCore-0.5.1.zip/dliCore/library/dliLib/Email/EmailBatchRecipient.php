<?php
namespace dliLib\Email;

use dliLib\Model\DbModel;

/**
 * Hold recipient information used by an EmailBatch
 *
 * @author danlil
 * @see EmailBatch
 */
class EmailBatchRecipient extends DbModel
{
    protected static $_dbTableClass = 'dliLib\Email\Table\EmailBatchRecipientTable';

    const RECIPIENT_TYPE_TO     = 1;
    const RECIPIENT_TYPE_CC     = 2;
    const RECIPIENT_TYPE_BCC    = 3;

    // Email data
    protected $_id            = null;
    protected $_batchId       = null;
    protected $_recipientType = EmailBatchRecipient::RECIPIENT_TYPE_TO;
    protected $_userId        = null;
    protected $_emailAddress  = null;
    protected $_recipientName = null;
    protected $_sent          = null;

    protected $_keywordData = array();

    public function getId()
    {
        return $this->_id;
    }

    public function setId($_id)
    {
        $this->_id = $_id;
        return $this;
    }

    public function getBatchId()
    {
        return $this->_batchId;
    }

    public function setBatchId($_batchId)
    {
        $this->_batchId = $_batchId;
        return $this;
    }

    public function getRecipientType()
    {
        return $this->_recipientType;
    }

    public function setRecipientType($_recipientType)
    {
        $this->_recipientType = $_recipientType;
        return $this;
    }

    public function getUserId()
    {
        return $this->_userId;
    }

    public function setUserId($_userId)
    {
        $this->_emailAddress    = null;
        $this->_userId          = $_userId;
        return $this;
    }

    public function getEmailAddress()
    {
        return $this->_emailAddress;
    }

    public function setEmailAddress($_emailAddress)
    {
        $this->_userId          = null;
        $this->_emailAddress    = $_emailAddress;
        return $this;
    }

    public function getRecipientName()
    {
        return $this->_recipientName;
    }

    public function setRecipientName($_recipientName)
    {
        $this->_recipientName = $_recipientName;
        return $this;
    }

    public function getSent()
    {
        return $this->_sent;
    }

    public function setSent($_sent)
    {
        $this->_sent = $_sent;
        return $this;
    }

    public function _afterLoad() {
        $this->_keywordData = EmailBatchRecipientKeyword::fetchAllFromEmailBatchRecipient($this);
    }

    public function getAllKeywordData() {
        return $this->_keywordData;
    }

    public function addKeywordData($name, $value) {
        foreach($this->_keywordData as $keywordData) {
            if($keywordData->getName() == $name) {
                $keywordData->setValue($value);
                //var_dump($this->_keywordData);
                return;
            }
        }

        $keywordData = new EmailBatchRecipientKeyword();
        $keywordData->setName($name)->setValue($value);
        $this->_keywordData[] = $keywordData;
    }

    protected function _afterSave() {
        // Save all the recipients
        foreach($this->_keywordData as $keywordData) {
            $keywordData->setRecipientId($this->getId());
            $keywordData->save();
        }
        //EmailBatchRecipientKeyword::saveBatch($this->_keywordData);
    }

    public static function fetchAllFromEmailBatch(EmailBatch &$emailBatch) {
        return static::_fetchAll(static::getDbTable()->selectConditions()->where('fk_i_batch_id', $emailBatch->getId()));
    }

    public static function deleteAllFromEmailBatch(EmailBatch &$emailBatch) {
        static::getDbTable()->delete(array('fk_i_batch_id' => $emailBatch->getId()));
    }
}