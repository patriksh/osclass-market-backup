<?php
namespace dliLib\Email;

use dliLib\dliString;
use dliLib\Model\DbModel;
class EmailAddress extends DbModel
{
    const STATUS_NOT_CHECKED                        = 0;
    const STATUS_INVALID_FORMAT                     = 1;
    const STATUS_BAD_MX_RECORD                      = 2;
    const STATUS_UNABLE_TO_CONNECT_TO_MAIL_SERVER   = 3;
    const STATUS_UNABLE_TO_VERIFY_MAILBOX           = 4;
    const STATUS_OK                                 = 10;

    protected static $_dbTableClass = 'dliLib\Email\Tables\EmailAddressStatusTable';

    protected $_email   = '';
    protected $_status  = EmailAddress::STATUS_NOT_CHECKED;
    protected $_checked = null;

    public function getEmail()
    {
        return $this->_email;
    }

    public function setEmail($_email)
    {
        $this->_email = $_email;
        return $this;
    }

    public function getStatus()
    {
        return $this->_status;
    }

    public function getChecked()
    {
        return $this->_checked;
    }


    public function validateEmail($verify = false) {
        $email = new dliString($this->_email);
        $this->_checked = date('Y-m-d H:m:s');
        $mailparts=explode("@",$email);
        $hostname = $mailparts[1];

        // validate email address syntax
        if(!$email->isValidEmailAddress()) {
            $this->_status = EmailAddress::STATUS_INVALID_FORMAT;
            return $this->_status;
        }

        // get mx addresses by getmxrr
        $b_mx_avail=getmxrr( $hostname, $mx_records, $mx_weight );
        $b_server_found=0;

        if(!$b_mx_avail) {
            $this->_status = EmailAddress::STATUS_BAD_MX_RECORD;
            return $this->_status;
        }

        if(count($mx_records) > 0 && $verify == false) {
            return true;
        }


        // copy mx records and weight into array $mxs
        $mxs=array();

        for($i=0;$i<count($mx_records);$i++){
            $mxs[$mx_records[$i]] = $mx_weight[$i];
        }

        // sort array mxs to get servers with highest prio
        //ksort ($mxs, SORT_NUMERIC );
        //reset ($mxs);
        arsort ($mxs );
        reset ($mxs);

        $connected = false;

        while (list ($mx_host, $mx_weight) = each ($mxs) ) {
            if($b_server_found == 0){
                //try connection on port 25
                $fp = @fsockopen($mx_host, 587, $errno, $errstr, 2);
                if($fp){
                    $connected = true;
                    $ms_resp="";
                    // say HELO to mailserver
                    $ms_resp.=$this->send_command($fp, "HELO microsoft.com");

                    // initialize sending mail
                    $ms_resp.=$this->send_command($fp, "MAIL FROM:<support@microsoft.com>");

                    // try receipent address, will return 250 when ok..
                    $rcpt_text=$this->send_command($fp, "RCPT TO:<".$email.">");
                    $ms_resp.=$rcpt_text;

                    if(substr( $rcpt_text, 0, 3) == "250")
                        $b_server_found=1;

                    // quit mail server connection
                    $ms_resp.=$this->send_command($fp, "QUIT");

                    fclose($fp);
                }
            }
        }

        if(!$connected && !$b_server_found) {
            $this->_status = EmailAddress::STATUS_UNABLE_TO_CONNECT_TO_MAIL_SERVER;
            return $this->_status;
        }
        else if(!$b_server_found) {
            $this->_status = EmailAddress::STATUS_UNABLE_TO_VERIFY_MAILBOX;
            return $this->_status;
        }
        else if($b_server_found) {
            $this->_status = EmailAddress::STATUS_OK;
            return $this->_status;
        }
    }

    protected function send_command($fp, $out){

        fwrite($fp, $out . "\r\n");
        return $this->get_data($fp);
    }

    protected function get_data($fp){
        $s="";
        stream_set_timeout($fp, 2);

        for($i=0;$i<2;$i++)
            $s.=fgets($fp, 1024);

            return $s;
    }

}

// support windows platforms
if (!function_exists ('getmxrr') ) {
    function getmxrr($hostname, &$mxhosts, &$mxweight) {
        if (!is_array ($mxhosts) ) {
            $mxhosts = array ();
        }

        if (!empty ($hostname) ) {
            $output = "";
            @exec ("nslookup.exe -type=MX $hostname.", $output);
            $imx=-1;

            foreach ($output as $line) {
                $imx++;
                $parts = "";
                if (preg_match ("/^$hostname\tMX preference = ([0-9]+), mail exchanger = (.*)$/", $line, $parts) ) {
                    $mxweight[$imx] = $parts[1];
                    $mxhosts[$imx] = $parts[2];
                }
            }
            return ($imx!=-1);
        }
        return false;
    }
}