<?php
namespace dliLib\Email;


/**
 * Class EmptyEmail
 *
 * @author danlil
 * @package dliLib\Email
 */
class OneTimeEmail extends AbstractEmail
{
    private $_title                 = "";
    private $_content               = "";
    protected $_breakOnInvalidTags  = false;
    protected $_isInstallable       = false;

    /**
     * Should return the internal Osclass description of the email.
     * @return string
     */
    protected function _getDescription()
    {
        return "";
    }

    public function setTitle($title) {
        $this->_title = $title;
    }

    /**
     * Should return the default title/subject of the email
     * @return string
     */
    protected function _getDefaultTitle()
    {
        return $this->_title;
    }

    public function setContent($content) {
        $this->_content = $content;

    }

    /**
     * Should return the default content/body of the email
     * @return string
     */
    protected function _getDefaultContent()
    {
        return $this->_content;
    }
}