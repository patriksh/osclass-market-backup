<?php
namespace dliLib\Email\Table;

use dliLib\Db\AbstractTable;
class EmailBatchTable extends AbstractTable
{
    protected $_tableName = 't_dli_core_email_batches';

    protected function _init() {
        $this->_struct =
        "CREATE TABLE IF NOT EXISTS /*TABLE_NAME*/ (
            pk_i_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            s_from VARCHAR(64) NOT NULL,
            s_from_name VARCHAR(64) NOT NULL,
            s_reply_to VARCHAR(64) NOT NULL,
            s_title VARCHAR(64) NOT NULL,
            s_content TEXT NOT NULL,
            s_attachement TEXT NOT NULL,
            i_batch_size INT NOT NULL,
            i_cool_down INT NOT NULL,
            dt_created DATETIME NOT NULL,
            dt_last_run DATETIME DEFAULT NULL,
            PRIMARY KEY (pk_i_id)
        ) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';";
    }
}