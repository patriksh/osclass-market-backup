<?php
namespace dliLib\Email\Table;

use dliLib\Db\AbstractTable;
use dliLib\Email\EmailBatchRecipient;
class EmailBatchRecipientTable extends AbstractTable
{
    protected $_tableName = 't_dli_core_email_batch_recipients';

    protected function _init() {
        $this->_struct =
        "CREATE TABLE IF NOT EXISTS /*TABLE_NAME*/ (
            pk_i_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            fk_i_batch_id INT UNSIGNED NOT NULL,
            i_recipient_type INT DEFAULT ".EmailBatchRecipient::RECIPIENT_TYPE_TO.",
            s_email_address VARCHAR(255) DEFAULT NULL,
            s_recipient_name VARCHAR(64) DEFAULT NULL,
            dt_sent DATETIME DEFAULT NULL,
            PRIMARY KEY (pk_i_id),
            INDEX (fk_i_batch_id),
            FOREIGN KEY (fk_i_batch_id) REFERENCES ".EmailBatchTable::getName()." (pk_i_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';";
    }
}