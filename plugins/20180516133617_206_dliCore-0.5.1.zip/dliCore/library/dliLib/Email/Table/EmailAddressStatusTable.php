<?php
namespace dliLib\Email\Table;

use dliLib\Db\AbstractTable;
class EmailAddressStatusTable extends AbstractTable
{
    protected $_tableName = 't_dli_core_email_address_statuses';

    protected function _init() {
        $this->_struct =
        "CREATE TABLE IF NOT EXISTS /*TABLE_NAME*/ (
            s_email_address VARCHAR(255) NOT NULL,
            i_status INT UNSIGNED DEFAULT NULL,
            dt_checked DATETIME NOT NULL,
            PRIMARY KEY (s_email_address)
        ) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';";
    }
}