<?php
namespace dliLib\Email\Table;

use dliLib\Db\AbstractTable;

/**
 * Holds recipient unique keywords
 *
 * @package dliLib\Email\Table
 */
class EmailBatchRecipientKeywordsTable extends AbstractTable
{
    protected $_tableName = 't_dli_core_email_batch_recipient_keywords';

    protected function _init() {
        $this->_struct =
        "CREATE TABLE IF NOT EXISTS /*TABLE_NAME*/ (
            fk_i_recipient_id INT UNSIGNED NOT NULL,
            s_name VARCHAR(64) NOT NULL,
            s_value VARCHAR(1024) DEFAULT NULL,
            PRIMARY KEY (fk_i_recipient_id, s_name),
            FOREIGN KEY (fk_i_recipient_id) REFERENCES ".EmailBatchRecipientTable::getName()." (pk_i_id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARACTER SET 'UTF8' COLLATE 'UTF8_GENERAL_CI';";
    }
}