<?php
namespace dliLib\Email;

use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Preference\StringPreference;

/**
 * Hold receipient information used by an EmailBatch
 *
 * @author danlil
 * @see EmailBatch
 */
class EmailManager
{
    /**
     * @var StringPreference
     */
    private $_errorToAddressPreference;

    public function __construct() {
        $plugin = PluginManager::getInstance()->getPlugin('dliCore');
        $this->_errorToAddressPreference = &$plugin->getPreference('emailErrorToAddress');
    }

    public function processBatches() {

    }
}