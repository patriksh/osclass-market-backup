<?php
namespace dliLib\Email;

use dliLib\Email\AbstractEmail;
use dliLib\Model\DbModel;
use dliLib\Email\EmailBatchRecipient;

/**
 * Throttles sending of email to multiple recipients
 * @author danlil
 *
 */
class EmailBatch extends DbModel
{
    protected static $_dbTableClass = 'dliLib\Email\Table\EmailBatchTable';

    // Email data
    protected $_id            = null;
    protected $_from          = '';
    protected $_fromName      = '';
    protected $_to            = '';
    protected $_toName        = '';
    protected $_cc            = '';
    protected $_ccName        = '';
    protected $_bcc           = '';
    protected $_bccName       = '';
    protected $_replyTo       = '';
    protected $_title         = '';
    protected $_content       = '';
    protected $_attachements  = '';

    /**
     * @var EmailBatchRecipient[]
     * @nocache
     */
    protected $_recipients    = [];

    /**
     * Number of emails to send each iteration
     * @var int
     */
    protected $_batchSize     = 50;

    /**
     * Minimum number of seconds between iterations
     * @var int
     */
    protected $_coolDown      = 30;
    protected $_created       = null;
    protected $_lastRun       = null;

    protected function _init() {
        if($this->_created == null) {
            $this->_created     = date('Y-m-d H:m:s');
        }
    }

    /**
     * Load all recipients connected to the batch
     * @see \dliLib\Model\DbModel::_afterLoad()
     */
    protected function _afterLoad() {
        $this->_recipients = EmailBatchRecipient::fetchAllFromEmailBatch($this);
    }

    /**
     * Selete all recipients connected to the batch
     * @see \dliLib\Model\DbModel::_beforeDelete()
     */
    protected function _beforeDelete() {
        EmailBatchRecipient::deleteAllFromEmailBatch($this);
    }

    public function getId() {
        return $this->_id;
    }

    public function setEmail(AbstractEmail $email) {
        $emailParams        = $email->_getEmailParams();
        $this->_from        = $emailParams['from'];
        $this->_fromName    = $emailParams['from_name'];

        $this->_to          = $emailParams['to'];
        $this->_toName      = $emailParams['to_name'];

        foreach($emailParams['to'] as $emailAddress => $recipientName) {
            $recipient = new EmailBatchRecipient();
            $recipient->setRecipientType(EmailBatchRecipient::RECIPIENT_TYPE_TO)
                      ->setEmailAddress($emailAddress)
                      ->setRecipientName($recipientName);

            if(isset($emailParams['recipientKeywordData'][$emailAddress])) {
                foreach($emailParams['recipientKeywordData'][$emailAddress] as $name => $value) {
                    $recipient->addKeywordData($name, $value);
                }
            }

            $this->_recipients[] = $recipient;
        }

        /*foreach($emailParams['cc'] as $emailAddress => $recipientName) {
            $recipient = new EmailBatchRecipient();
            $recipient->setRecipienttype(EmailBatchRecipient::RECIPIENT_TYPE_CC)
            ->setEmailaddress($emailAddress)
            ->setRecipientName($recipientName);

            if(isset($emailParams['recipientKeywordData'][$emailAddress])) {
                foreach($emailParams['recipientKeywordData'][$emailAddress] as $name => $value) {
                    $recipient->addKeywordData($name, $value);
                }
            }

            $this->_recipients[] = $recipient;
        }*/

        foreach($emailParams['add_bcc'] as $emailAddress) {
            $recipient = new EmailBatchRecipient();
            $recipient->setRecipientType(EmailBatchRecipient::RECIPIENT_TYPE_BCC)
            ->setEmailAddress($emailAddress);

            if(isset($emailParams['recipientKeywordData'][$emailAddress])) {
                foreach($emailParams['recipientKeywordData'][$emailAddress] as $name => $value) {
                    $recipient->addKeywordData($name, $value);
                }
            }

            $this->_recipients[] = $recipient;
        }

        $this->_replyTo     = $emailParams['reply_to'];
        $this->_title       = $emailParams['subject'];
        $this->_content     = $emailParams['body'];
        $this->_attachement = implode(',', $emailParams['attachment']);
    }

    protected function _afterSave() {
        // Save all the recipients
        foreach($this->_recipients as $recipient) {
            $recipient->setBatchId($this->getId());
        }
        EmailBatchRecipient::saveBatch($this->_recipients);
    }

    // Check if to should be sent one by one or all together
    public function process() {
        $lastRun = new \DateTime($this->_lastRun);

        if($this->_lastRun == null || $lastRun->diff(new \DateTime(), true)->s > $this->_coolDown) {
            $sentNum = 0;

            foreach($this->_recipients as &$recipient) {
                if(!$recipient->getSent()) {
                    $email = new OneTimeEmail();
                    $email->setTitle($this->_title);
                    $email->setContent($this->_content);
                    $email->setFrom($this->_from, $this->_fromName);
                    $email->setReplyTo($this->_replyTo);
                    $recipientKeywords = array();

                    /**
                     * @var EmailBatchRecipientKeyword $keywordData
                     */
                    foreach($recipient->getAllKeywordData() as $keywordData) {
                        $recipientKeywords[$keywordData->getName()] = $keywordData->getValue();
                    }

                    $email->addTo($recipient->getEmailAddress(), $recipient->getRecipientName(), $recipientKeywords);
                    $email->send();

                    $recipient->setSent(date('Y-m-d H:m:s'));
                    $recipient->save();
                    if(++$sentNum >= $this->_batchSize) {
                        break;
                    }
                }
            }

            $this->_lastRun = date('Y-m-d H:m:s');
            $this->save();
        }
    }

    public function getNumRecipientsLeft() {
        $num = 0;
        foreach($this->_recipients as &$recipient) {
            if($recipient->getSent() == null) {
                ++$num;
            }
        }
        return $num;
    }

    public function setBatchSize($batchSize) {
        $this->_batchSize = $batchSize;
        return $this;
    }

    public function getBatchSize() {
        return $this->_batchSize;
    }

    public function setCooldown($cooldown) {
        $this->_coolDown = $cooldown;
        return $this;
    }
}