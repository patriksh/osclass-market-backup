<?php
namespace dliLib\Email;

use dliLib\Cache\CacheManager;
use dliLib\dliString;

/**
 * Class AbstractEmail
 *
 * Base class for emails.
 * Predefined available keywords are:
 * {WEB_URL}, {WEB_TITLE}, {WEB_LINK}, {CURRENT_DATE}, {HOUR}, {IP_ADDRESS}
 *
 * @author danlil
 * @package dliLib\Email
 */
abstract class AbstractEmail
{
    /**
     * @type string
     */
    protected $_defaultContent          = '';

    protected $_dynamicTags             = array();

    protected $_page                    = null;

    protected $_from                    = '';
    protected $_fromName                = '';
    protected $_to                      = array();
    protected $_cc                      = array();
    protected $_bcc                     = array();
    protected $_attachements            = array();

    protected $_locale                  = null;

    protected $_globalKeywordData       = array();
    protected $_recipientKeywordData    = array();

    protected $_replyTo                 = null;

    protected $_breakOnInvalidTags      = true;
    protected $_isInstallable           = true;

    private   $_defaultKeywords         = array('{WEB_URL}',
                                                '{WEB_TITLE}',
                                                '{WEB_LINK}' ,
                                                '{CURRENT_DATE}',
                                                '{HOUR}',
                                                '{IP_ADDRESS}');
    private   $_keywords                = array();

    /**
     * Should return the internal Osclass name of the email
     * @return string
     */
    protected function _getInternalName() {
        return static::class;
    }

    public function setLocale($locale) {
        $this->_locale = $locale;
    }

    /**
     * Should return the internal Osclass description of the email.
     * @return string
     */
    abstract protected function _getDescription();

    /**
     * Should return the default title/subject of the email
     * @return string
     */
    abstract protected function _getDefaultTitle();

    /**
     * Should return the default content/body of the email
     * @return string
     */
    abstract protected function _getDefaultContent();

    /**
     * @param array|null $globalKeywordData
     */
    final public function __construct($globalKeywordData = array()) {
        // Extract valid key words
        $titleKeywords = array();
        preg_match_all('(\{\w+\})', $this->_getDefaultTitle(), $titleKeywords);
        $contentKeywords = array();
        preg_match_all('(\{\w+\})', $this->_getDefaultContent(), $contentKeywords);

        $this->_keywords = array_values(array_merge($titleKeywords[0], $contentKeywords[0], $this->_defaultKeywords));

        $this->_validateKeywordData($globalKeywordData);
        $this->_globalKeywordData = $globalKeywordData;

        $this->_from        = osc_mailserver_mail_from();
        $this->_fromName    = osc_mailserver_name_from();
    }

    /**
     * @param array $keyWordData
     */
    private function _validateKeywordData($keyWordData) {
        if(is_array($keyWordData)) {
            foreach($keyWordData as $tagName => $data) {
                $tagString = new dliString($tagName);
                if(!$tagString->startsWith('{') || !$tagString->endsWith('}')) {
                    throw new \InvalidArgumentException($tagName . ' make sure to enclose tags in { }');
                }

                if($this->_breakOnInvalidTags && !in_array($tagString, $this->_keywords)) {
                    throw new \InvalidArgumentException($tagName . ' is not a valid tag');
                }
            }
        }
    }

    final public function setFrom($emailAddress, $name = '') {
        if(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL) === false) {
            $this->_from     = $emailAddress;
            $this->_fromName = $name;
        }
        else {
            throw new \InvalidArgumentException($emailAddress . ' is not a valid email address');
        }
    }

    final public function addTo($emailAddress, $name = '', $recipientKeywordData = array()) {
        if(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL) === false) {
            $this->_to[$emailAddress] = $name;
            if($recipientKeywordData) {
                $this->_validateKeywordData($recipientKeywordData);
                $this->_recipientKeywordData[$emailAddress] = $recipientKeywordData;
            }
        }
        else {
            throw new \InvalidArgumentException($emailAddress . ' is not a valid email address');
        }
    }

    final public function addCc($emailAddress, $name = '', $recipientKeywordData = array()) {
        if(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL) === false) {
            $this->_cc[$emailAddress] = $name;
            if($recipientKeywordData) {
                $this->_validateKeywordData($recipientKeywordData);
                $this->_recipientKeywordData[$emailAddress] = $recipientKeywordData;
            }
        }
        else {
            throw new \InvalidArgumentException($emailAddress . ' is not a valid email address');
        }
    }

    final public function addBcc($emailAddress, $name = '', $recipientKeywordData = array()) {
        if(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL) === false) {
            $this->_bcc[$emailAddress] = $name;
            if($recipientKeywordData) {
                $this->_validateKeywordData($recipientKeywordData);
                $this->_recipientKeywordData[$emailAddress] = $recipientKeywordData;
            }
        }
        else {
            throw new \InvalidArgumentException($emailAddress . ' is not a valid email address');
        }
    }

    final public function addAttachement($path, $name = null) {
        if(file_exists($path)) {
            if(!$name) {
                $name = basename($path);
            }
            $this->_attachements[$path] = array('path' => $path, 'name' => $name);
        }
        else {
            throw new \InvalidArgumentException('Attachement does not exist');
        }
    }

    final public function setReplyTo($replyTo) {
        if(!filter_var($replyTo, FILTER_VALIDATE_EMAIL) === false) {
            $this->_replyTo = $replyTo;
        }
        else {
            throw new \InvalidArgumentException($replyTo . ' is not a valid email address');
        }
    }

    final public function _getEmailParams() {
        $emailParams                = array();

        if($this->_from) {
            $emailParams['from']        = $this->_from;
            $emailParams['from_name']   = $this->_fromName;
        }

        $emailParams['to']            = $this->_to;
        $emailParams['to_name']       = array_values($this->_to);

        // cc not used in osc send function
        //$emailParams['cc']          = array_keys($this->_cc);
        //$emailParams['cc_name']     = array_values($this->_cc);

        $emailParams['add_bcc']     = array_keys($this->_bcc);
        // BCC can't take names yet
        //$emailParams['bcc_name']    = array_values($this->_bcc);
        $emailParams['attachment']  = $this->_attachements;

        if($this->_replyTo) {
            $emailParams['reply_to']    = $this->_replyTo;
        }
        else {
            $emailParams['reply_to']    = $this->_from;
        }

        $cacheKey = 'email-' . static::class;
        $this->_page = CacheManager::getInstance()->fetch($cacheKey);

        if(!$this->_page) {
            $this->_page = \Page::newInstance()->findByInternalName($this->_getInternalName());
            CacheManager::getInstance()->store($cacheKey, $this->_page);
        }

        $emailParams['subject']     = $this->_getTitle($this->_locale);
        $emailParams['body']        = $this->_getContent($this->_locale);

        $emailParams['globalKeywordData'] = $this->_globalKeywordData;
        $emailParams['recipientKeywordData'] = $this->_recipientKeywordData;

        return $emailParams;
    }

    protected function _getTitle($locale = null) {
        if(!$this->_page) {
            return $this->_getDefaultTitle();
        }
        if(!$locale) {
            $locale = osc_current_user_locale();
        }
        return (string) osc_field($this->_page, "s_title", $locale);
    }

    protected function _getContent($locale = null) {
        if(!$this->_page) {
            return $this->_getDefaultContent();
        }
        if(!$locale) {
            $locale = osc_current_user_locale();
        }
        return (string)osc_field($this->_page, "s_text", $locale);
    }

    final public function send() {
        $globalKeywords[0] = array_keys($this->_globalKeywordData);
        $globalKeywords[1] = array_values($this->_globalKeywordData);

        $emailParams = $this->_getEmailParams();
        $emailParams['subject'] = osc_mailBeauty($emailParams['subject'], $globalKeywords);
        $emailParams['body']    = osc_mailBeauty($emailParams['body'], $globalKeywords);

        // We have personalized mails
        if($this->_recipientKeywordData) {
            foreach($this->_to as $recipientEmail => $recipientName)
            {
                $recipientKeywords[0] = array_keys($this->_recipientKeywordData[$recipientEmail]);
                $recipientKeywords[1] = array_values($this->_recipientKeywordData[$recipientEmail]);
                $emailParams['subject'] = osc_mailBeauty($emailParams['subject'], $recipientKeywords);
                $emailParams['body']    = osc_mailBeauty($emailParams['body'], $recipientKeywords);
            }
        }
        //return;
        osc_sendMail($emailParams);
    }

    final public function install() {
        if(!$this->_isInstallable) {
            return;
        }

        $page = \Page::newInstance();

        $descriptions = array();
        foreach (osc_listLanguageCodes() as $code) {
            $descriptions[$code] =
            array("s_title" => $this->_getDefaultTitle(), "s_text" => $this->_getDefaultContent());
        }

        $isInserted = $page->insert(
            array(
                "s_internal_name" => $this->_getInternalName(),
                "b_indelible"     => true,
                "b_link"          => true
            ),
            $descriptions
        );

        if(!$isInserted) {
            throw new \Exception($page->getErrorDesc());
        }
    }

    final public function uninstall() {
        if(!$this->_isInstallable) {
            return;
        }
    	// Gets the Page data-access object (an emails is a special static page)
		$page = \Page::newInstance();

        // Get the e-mail.
        $pageInfo = $page->findByInternalName($this->_getInternalName());
        if(! empty($pageInfo)) {
            // Delete descriptions (title and body) in every language.
            $page->dao->delete(
                DB_TABLE_PREFIX.'t_pages_description',
                array('fk_i_pages_id' => $pageInfo['pk_i_id']));

            // Delete the email itself.
            $page->dao->delete(
                DB_TABLE_PREFIX.'t_pages',
                array('pk_i_id' => $pageInfo['pk_i_id']));
        }
    }

    public function update($previousVersion, $newVersion) {
        if(!$this->_isInstallable) {
            return;
        }
    }
}