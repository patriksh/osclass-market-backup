<?php
namespace dliLib\Email;

use dliLib\Model\DbModel;

/**
 * Hold receipient information used by an EmailBatch
 *
 * @author danlil
 * @see EmailBatch
 */
class EmailBatchRecipientKeyword extends DbModel
{
    protected static $_dbTableClass = 'dliLib\Email\Table\EmailBatchRecipientKeywordsTable';

    protected $_recipientId   = null;
    protected $_name          = null;
    protected $_value         = null;

    /**
     * @return null
     */
    public function getRecipientId()
    {
        return $this->_recipientId;
    }

    /**
     * @param null $recipientId
     * @return EmailBatchRecipientKeyword
     */
    public function setRecipientId($recipientId)
    {
        if(is_array($recipientId)) {
            $i = 1;
        }
        $this->_recipientId = $recipientId;
        return $this;
    }

    /**
     * @return null
     */
    public function getName()
    {
        return $this->_name;
    }

    /**
     * @param null $name
     * @return EmailBatchRecipientKeyword
     */
    public function setName($name)
    {
        $this->_name = $name;
        return $this;
    }

    /**
     * @return null
     */
    public function getValue()
    {
        return $this->_value;
    }

    /**
     * @param null $value
     * @return EmailBatchRecipientKeyword
     */
    public function setValue($value)
    {
        $this->_value = $value;
        return $this;
    }

    public static function fetchAllFromEmailBatchRecipient(EmailBatchRecipient &$emailBatchRecipient) {
        return static::_fetchAll(static::getDbTable()->selectConditions()->where('fk_i_recipient_id', $emailBatchRecipient->getId()));
    }
}