<?php
namespace dliLib\Email;

use dliLib\Model\DbModel;

/**
 * Hold keywords used in Email send using EmailBatch
 *
 * @author danlil
 * @see EmailBatch
 */
class EmailBatchKeyword extends DbModel
{
    protected static $_dbTableClass = 'dliLib\Email\Table\EmailBatchKeywordsTable';

    protected $_recipientId     = null;
    protected $_name            = null;
    protected $_value           = null;

    /**
     * @return null
     */
    public function getRecipientId()
    {
        return $this->_recipientId;
    }

    /**
     * @param null $recipientId
     * @return EmailBatchKeyword
     */
    public function setRecipientId($recipientId)
    {
        $this->_recipientId = $recipientId;
        return $this;
    }

    /**
     * @return null
     */
    public function getName()
    {
        return $this->_name;
    }

    /**
     * @param null $name
     * @return EmailBatchKeyword
     */
    public function setName($name)
    {
        $this->_name = $name;
        return $this;
    }

    /**
     * @return null
     */
    public function getValue()
    {
        return $this->_value;
    }

    /**
     * @param null $value
     * @return EmailBatchKeyword
     */
    public function setValue($value)
    {
        $this->_value = $value;
        return $this;
    }

    public static function fetchAllFromEmailBatch(EmailBatch &$emailBatch) {
        return static::_fetchAll(static::getDbTable()->selectConditions()->where('fk_i_batch_id', $emailBatch->getId()));
    }
}