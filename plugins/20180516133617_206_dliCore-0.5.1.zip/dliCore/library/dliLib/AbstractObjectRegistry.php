<?php
namespace dliLib;
/**
 * Class that manages objects from several different classes or plugins that should be
 * instantiated by a specific module but used by the entire system without
 * actual knowledge about the object in question. The object is referenced by
 * it's class name and ONLY instantiated after it has been called at least once.
 * This is to avoid objects that are not being used by the current request from being instantiated.
 *
 * One example of usage might be multiple modules being able to supply parts of a common configuration form
 * by registering their pieces in a registry. They all share a common interface and the module responsible for
 * rendering the form simply loops through them all and renders them by some known function.
 *
 * @author danlil
 *
 */

abstract class AbstractObjectRegistry extends Singleton
{
    /**
    * Array of names of objects or if the object has been requested at least once
    * an instance of the object in question.
    * @var array
    */
    private $_objects = array();

    /**
    * Object type to accept for storage in the registry. Can be a single string
    * of the name of the class to accept or an array of strings if several class
    * types are to be accepted.
    * @var mixed
    */
    protected $_acceptedObjectClasses = null;

    /**
     * Name of function to run when object has been created
     * @var string|null
     */
    protected $_bootstrapFunction = null;

    protected $_bootStrapRunFor  = [];

    /**
     *
     * Returns the requested object by name. If the object is not yet instantiated
     * it will be instantiated first and then returned.
     *
     * If the requested object is of an unkown class type an Exception is thrown
     * is thrown.
     *
     * @param string $name
     * @return mixed|null
     * @throws \InvalidArgumentException
     */
    public function &get($name) {
        if(empty($this->_objects[$name])) {
            $null = null;
            return $null;
        }

        $object = $this->_objects[$name];

        // If the object is already instantiated  we return it
        if(is_object($object)) {
            if($this->_bootstrapFunction) {
                if(!in_array($name, $this->_bootStrapRunFor)) {
                    $funcName = $this->_bootstrapFunction;
                    $this->_bootStrapRunFor[] = $name;
                    $object->$funcName();
                }
            }
            return $object;
        }
        // Instantiate  the class and return it
        else {
            if(class_exists($this->_objects[$name])) {
                $object = new $this->_objects[$name];
                $this->_objects[$name] = $object;
                if($this->_bootstrapFunction) {
                    $funcName = $this->_bootstrapFunction;
                    $this->_bootStrapRunFor[] = $name;
                    $object->$funcName();
                }
                return $object;
            }
            else {
                throw new \InvalidArgumentException('Unknown class');
            }
        }
    }

    /***
     * Get a list of names and classes of registered objects
     * @return string[]
     */
    public function getMetaData() {
        $metaData = [];
        foreach($this->_objects as $objectName => $object) {
            // If the object is already instantiated  we return it
            if (is_object($object)) {
                $metaData[$objectName] = get_class($object);
            }
            else {
                if (class_exists($object)) {
                    $metaData[$objectName] = $object;
                }
            }
        }

        return $metaData;
    }

  /**
   *
   * Returns array of all registered objects.
   */
  public function &getAll() {
    $objects = array();

    foreach($this->_objects as $objectName => $objectClassName) {
      $objects[] = &$this->get($objectName);
    }
    return $objects;
  }

  /**
   * Given a constructor to allow special cases where several instances of a registry might actually make sense.
   * For instance, keeping db tables in registries that are each owned by their own modules.
   */
  public function __construct() {

  }

    /**
     * Registers a object given it's class name or instance of the object and a name for the object.
     * Note that if a string is given and namespaces are used the entire name space must be provided.
     * @param $objectClass
     * @param string $objectName
     * @throws \Exception
     */
  public function register($objectClass, $objectName = null) {
    if($this->_isValidObject($objectClass)) {
        if(!$objectName) {
            if(is_object($objectClass)){
                $objectName = get_class($objectClass);
            }
            else {
                $objectName = $objectClass;
            }
        }
      $this->_objects[$objectName] = $objectClass;
    }
    else {
      throw new \Exception('Invalid object registered');
    }
  }

    /**
     *
     * Check if the given object class is in the array of accepted object classes.
     * $objectClass can be either a stringname of an object class or an instance
     * of the object of the class type. It may also be an array consisting of
     * a multitude of the above in any order.
     * @param mixed $objectClass
     * @return bool
     */
  private function _isValidObject($objectClass) {
    if(is_string($objectClass) && !class_exists($objectClass)) {
        return false;
    }

    if(!is_array($this->_acceptedObjectClasses)) {
        $acceptedObjectClasses = array($this->_acceptedObjectClasses);
    }
    else {
        $acceptedObjectClasses = $this->_acceptedObjectClasses;
    }

    foreach($acceptedObjectClasses as $acceptedObjectClass) {
        if(is_string($objectClass)) {
            if($objectClass == $acceptedObjectClass) {
                return true;
            }

            if(is_subclass_of($objectClass, $acceptedObjectClass)) {
                return true;
            }
        }
        else if($objectClass instanceof $acceptedObjectClass) {
            return true;
        }
    }

    return false;
  }
}