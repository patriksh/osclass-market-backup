<?php
namespace dliLib\Db;

use dliLib\Cache\CacheManager;
/**
 * Base class for tables to be used with \dliLib\Db\ModelGateway \dliLib\Model\DbModel
 *
 * @author danlil
 *
 */
abstract class AbstractTable
{
    /**
     * Struct of the table. Used when installing the table.
     * @var string
     */
    protected $_struct = '';

    /**
     * Table name to give the table (excluding the DB_PREFIX constant form osclass)
     * Sadly DAO also exposes a public tableName. Ignore that. It will be populated by this.
     *
     * @var string
     */
    protected $_tableName = '';

    /**
     * @var \DAO
     */
    protected $_dao = null;

    /**
     * Holds the primary key of the table
     * Would like this to be private, but since we are extending DAO we have to make it public and have it's name break our standard
     * instead of having both a _primaryKey and primaryKey variable
     * @var int|string|array
     */
    protected $_primaryKey = null;

    /**
     * Stores the table layout info
     * @var string[][]
     */
    protected static $_tableInfo = array();

    /**
     * Used to store our last inserted id (since the standard mysql function can only return this for single auto incrementing columns)
     * This handles multi column primary keys etc.
     * @var int|string|array
     */
    protected static $_lastInsertedId = null;

    /**
     * Keep track of if we have populated the tables fields, primarykey etc.
     * @var unknown
     */
    protected static $_infoGathered = array();

    /**
     * Keeps track of when the schema in the mysql was updated
     * @var string[][]
     */
    protected static $_tablesUpdatedInfo = null;

    final public function __construct() {
        if($this->_tableName == '') {
            throw new \Exception('$_tableName not set for class ' . static::class);
        }

        $this->_dao = new \DAO();
        $this->_dao->setTableName($this->_tableName);

        // Fetch information about when tables where updated
        if(static::$_tablesUpdatedInfo === null) {
            $result = $this->_dao->dao->query("SELECT TABLE_NAME, CREATE_TIME, UPDATE_TIME FROM INFORMATION_SCHEMA.TABLES WHERE table_schema = '" . DB_NAME . "'");
            if ($result->numRows) {
                $rows = $result->result();
                foreach($rows as $row) {
                    $createTime = strtotime($row['CREATE_TIME']);
                    $updateTime = strtotime($row['UPDATE_TIME']);
                    $tableInformationTime = max($createTime, $updateTime);
                    static::$_tablesUpdatedInfo[$row['TABLE_NAME']] = $tableInformationTime;
                }
            }
        }

        $this->_init();

        $this->_struct = str_replace(['/*TABLE_PREFIX*/', '{TABLE_PREFIX}'], $this->_dao->getTablePrefix(), $this->_struct);
        $this->_struct = str_replace(['/*TABLE_NAME*/', '{TABLE_PREFIX}'], $this->_dao->getTableName(), $this->_struct);

        $this->_primaryKey = null;
    }

    public function selectConditions() {
        $conditions = clone $this->_dao->dao;
        $conditions->_resetSelect();
        $conditions->_resetWrite();
        return $conditions->select()->from($this->_dao->getTableName());
    }

    /**
     * Sets information such as primary key
     *
     * @throws \Exception
     */
    private function _gatherInfo() {
        $tableData          = $this->describeTable();
        $this->_primaryKey   = null;
        $this->_dao->fields = [];
        foreach($tableData as $columnName => $columnMetaData) {
            $this->_dao->fields[] = $columnName;

            if($columnMetaData['PRIMARY'] === true) {
                // If we already have a primary key this table uses a multi column primary key
                if($this->_primaryKey !== null) {
                    if(is_array($this->_primaryKey)) {
                        $this->_primaryKey[$columnMetaData['PRIMARY_POSITION'] - 1] = $columnName;
                    }
                    else {
                        $firstVal = $this->_primaryKey;
                        $this->_primaryKey = [];
                        $this->_primaryKey[$tableData[$firstVal]['PRIMARY_POSITION'] - 1] = $firstVal;
                        $this->_primaryKey[$columnMetaData['PRIMARY_POSITION'] - 1] = $columnName;
                    }
                }
                else {
                    $this->_primaryKey = $columnName;
                }
            }
        }

        $this->_dao->setPrimaryKey($this->_primaryKey);
    }

    public function getFields() {
        $this->_gatherInfo();
        return $this->_dao->getFields();
    }

    public function getTableName() {
        return $this->_dao->getTableName();
    }

    /**
     * @return string|string[]
     * @throws \Exception
     */
    public function getPrimaryKey() {
        $this->_gatherInfo();
        return $this->_primaryKey;
    }

    protected function _init() {}

    /**
     * Returns true if the table exists in DB
     * @return bool
     */
    final public function isInstalled() {
        return array_key_exists(static::getName(), static::$_tablesUpdatedInfo);
    }

    final public function installSchema() {
        if($this->_struct !== '' && !$this->_dao->dao->importSQL($this->_struct)){
            throw new \Exception($this->_dao->dao->getErrorLevel() . ' - ' . $this->_dao->dao->getErrorDesc());
        }
    }

    final public function uninstallSchema() {
        $this->_dao->dao->query(sprintf('DROP TABLE %s', $this->_dao->getTableName()));
    }

    /**
     * Called on all registered tables when a Plugin is updated
     *
     * @param string $previousVersion
     * @param string $newVersion
     */
    public function updateSchema($previousVersion, $newVersion) {

    }

    /**
     * $key can be a single key in string form or multiple column names in array.
     * The array can be of form array(keyColumnName1 => value, keyColumnName2 => value) or
     * array(value1, value2, value3). If the latter is used, the order should equal that of the
     * columns index position in the primary key.
     *
     * @see \DAO::updateByPrimaryKey()
     */
    public function updateByPrimaryKey($values, $key) {
        $this->_gatherInfo();

        // Does this table have a multi column primary key
        if(is_array($this->getPrimaryKey())) {
            if(!is_array($key)) {
                $className = get_class($this);
                throw new \Exception("The table \"$className\" uses a multi column primary key. Single column key provided.");
            }

            $cond = array();
            $primaryPosition = 0;

            foreach($this->getPrimaryKey() as $keyPart) {
                if(!array_key_exists($keyPart, $key) && !array_key_exists($primaryPosition, $key)) {
                    $className = get_class($this);
                    throw new \Exception("The table \"$className\" uses a multi column primary key. \"$keyPart\" not provided.");
                }

                if(isset($key[$keyPart])) {
                    $cond[$keyPart] = $key[$keyPart];
                }
                else {
                    $cond[$keyPart] = $key[$primaryPosition];
                }

                ++$primaryPosition;
            }

            $result = $this->_dao->update($values, $cond);
            $this->_dao->dao->_resetWrite();
            return $result;
        }
        else {
            // If "normal" single column primary key is used we just pass it on
            $result = $this->_dao->updateByPrimaryKey($values, $key);
            $this->_dao->dao->_resetWrite();
            return $result;
        }
    }

    /**
     * $key can be a single key in string form or multiple column names in array.
     * The array can be of form array(keyColumnName1 => value, keyColumnName2 => value) or
     * array(value1, value2, value3). If the latter is used, the order should equal that of the
     * columns index position in the primary key.
     *
     * @see DAO::deleteByPrimaryKey()
     */
    public function deleteByPrimaryKey($key)
    {
        // Does this table have a multi column primary key
        if(is_array($this->getPrimaryKey())) {
            if(!is_array($key)) {
                $className = get_class($this);
                throw new \Exception("The table \"$className\" uses a multi column primary key. Single column key provided.");
            }

            $cond = [];
            $primaryPosition = 0;

            foreach($this->getPrimaryKey() as $keyPart) {
                if(!array_key_exists($keyPart, $key) && !array_key_exists($primaryPosition, $key)) {
                    $className = get_class($this);
                    throw new \Exception("The table \"$className\" uses a multi column primary key. \"$keyPart\" not provided.");
                }

                if(isset($key[$keyPart])) {
                    $cond[$keyPart] = $key[$keyPart];
                }
                else {
                    $cond[$keyPart] = $key[$primaryPosition];
                }

                ++$primaryPosition;
            }
            $result = $this->_dao->delete($cond);
            $this->_dao->dao->_resetWrite();
            return $result;
        }
        else {
            // If "normal" single column primary key is used we just pass it on
            if((!is_array($key) && !empty($key)) || array_key_exists($this->getPrimaryKey(), $key)) {
                if(is_array($key)) {
                    $key = $key[$this->getPrimaryKey()];
                }
                $result = $this->_dao->deleteByPrimaryKey($key);
                $this->_dao->dao->_resetWrite();
                return $result;
            }
            else {
                $this->_dao->dao->_resetWrite();
                throw new \Exception(__('Primary key not supplied', 'dliCore'));
            }
        }
    }

    /**
     * Basic delete. It returns false if the keys from $where doesn't
     * match with the fields defined in the construct
     *
     * @param $cond
     * @return mixed
     * @throws \Exception
     */
    public function delete($cond) {
        $this->_gatherInfo();
        $result = $this->_dao->delete($cond);
        $this->_dao->dao->_resetWrite();
        return $result;
    }

    /**
     * $key can be a single key in string form or multiple column names in array.
     * The array can be of form array(keyColumnName1 => value, keyColumnName2 => value) or
     * array(value1, value2, value3). If the latter is used, the order should equal that of the
     * columns index position in the primary key.
     *
     * @see DAO::findByPrimaryKey()
     * @throws \Exception
     */
    function findByPrimaryKey($key)
    {
        $this->_gatherInfo();

        // Does this table have a multi column primary key
        if(is_array($this->getPrimaryKey())) {
            if(!is_array($key)) {
                $className = get_class($this);
                throw new \Exception("The table \"$className\" uses a multi column primary key. Single column key provided.");
            }

            $cond = array();
            $primaryPosition = 0;

            foreach($this->getPrimaryKey() as $keyPart) {
                if(!array_key_exists($keyPart, $key) && !array_key_exists($primaryPosition, $key)) {
                    $className = get_class($this);
                    throw new \Exception("The table \"$className\" uses a multi column primary key. \"$keyPart\" not provided.");
                }

                if(isset($key[$keyPart])) {
                    $cond[$keyPart] = $key[$keyPart];
                }
                else {
                    $cond[$keyPart] = $key[$primaryPosition];
                }

                ++$primaryPosition;
            }

            $this->_dao->dao->select($this->_dao->fields);
            $this->_dao->dao->from($this->_dao->getTableName());
            foreach($cond as $keyName => $keyValue) {
                $this->_dao->dao->where($keyName, $keyValue);
            }
            $result = $this->_dao->dao->get();
            $this->_dao->dao->_resetSelect();
            if( $result === false ) {
                return false;
            }

            if( $result->numRows() !== 1 ) {
                return false;
            }

            return $result->row();
        }
        else {
            // If "normal" single column primary key is used we just pass it on
            $result = $this->_dao->findByPrimaryKey($key);
            $this->_dao->dao->_resetSelect();
            return $result;
        }
    }

    /**
     * Performs a INSERT ON DUPLICATE KEY UPDATE query
     *
     * @param array $data
     * @return boolean
     * @throws \Exception
     */
    public function insertOrUpdate(array $data) {
        $this->_gatherInfo();

        if( !is_null($data) ) {
            $this->_dao->dao->set($data);
        }

        if( count($this->_dao->dao->aSet) == 0 ) {
            return false;
        }


        if( $this->_dao->getTableName() == '') {
            if( !isset($this->dao->aFrom[0]) ) {
                return false;
            }

            $table = $this->dao->aFrom[0];
        }

        $sql = $this->_dao->dao->_insert($this->_dao->getTableName(), array_keys($this->_dao->dao->aSet), array_values($this->_dao->dao->aSet));
        $sql .= ' ON DUPLICATE KEY UPDATE ';

        $columns = array();
        foreach($this->_dao->dao->aSet as $columnName => $columnValue) {
            $columns[] = $columnName . ' = ' . $columnValue;
        }

        $sql .= implode(', ', $columns);
        $this->_dao->dao->_resetWrite();
        $result = $this->_dao->dao->query($sql);

        if($result) {
            // Check if an autoincrement id was created.
            // If so that IS the pk
            $autIncId = $this->_dao->dao->insertedId();
            if($autIncId) {
                static::$_lastInsertedId = $autIncId;
            }
            else if(is_array($this->getPrimaryKey())) {
                $pk = array();
                foreach($this->getPrimaryKey() as $keyName) {
                    $pk[] = $data[$keyName];
                }
                static::$_lastInsertedId = $pk;
            }
            else {
                static::$_lastInsertedId = $data[$this->getPrimaryKey()];
            }

        }
        return $result;
    }

    public function getLastInsertedId() {
        return static::$_lastInsertedId;
    }

    /***
     * Returns the name of the table so it can be used as FK's in other tables without any instance
     * of this table being known at the time.
     *
     * @return string
     */
    public static function getName() {
        $vars = get_class_vars(static::class);

        if(isset($vars['_tableName']) && $vars['_tableName'] != '') {
            $name = DB_TABLE_PREFIX . $vars['_tableName'];
        }
        else if(!empty($this)) {
            $name = $this->_dao->getTableName();
        }
        else {
            $calledClassName = static::class;
            /*** @var static $table */
            $table = new $calledClassName();
            $name = $table->getTableName();
            unset($table);
        }
        return $name;
    }

    public function beginTransaction() {
        $this->_dao->dao->query('BEGIN');
    }

    public function commitTransaction() {
        $this->_dao->dao->query('COMMIT');
    }

    public function setTransactionSavepoint($name) {
        $this->_dao->dao->query('SAVEPOINT ' . $name);
    }

    public function rollbackTransaction($to = null) {
        $this->_dao->dao->query('ROLLBACK'  . ($to ? ' TO ' . $to : ''));
    }

    private function _checkCachedTableInfo() {
        if (!array_key_exists(static::class, static::$_tableInfo)) {
            $key = 'dliCore/tableInfo/' . static::getName();
            $cachedTableInfo = CacheManager::getInstance()->fetch($key);

            if ($cachedTableInfo) {
                if ($cachedTableInfo['cachedTime'] == static::$_tablesUpdatedInfo[static::getName()]) {
                    static::$_tableInfo[static::class] = $cachedTableInfo['tableInfo'];
                } else {
                    CacheManager::getInstance()->delete($key);
                }
            }
        }
    }

    private function _cacheTableInfo() {
        $key = 'dliCore/tableInfo/'.static::getName();
        $data = array();
        $data['cachedTime'] = static::$_tablesUpdatedInfo[static::getName()];
        $data['tableInfo']  = static::$_tableInfo[static::class];

        CacheManager::getInstance()->store($key, $data, 3600*24);
    }


    /***
     * Fetches actual table layout data instead of relying on hard coded value in the source code.
     * This enables us to get a warning if we add a new required column but don't update our code.
     *
     * Retrieved data is cached and only re-fetched if a table is updated. This requires dliCore cache system to be active to be writable
     *
     * @throws \Exception
     * @return array
     */
    public function describeTable()
    {
        // Check for cached table info
        $this->_checkCachedTableInfo();

        if (!array_key_exists(static::class, static::$_tableInfo)) {
            $sql = 'DESCRIBE ' . static::getName();

            if ($queryResult = $this->_dao->dao->query($sql)) {
                if ($queryResult != null) {
                    $result = $queryResult->result();
                }
            } else {
                throw new \Exception($this->_dao->dao->getErrorDesc());
            }

            $desc = array();

            $row_defaults = array(
                'Length' => null,
                'Scale' => null,
                'Precision' => null,
                'Unsigned' => null,
                'Primary' => false,
                'PrimaryPosition' => null,
                'Identity' => false
            );
            $i = 1;
            $p = 1;
            foreach ($result as $key => $row) {
                $row = array_merge($row_defaults, $row);
                if (preg_match('/unsigned/', $row['Type'])) {
                    $row['Unsigned'] = true;
                }
                if (preg_match('/^((?:var)?char)\((\d+)\)/', $row['Type'], $matches)) {
                    $row['Type'] = $matches[1];
                    $row['Length'] = $matches[2];
                } else
                    if (preg_match('/^decimal\((\d+),(\d+)\)/', $row['Type'], $matches)) {
                        $row['Type'] = 'decimal';
                        $row['Precision'] = $matches[1];
                        $row['Scale'] = $matches[2];
                    } else
                        if (preg_match('/^float\((\d+),(\d+)\)/', $row['Type'], $matches)) {
                            $row['Type'] = 'float';
                            $row['Precision'] = $matches[1];
                            $row['Scale'] = $matches[2];
                        } else
                            if (preg_match('/^((?:big|medium|small|tiny)?int)\((\d+)\)/', $row['Type'], $matches)) {
                                $row['Type'] = $matches[1];
                            /**
                             * The optional argument of a MySQL int type is not precision
                             * or length; it is only a hint for display width.
                             */
                            }
                if (strtoupper($row['Key']) == 'PRI') {
                    $row['Primary'] = true;
                    $row['PrimaryPosition'] = $p;
                    if ($row['Extra'] == 'auto_increment') {
                        $row['Identity'] = true;
                    } else {
                        $row['Identity'] = false;
                    }
                    ++ $p;
                }
                $desc[(string) $row['Field']] = array(
                    'SCHEMA_NAME' => null, // @todo
                    'TABLE_NAME' => (string) $this->_dao->getTableName(),
                    'COLUMN_NAME' => (string) $row['Field'],
                    'COLUMN_POSITION' => $i,
                    'DATA_TYPE' => $row['Type'],
                    'DEFAULT' => $row['Default'],
                    'NULLABLE' => (bool) ($row['Null'] == 'YES'),
                    'LENGTH' => $row['Length'],
                    'SCALE' => $row['Scale'],
                    'PRECISION' => $row['Precision'],
                    'UNSIGNED' => $row['Unsigned'],
                    'PRIMARY' => $row['Primary'],
                    'PRIMARY_POSITION' => $row['PrimaryPosition'],
                    'IDENTITY' => $row['Identity'],
                    'AUTO_INCREMENT' => (strpos($row['Extra'], 'auto_increment') === false ? false : true)
                );
                ++ $i;
            }
            static::$_tableInfo[static::class] = $desc;
            $this->_cacheTableInfo();
        }

        return static::$_tableInfo[static::class];
    }

    public function escape($dataValue)
    {
        return $this->_dao->dao->escape($dataValue);
    }

    public function query($sql)
    {
        return $this->_dao->dao->query($sql);
    }
}
