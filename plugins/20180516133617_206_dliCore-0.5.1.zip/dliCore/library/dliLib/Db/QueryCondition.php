<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2016-09-09
 * Time: 14:12
 */

namespace dliLib\Db;


class QueryCondition
{
    const DESC              = 'desc';
    const ASC               = 'asc';

    private $_fields        = [];
    private $_where         = [];
    private $_whereNot      = [];
    private $_whereIn       = [];
    private $_whereNotIn    = [];

    public function __construct(array $fields) {
        $this->_fields = $fields;
    }

    private function _checkField($field) {
        if(!in_array($field, $this->_fields)) {
            throw new \InvalidArgumentException('Unknown field ' . $field);
        }
    }

    public function where($field, $condition) {
        $this->_checkField($field);
        //$this->_where[]
    }

    public function whereNot($field, $condition) {
        $this->_checkField($field);
    }

    public function whereIn($field, array $condition) {
        $this->_checkField($field);
    }

    public function whereNotIn($field, array $condition) {
        $this->_checkField($field);
    }
}