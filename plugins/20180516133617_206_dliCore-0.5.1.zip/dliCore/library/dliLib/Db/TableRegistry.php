<?php
namespace dliLib\Db;

use dliLib\AbstractObjectRegistry;

/**
 * Registry used by plugins to keep track of tables owned by it 
 * 
 * @author danlil
 *
 */
class TableRegistry extends AbstractObjectRegistry
{
    protected $_acceptedObjectClasses = array('dliLib\Db\AbstractTable');
}

?>