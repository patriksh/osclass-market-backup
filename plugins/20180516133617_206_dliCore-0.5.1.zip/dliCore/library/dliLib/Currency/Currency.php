<?php
/**
 * Created by PhpStorm.
 * User: danlil
 * Date: 2016-09-02
 * Time: 10:48
 */

namespace dliLib\Currency;

use dliLib\Model\OscModel;

class Currency extends OscModel
{
    protected static $_dbTableClass = 'dliLib\Currency\Table\CurrencyTable';

    protected $_code;
    protected $_name;
    protected $_description;
    protected $_enabled;

    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->_code;
    }

    /**
     * @param mixed $code
     * @return Currency
     */
    public function setCode($code)
    {
        $this->_code = $code;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->_name;
    }

    /**
     * @param mixed $name
     * @return Currency
     */
    public function setName($name)
    {
        $this->_name = $name;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->_description;
    }

    /**
     * @param mixed $description
     * @return Currency
     */
    public function setDescription($description)
    {
        $this->_description = $description;
        return $this;
    }

    /**
     * @return mixed
     */
    public function getEnabled()
    {
        return $this->_enabled;
    }

    /**
     * @param mixed $enabled
     * @return Currency
     */
    public function setEnabled($enabled)
    {
        $this->_enabled = $enabled;
        return $this;
    }


}