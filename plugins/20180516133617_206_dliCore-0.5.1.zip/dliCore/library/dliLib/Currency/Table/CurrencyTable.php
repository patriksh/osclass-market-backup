<?php
namespace dliLib\Currency\Table;

use dliLib\Db\AbstractTable;

/**
 * Special structless table used as a glue between Currency and the db
 * @author danlil
 *
 */
class CurrencyTable extends AbstractTable
{
    protected $_tableName = 't_currency';
}