<?php
namespace dliLib;
use Carbon\Carbon;

/**
 * Extends DateTime and provide some functions for manipulating them
 *
 * @see \DateTime
 * @author danlil
 *
 */
class dliDateTime extends Carbon
{
    public static function createFromString($timeStr = 'now', $tz = null) {
        return new dliDateTime($timeStr, $tz);
    }
    /**
     * Return Date in ISO8601 format
     *
     * @return String
     */
    public function __toString() {
        return $this->format('Y-m-d H:i:s');
    }

    /**
     * Returns the dliDateTime in the format configured in the osclass installation
     * @return string
     */
    public function getAsFormattedString() {
        return $this->format(osc_date_format() . ' ' . osc_time_format());
    }

    /**
     * Returns the date portion in the format configured in the osclass installation
     * @return string
     */
    public function getDateAsFormattedString() {
        return $this->format(osc_date_format());
    }

    /**
     * Returns the time portion in the format configured in the osclass installation
     * @return string
     */
    public function getTimeAsFormattedString() {
        return $this->format(osc_time_format());
    }

    /**
     * Return difference between $this and $now
     *
     * @param \Datetime|String $now
     * @param null $absolute
     * @return \DateInterval
     */
    public function diff($now = 'now', $absolute = null) {
        if(!($now instanceOf \DateTime)) {
            $now = new \DateTime($now);
        }
        return parent::diff($now, $absolute);
    }

    /**
     * Return Age in Years
     *
     * @param \Datetime|String $now
     * @return Integer
     */
    public function getAge($now = 'now') {
        return $this->diff($now)->format('%y');
    }
}
