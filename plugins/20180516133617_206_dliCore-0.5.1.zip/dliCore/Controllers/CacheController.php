<?php
namespace dliCore\Controllers;

use dliLib\Html\Form;
use dliLib\Html\Widgets\Tabs\Tab;
use dliLib\Html\Widgets\Tabs;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Cache\CacheManager;

/**
 * Provides functionality to configure dliCore caching component
 *
 * @author danlil
 *
 */
class CacheController extends AdminSecBaseController
{
    public function configureAction() {

        $this->_setHeading(__('dliCore - Configure Caching', 'dliCore'));

        $configurationTabs = new Tabs('cacheConfigTabs');

        $cacheManagerForm = CacheManager::getInstance()->getConfigForm();
        $cacheManagerForm->addDecorator(new Form\Admin\VerticalDecorator());
        $cacheManagerForm->process();
        
        $configurationTab = new Tab($cacheManagerForm->getAttribute('id').'_tab', __('General', 'dliCore'));
        $configurationTab->addChild($cacheManagerForm);
        $configurationTabs->addTab($configurationTab);

        foreach(CacheManager::getInstance()->getAllCacheSystems() as $cacheSystem) {
            $cacheSystemConfigForm = $cacheSystem->getConfigForm();

            if($cacheSystemConfigForm) {
                $cacheSystemConfigForm->addDecorator(new Form\Admin\VerticalDecorator());
                $cacheSystemConfigForm->process();
                $configurationTab = new Tab($cacheSystemConfigForm->getAttribute('id').'_tab', $cacheSystem->getName());
                $configurationTab->addChild($cacheSystemConfigForm);
                $configurationTabs->addTab($configurationTab);
            }
        }

        $this->_exportVariableToView('configurationTabs', $configurationTabs);
    }

    public function flushAction($cache) {
        $cache = CacheManager::getInstance()->getCacheSystem($cache);
        if($cache) {
            $cache->flush();
            osc_add_flash_info_message(sprintf(__('%s flushed', 'dliCore'), $cache->getName()), 'admin');
        }
        else {
            osc_add_flash_error_message(__('Unknown cache, unable to flush.', 'dliCore'), 'admin');
        }
        $this->getActionRoute('configure')->redirect();
    }
}

?>