<?php
namespace dliCore\Controllers;

use dliLib\CSS\CSSManager;
use dliLib\dliDateTime;
use dliLib\Html\Element\DataTable;
use dliLib\Html\Form;
use dliLib\Html\Form\Element\CronEditor;
use dliLib\Html\Widgets\Admin\PageHeader;
use dliLib\Html\Widgets\Admin\PageHeader\HelpButton;
use dliLib\Html\Widgets\Admin\PageHeader\PlusButton;
use dliLib\Html\Widgets\Admin\PageHeader\TextButton;
use dliLib\Job\AbstractJob;
use dliLib\Job\ClosureJob;
use dliLib\Job\JobManager;
use dliLib\Job\UserCreatedShellCommandJob;
use dliLib\JS\JSWrapper;
use dliLib\Lock\Lock;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Request;
use dliLib\Shell\ProcessManager;
use dliLib\Validator\ClosureValidator;
use dliLib\Validator\Dependency\ValidatorDependency;
use dliLib\Validator\Required;


/**
 * Class JobController
 *
 * Allows user to to create, edit and delete Jobs for the JobManager to handle
 *
 * @see JobManager
 * @package dliCore\Controllers
 */
class JobController extends AdminSecBaseController
{
    private $_helpButton = null;

    protected function _init()
    {
        // Create Page header
        $header = new PageHeader('JobManager');
        $this->_helpButton = new HelpButton();
        $this->_helpButton->setHelpText(__('The JobManager is used to execute recurring tasks. It functions much like a cron manager but does not require you to have access to or edit the cron table.', 'dliCore'));
        $header->addButton($this->_helpButton);
        $header->addButton(new PlusButton(null, __('Add Job', 'dliCore'), $this->getActionRoute('create')->getUrl()));
        $header->addButton(new TextButton(null, __('List Jobs', 'dliCore'), 'green', $this->getActionRoute('list')->getUrl()));

        if(JobManager::getInstance()->isEnabled()) {
            $header->addButton(new TextButton(null, __('Enabled - Click to Disable JobManager', 'dliCore'), 'green', $this->getActionRoute('disable')->getUrl()));
        }
        else {
            $header->addButton(new TextButton(null, __('Disabled - Click to Enable JobManager', 'dliCore'), 'red', $this->getActionRoute('enable')->getUrl()));
        }

        $this->_setHeader($header);
    }

    /**
     * @return Form
     * @throws \Exception
     */
    protected function _getJobForm() {
        $jobForm = new Form('job');
        $jobForm->setStoreDataCallbackFunction(array($this, 'storeJob'));

        $name = new Form\Element\Input('name');
        $name->setLabel(__('Name of Job', 'dliCore'));
        $name->addValidator(new Required());
        $jobForm->addChild($name);

        $owner = new Form\Element\Select('owner');
        foreach(PluginManager::getInstance()->getAllPlugins() as $plugin) {
            if($plugin == PluginManager::getInstance()->getCorePlugin()) {
                $owner->addOption(__('None', 'dliCore'), $plugin->getName());
            }
            else {
                $owner->addOption($plugin->getName(), $plugin->getName());
            }
        }
        $owner->setLabel(__('Owning Plugin', 'dliCore'));
        $owner->setValue('dliCore');
        $owner->setDescription(__('If owning Plugin is uninstalled, the Job will be deleted', 'dliCore'));
        $owner->addValidator(new Required());
        $jobForm->addChild($owner);

        /*$type = new Form\Element\Select('type');
        $type->addOption(__('Shell Command', 'dliCore'), 4);
        $type->addOption(__('Execute Route', 'dliCore'), 5);
        $type->setLabel(__('Job type', 'dliCore'));
        $type->setValue(AbstractJob::TYPE_USER_CREATED_SHELL_COMMAND);
        $type->addValidator(new Required());
        $jobForm->addChild($type);*/

        $command = new Form\Element\Input('command');
        $command->setLabel(__('Command to run', 'dliCore'));
        $command->addValidator(new Required());
        $jobForm->addChild($command);

        $cronEditor = new CronEditor('cronString');
        $jobForm->addChild($cronEditor);

        $jobForm->addChild(new Form\Element\Submit('submitButton', __('Create', 'dliCore')));

        $jobForm->addDecorator(new Form\Admin\VerticalDecorator());
        $jobForm->setStoreDataCallbackFunction(array($this, 'storeJob'));

        return $jobForm;
    }

    /**
     * @throws \Exception
     */
    public function listAction()
    {
        $this->_exportVariableToView('jobManagerIsEnabled', JobManager::getInstance()->isEnabled());
        $this->_exportVariableToView('processManagerIsEnabled', ProcessManager::getInstance()->isEnabled());

        $jobs = JobManager::getInstance()->getJobs();
        $userJobs = array();
        $pluginJobs = array();
        foreach ($jobs as $job) {
            if ($job->getCreator() == AbstractJob::CREATOR_USER) {
                $userJobs[] = $job;
            } else {
                $pluginJobs[] = $job;
            }
        }

        $userJobsTable = new DataTable('userJobs');
        $userJobsTable->setAttribute('class', 'table');
        $userJobsTable->setColumns(
            [
                'name' => __('Name', 'dliCore'),
                'owner' => __('Owner', 'dliCore'),
                'type' => __('Type', 'dliCore'),
                'command' => __('Command', 'dliCore'),
                'lastrun' => __('Last Run', 'dliCore'),
                'schedule' => __('Schedule', 'dliCore'),
                'nextrun' => __('Next Run', 'dliCore')
            ]
        );
        $userJobsTable->addOption('order', [[0, 'desc'], [1, 'desc']])->
        addOption('dom', 'BftB')->
        addOption('columnDefs',
            [
                [
                    'className' => 'process-name',
                    'targets' => 0
                ]
            ]
        )->
        addOption('select', ['style' => 'single'])->
        addOption('buttons',
            [
                [
                    'extend' => 'selected',
                    'text' => __('Edit', 'dliCore'),
                    'action' => new JSWrapper('function(e, dt, no, config) {
                            var rows = dt.rows( { selected: true } );
                            if(rows.count() > 0) {
                                var aData = dt.rows({ selected: true }).data().toArray();;
                                var job = aData[0];
                                window.location.href = job.editUrl;                                      
                            }
                        }')
                ],
                [
                    'extend' => 'selected',
                    'text' => __('Delete', 'dliCore'),
                    'action' => new JSWrapper('function(e, dt, no, config) {
                            var rows = dt.rows( { selected: true } );
                            if(rows.count() > 0) {
                                var aData = dt.rows({ selected: true }).data().toArray();;
                                var job = aData[0];
                                window.location.href = job.deleteUrl;                                      
                            }
                        }')
                ]
            ]
        );

        $userJobsTable->setData($userJobs, function ($job) {
            return [
                'name' => $job->getName(),
                'owner' => ($job->getOwner() == \dliLib\Plugin\Manager\PluginManager::getInstance()->getCorePlugin()->getName() ? __('None', 'dliCore') : $job->getOwner()),
                'type' => $job->getTypeAsString(),
                'command' => $job->getCommand(),
                'lastrun' => $job->getLastExecution(true),
                'schedule' => $job->getSchedule(),
                'nextrun' => $job->getNextExecution(),
                'editUrl' => $this->getActionRoute('edit')->getUrl(['name' => $job->getName(), 'owner' => $job->getOwner()]),
                'deleteUrl' => $this->getActionRoute('delete')->getUrl(['name' => $job->getName(), 'owner' => $job->getOwner()])
            ];
        });

        $this->_exportVariableToView('userJobsTable', $userJobsTable);

        $pluginJobsTable = new DataTable('pluginJobs');
        $pluginJobsTable->setAttribute('class', 'table');
        $pluginJobsTable->setColumns(
            [
                'name' => __('Name', 'dliCore'),
                'owner' => __('Owner', 'dliCore'),
                'type' => __('Type', 'dliCore'),
                'command' => __('Command', 'dliCore'),
                'lastrun' => __('Last Run', 'dliCore'),
                'schedule' => __('Schedule', 'dliCore'),
                'nextrun' => __('Next Run', 'dliCore')
            ]
        );
        $pluginJobsTable->addOption('order', [[0, 'desc'], [1, 'desc']])->
        addOption('dom', 'ft')->
        addOption('columnDefs',
            [
                [
                    'className' => 'process-name',
                    'targets' => 0
                ]
            ]
        );

        $pluginJobsTable->setData($pluginJobs, function ($job) {
            return [
                'name' => $job->getName(),
                'owner' => $job->getOwner(),
                'type' => $job->getTypeAsString(),
                'command' => ($job instanceof ClosureJob ? 'Closure' :  $job->getCommand()),
                'lastrun' => $job->getLastExecution(true) . ' (' . dliDateTime::createFromString($job->getLastExecution(true))->diffForHumans(dliDateTime::create(), true) . ' ago)',
                'schedule' => $job->getSchedule(),
                'nextrun' => $job->getNextExecution() . ' (in ' . dliDateTime::createFromString($job->getNextExecution())->diffForHumans(dliDateTime::create(), true) . ')'
            ];
        });

        $this->_exportVariableToView('pluginJobsTable', $pluginJobsTable);

        CSSManager::getInstance()->registerStyle('
            td.process-name {
                font-weight: bold;
            }
        ');
    }

    /**
     * @param Form $jobForm
     * @throws \Exception
     */
    private function _checkFormSubmission(Form $jobForm) {
        if($jobForm->isSubmitted()) {
            $jobForm->populate();

            $jobOwner = PluginManager::getInstance()->getPlugin($jobForm->getValue('owner'));

            if($jobOwner) {
                // Have we changed owner or name?
                $get = Request::getParamsAsArray('get');
                $originalJobName = null;
                if(array_key_exists('name', $get)) {
                    $originalJobName = $get['name'];
                }

                $originalOwner = null;
                if(array_key_exists('owner', $get)) {
                    $originalOwner = PluginManager::getInstance()->getPlugin($get['owner']);
                }

                $nameElement = $jobForm->getFormElementByName('name');

                if($originalJobName != $nameElement->getValue() || $originalOwner != $jobOwner) {
                    $vf = function ($value) use ($jobOwner) {
                        if (AbstractJob::exists(array($value, $jobOwner->getName()))) {
                            return false;
                        }
                        return true;
                    };


                    $nameValidator = new ClosureValidator($vf, sprintf(__('A job with this name already exists for %s', 'dliCore'), $jobForm->getValue('owner')));
                    $owner = $jobForm->getFormElementByName('owner');
                    $ownerDependency = new ValidatorDependency($owner, '==', $owner->getValue());
                    $nameValidator->addDependency($ownerDependency, 'notEqualTo');
                    $nameElement->addValidator($nameValidator);
                }
            }
            else {
                $vf = function ($value) {
                    return false;
                };
                $ownerElement = $jobForm->getFormElementByName('owner');
                $ownerElement->addValidator(new ClosureValidator($vf, sprintf(__('%s is an invalid Plugin', 'dliCore'), $jobForm->getValue('owner'))));
            }

            if($jobForm->validate()) {
                $jobForm->store();
                $this->getActionRoute('list')->redirect();
            }
        }
    }

    /**
     * @throws \Exception
     */
    public function createAction() {
        $jobForm = $this->_getJobForm();

        $this->_helpButton->setHelpText('
            <div>
                <strong>'.__('Name', 'dliCore').'</strong>: '.__('A name to identify the Job. Note that two Jobs tied to the same Owner can\'t have the same names', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Owning Plugin', 'dliCore').'</strong>: '.__('The Plugin to tie the Job to. If the owning Plugin is uninstalled the Job will be removed. Note that only Plugins built using the dliCore Framework are available to choose from.', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Command to run', 'dliCore').'</strong>: '.__('The command the Job should run. <strong><small>(i.e ping www.google.com)</small></strong>', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Schedule', 'dliCore').'</strong>: '.__('Use the control to build the schedule expression to determine how often the Job should run.', 'dliCore').'
            </div>
        ');

        $this->_checkFormSubmission($jobForm);
        $this->_exportVariableToView('jobForm', $jobForm);
    }

    /**
     * @param $name
     * @param $owner
     * @throws \Exception
     */
    public function editAction($name, $owner) {
        $owner = PluginManager::getInstance()->getPlugin($owner);

        if(!$owner) {
            $this->getActionRoute('list')->redirect();
        }

        $this->_helpButton->setHelpText('
            <div>
                <strong>'.__('Name', 'dliCore').'</strong>: '.__('A name to identify the Job. Note that two Jobs tied to the same Owner can\'t have the same names', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Owning Plugin', 'dliCore').'</strong>: '.__('The Plugin to tie the Job to. If the owning Plugin is uninstalled the Job will be removed. Note that only Plugins built using the dliCore Framework are available to choose from.', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Command to run', 'dliCore').'</strong>: '.__('The command the Job should run. <strong><small>(i.e ping www.google.com)</small></strong>', 'dliCore').'
            </div>
            <div>
                <strong>'.__('Schedule', 'dliCore').'</strong>: '.__('Use the control to build the schedule expression to determine how often the Job should run.', 'dliCore').'
            </div>
        ');

        $job = JobManager::getInstance()->getJobByNameForOwner($name, $owner);
        if(!$job) {
            $this->getActionRoute('list')->redirect();
        }

        $jobForm = $this->_getJobForm();

        $jobForm->setValue('name', $job->getName());
        $jobForm->setValue('owner', $owner->getName());
        $jobForm->setValue('type', $job->getType());
        $jobForm->setValue('command', $job->getCommand());
        $jobForm->setValue('cronString', $job->getSchedule());

        $jobForm->getFormElementByName('submitButton')->setText(__('Update', 'dliCore'));

        $this->_checkFormSubmission($jobForm);
        $this->_exportVariableToView('jobForm', $jobForm);
    }

    /**
     * @param $name
     * @param $owner
     * @throws \Exception
     */
    public function deleteAction($name, $owner) {
        $owner = PluginManager::getInstance()->getPlugin($owner);

        if(!$owner) {
            $this->getActionRoute('list')->redirect();
        }

        $job = JobManager::getInstance()->getJobByNameForOwner($name, $owner);

        if($job) {
            $lock = new Lock($job->getName());
            if ($lock->acquire()) {
                AbstractJob::delete($job);
            }
            $lock->release();
        }
        $this->getActionRoute('list')->redirect();
    }

    public function enableAction() {
        JobManager::getInstance()->enable();
        $this->getActionRoute('list')->redirect();
    }

    public function disableAction() {
        JobManager::getInstance()->disable();
        $this->getActionRoute('list')->redirect();
    }

    /**
     * Store the Job Data
     *
     * @param Form $form
     * @throws \Exception
     */
    public function storeJob($form) {
        $jobOwner = PluginManager::getInstance()->getPlugin($form->getValue('owner'));
        if($jobOwner) {

            // Are we renaming an existing Job or moving it to a new owner?
            $get = Request::getParamsAsArray('get');
            if(array_key_exists('name', $get)) {
                $originalJobName = $get['name'];
            }
            else {
                $originalJobName = $form->getValue('name');
            }

            if(array_key_exists('owner', $get)) {
                $originalOwner = PluginManager::getInstance()->getPlugin($get['owner']);
                if(!$originalOwner) {
                    $originalOwner = $jobOwner;
                }
            }
            else {
                $originalOwner = $jobOwner;
            }

            /*if($form->getValue('type') == AbstractJob::TYPE_USER_CREATED_SHELL_COMMAND) {
                $job = UserCreatedShellCommandJob::find([$originalJobName, $originalOwner->getName()]);
                if (!$job) {
                    $job = new UserCreatedShellCommandJob();
                }
            }
            else {
                $job = UserCreatedRouteJob::find([$originalJobName, $originalOwner->getName()]);
                if (!$job) {
                    $job = new UserCreatedRouteJob();
                }
            }*/

            $job = UserCreatedShellCommandJob::find([$originalJobName, $originalOwner->getName()]);
            if (!$job) {
                $job = new UserCreatedShellCommandJob();
            }

            $job->setName($form->getValue('name'));
            $job->setCommand($form->getValue('command'));
            $job->setSchedule($form->getValue('cronString'));
            $job->setOwner($jobOwner);
            $job->save();
        }
    }
}