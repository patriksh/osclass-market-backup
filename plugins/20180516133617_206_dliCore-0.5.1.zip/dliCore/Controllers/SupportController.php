<?php
namespace dliCore\Controllers;

use dliCore\Forms\Support\RequestSupportForm;
use dliLib\Html\Form\Admin\VerticalDecorator;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Plugin\Controller\AdminSecBaseController;

/**
 * Provides functionality to request support for any installed Plugin
 *
 * @author danlil
 *
 */
class SupportController extends AdminSecBaseController
{
    public function _init()
    {
        $this->_setHeading(__('dliCore - Support', 'dliCore'));
    }

    public function requestSupportAction($defaultPlugin = '([a-zA-Z0-9_.-]*)') {
        $requestSupportForm = new RequestSupportForm('requestSupportForm');
        $requestSupportForm->addDecorator(new VerticalDecorator());
        if($defaultPlugin) {
            $requestSupportForm->setDefaultPlugin($defaultPlugin);
        }

        if($requestSupportForm->isSubmitted()) {
            $requestSupportForm->populate();
            if($requestSupportForm->validate()) {
                $requestSupportForm->store();
                $this->_refresh();
            }
        }

        $this->_exportVariableToView('requestSupportForm', $requestSupportForm);
    }

    public function howToAction() {
        $this->_setHeading(__('Build plugins with dliCore', 'dliCore'));
    }
}

?>