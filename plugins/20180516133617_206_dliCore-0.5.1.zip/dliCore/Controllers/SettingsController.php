<?php
namespace dliCore\Controllers;

use dliCore\Forms\Settings\StorageForm;
use dliLib\Cache\CacheManager;
use dliLib\Html\Form\Admin\VerticalDecorator;
use dliLib\Html\Widgets\Tabs\Tab;
use dliLib\Html\Widgets\Tabs;
use dliLib\Plugin\Controller\AdminSecBaseController;

/**
 * Provides functionality to configure dliCore caching component
 *
 * @author danlil
 *
 */
class SettingsController extends AdminSecBaseController
{
    public function configureAction() {

        $this->_setHeading(__('dliCore Settings', 'dliCore'));

        $configTabs = new Tabs('authenticatorTabs');

        // Paths
        $tab = new Tab('paths_tab', __('Paths', 'dliCore'));

            $storageForm = new StorageForm('dliCorePathsConfig');
            $storageForm->process();

        $tab->addChild($storageForm);
        $configTabs->addTab($tab);

            // Cache Manager Settings Tab
            /*$tab = new Tab('cacheManager_tab', __('Cache Manager', 'dliCore'));
            $cacheManagerConfigurationTabs = new Tabs('cacheConfigTabs');

            $cacheManagerForm = CacheManager::getInstance()->getConfigForm();
            $cacheManagerForm->addDecorator(new VerticalDecorator());
            $cacheManagerForm->process();

            $configurationTab = new Tab($cacheManagerForm->getAttribute('id').'_tab', __('General', 'dliCore'));
            $configurationTab->addChild($cacheManagerForm);
            $cacheManagerConfigurationTabs->addTab($configurationTab);

            foreach(CacheManager::getInstance()->getAllCacheSystems() as $cacheSystem) {
                $cacheSystemConfigForm = $cacheSystem->getConfigForm();

                if($cacheSystemConfigForm) {
                    $cacheSystemConfigForm->addDecorator(new VerticalDecorator());
                    $cacheSystemConfigForm->process();
                    $configurationTab = new Tab($cacheSystemConfigForm->getAttribute('id').'_tab', $cacheSystem->getName());
                    $configurationTab->addChild($cacheSystemConfigForm);
                    $cacheManagerConfigurationTabs->addTab($configurationTab);
                }
            }

        $tab->addChild($cacheManagerConfigurationTabs);
        $configTabs->addTab($tab);*/

        $this->_exportVariableToView('configForm', $configTabs);
    }
}

?>