<?php
namespace dliCore\Controllers;

use dliLib\Html\Form;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Plugin\Route\AbstractRoute;
use dliLib\Request;

/**
 * Provides functionality to request support for any installed Plugin
 *
 * @author danlil
 *
 */
class DonationController extends AdminSecBaseController
{
    public function donateAction($currencyCode = '([a-zA-Z0-9_.-]*)') {
        $donationForm = new Form('donationForm');
        $currencyOptions = new Form\Element\Select('currencyCode');
        $currencyOptions->addOption('EUR', 'EUR');
        $currencyOptions->addOption('GBP', 'GBP');
        $currencyOptions->addOption('USD', 'USD');
        $currencyOptions->setValue($currencyCode);

        $donationForm->addChild($currencyOptions);
        $amountInput = new Form\Element\Number('donateAmount', 0);
        $donationForm->addChild($amountInput);
        $donationForm->addChild(new Form\Element\Submit(null, 'submit', 'Donate'));
        $donationForm->addDecorator(new Form\Admin\HorizontalDecorator());

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $donationForm->populate();

            if($donationForm->validate()) {
                try {
                    $this->_doDonate(Request::getParam('currencyCode'), Request::getParam('donateAmount'), Request::getParam('subject'), Request::getParam('message'));
                } catch (\Exception $e) {
                    \View::newInstance()->_exportVariableToView('supportInqueryError', __('Error sending email', 'dliCore'));
                }
            }
        }
        if($currencyCode) {
            \View::newInstance()->_exportVariableToView('currencyCode', $currencyCode);
        }

        $this->_exportVariableToView('donationForm', $donationForm);

        $this->_setHeading(__('dliCore - Donate', 'dliCore'));
    }

    private function _doDonate($currencyCode, $donateAmount) {
        if($_POST['donateAmount'] > 0) {
            // Redirect to PayPal
            header('Location: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&item_name=Donation for dliCore&amount='.$donateAmount.'&currency_code='.$currencyCode.'&business=damien_@hotmail.com&cbt=Return to your admin interface&return='.AbstractRoute::getRoute('dliCore', 'Donation', 'donated')->getUrl().'&cancel_return='.AbstractRoute::getRoute('dliCore', 'Donation', 'canceled')->getUrl());
        }

        /*$message = "Website: " . osc_page_title() . "\n" .
            "Site: " . osc_base_url() . "\n" .
            "Contact date: " . date('c', time()) . "\n" .
            "Contact email: " . $senderEmail . "\n" .
            "\n" .
            "Support requested for: " . $pluginName . "\n" .
            "Subject: " . $subject . "\n".
            "Message: \n\n" .
            $message .
            "\n\n\n\n" .
            "Installed dliPlugins: \n" .
            "---------------------\n" .
            $pluginsStr .
            "---------------------\n";


        $emailParams =  array('subject'  => 'OSC Support - ' . $pluginName . ''
        ,'to'       => $plugin->getSupportEmail()
        ,'reply_to' => $senderEmail
        ,'body'     => nl2br($message)
        ,'alt_body' => $message);

        osc_sendMail($emailParams);*/
    }

    private function donatedAction() {
    }

    private function canceledAction() {
    }
}

?>