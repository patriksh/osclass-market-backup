<?php
namespace dliCore\Controllers;

use dliLib\Html\Element;
use dliLib\Html\Form;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Cache\CacheManager;
/**
 * Provides functionality to configure dliCore caching component
 *
 * @author danlil
 *
 */
class EmailController extends AdminSecBaseController
{
    public function configureAction() {

        $this->_setHeading(__('dliCore - Configure Caching', 'dliCore'));

        // Create form
        $cacheConfigForm = new Form('cacheConfig');
        $cacheConfigForm->addDecorator(new Form\Admin\TabbedDecorator());

        // Add manager config form
        $cacheManagerForm = &CacheManager::getInstance()->getConfigSubForm();
        $cacheConfigForm->addSubForm($cacheManagerForm);

        $cacheSystems = CacheManager::getInstance()->getAllCacheSystems();

        foreach($cacheSystems as $cacheSystem) {
            $cacheSystemPreferences = $cacheSystem->getAllPreferences();
            if(!$cacheSystemPreferences) {
                continue;
            }

            $cacheSystemForm = $cacheSystem->getConfigSubForm();

            if(Request::getParam('submittedFormId') === $cacheSystemForm->getAttribute('id')) {
                $cacheSystemForm->populate();
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    if ($cacheSystemForm->validate()) {
                        $this->_saveCacheSettings($cacheSystemForm);
                    }
                }
            }

            $cacheConfigForm->addSubForm($cacheSystemForm);
        }

        $cacheConfigForm->addChild(new Form\Element\Submit(null, __('Save Settings', 'dliCore'), array('class' => 'btn btn-submit')));

        if($cacheConfigForm->isSubmitted()) {
            $cacheConfigForm->populate();
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                if ($cacheConfigForm->validate()) {
                    $this->_saveCacheSettings($cacheConfigForm);
                }
            }
        }

        \View::newInstance()->_exportVariableToView('cacheConfigForm', $cacheConfigForm);
    }

    private function _saveCacheSettings($cacheManagerForm) {
        foreach($cacheManagerForm->getAllFormElements() as $element) {
            if($element instanceof Form\Element\Preference) {
                $element->storeValue();
            }
        }
    }
}

?>