<?php
namespace dliCore\Controllers;

use dliLib\Plugin\Controller\BaseController;

/**
 * Controller to act as a js file manager
 * It allows us to queue Js files with routes and have them run using the Controller/View model like normal calls.
 * That allows for easy adaptions of Js files to different themes by using different view files.
 *
 * @author danlil
 *
 */
class JsController extends BaseController
{
    public function serverTimeAction() {
        header("Content-type: text/plain");
        header("Cache-Control: no-cache, must-revalidate"); //HTTP 1.1
        header("Pragma: no-cache"); //HTTP 1.0
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past
        $now = new \DateTime();
        echo $now->format("D M d Y H:i:s O")."\n";
    }
}

?>