<?php
namespace dliCore\Controllers;

use dliLib\CSS\CSSManager;
use dliLib\dliDateTime;
use dliLib\Html\Element\DataTable;
use dliLib\Html\Widgets\Admin\PageHeader;
use dliLib\Html\Widgets\Admin\PageHeader\HelpButton;
use dliLib\Html\Widgets\Admin\PageHeader\TextButton;
use dliLib\Html\Widgets\Chart;
use dliLib\JS\JSManager;
use dliLib\JS\JSWrapper;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Shell\ProcessManager;

/**
 * Class ProcessController
 *
 * Responsible for managing processes
 * @see ProcessManager
 * @package dliCore\Controllers
 */
class ProcessController extends AdminSecBaseController
{
    protected function _init()
    {
        // Create Page header
        $header = new PageHeader('ProcessManager');
        $helpButton = new HelpButton();
        $helpButton->setHelpText(__('The ProcessManager is responsible for managing running processes. It monitors started processes, restarts processes and cleans up after processes. If disabled, no processes can be started through the dliCore Framework', 'dliCore'));
        $header->addButton($helpButton);

        if(ProcessManager::getInstance()->isEnabled()) {
            $header->addButton(new TextButton(null, __('Enabled - Click to Disable ProcessManager', 'dliCore'), 'green', $this->getActionRoute('disable')->getUrl()));
        }
        else {
            $header->addButton(new TextButton(null, __('Disabled - Click to Enable ProcessManager', 'dliCore'), 'red', $this->getActionRoute('enable')->getUrl()));
        }

        $this->_setHeader($header);
    }

    public function listAction() {
        $metricCharts = [];

        $this->_exportVariableToView('processManagerIsEnabled', ProcessManager::getInstance()->isEnabled());
        if(ProcessManager::getInstance()->isEnabled()) {
            ProcessManager::getInstance()->processProcesses(true);
        }

        $runningProcessTable = new DataTable('runningProcesses');
        $runningProcessTable->setAttribute('class', 'table');
        $runningProcessTable->setColumns(
            [
                '',
                'pid' => 'PID',
                'command' => __('Command', 'dliCore'),
                'started' => __('Started', 'dliCore')
            ]
        );
        $runningProcessTable->addOption('columnDefs',
            [
                [
                    'className' => 'details-control',
                    'sortable' => false,
                    'data' => null,
                    'defaultContent' => '',
                    'render' => new JSWrapper('function() {
                        return "<span class=\"ui-icon ui-icon-plusthick\"></span>";
                    }'),
                    'targets' => 0
                ]
            ])->
        addOption('order', [[1, 'desc']])->
        addOption('select', ['selector' => 'td:not(:first-child)', 'style' => 'single'])->
        addOption('dom', 'BftB')->
        addOption('buttons',
            [
                [
                    'extend' => 'selected',
                    'text' => __('Kill', 'dliCore'),
                    'action' => new JSWrapper('function(e, dt, no, config) {
                        var rows = dt.rows( { selected: true } );
                        if(rows.count() > 0) {
                            var aData = dt.rows({ selected: true }).data().toArray();;
                            var process = aData[0];
                            
                            if(process.description) {
                                $("#description").text(process.description);
                            }
                
                            $("#killProcessDialog").dialog({
                                modal: true,
                                buttons : {
                                    "' . __('Kill', 'dliCore') . '" : function() {
                                        window.location.href = process.killUrl;
                                    },
                                    "' . __('Cancel', 'dliCore') . '" : function() {
                                        $(this).dialog("close");
                                    }
                                }
                            });
                            $("#killProcessDialog").dialog("open");                                                       
                        }
                    }')
                ],
            ]
        );

        JSManager::getInstance()->registerScript('
            function formatProcessData ( d ) {
                // `d` is the original data object for the row
                return \'<table class="table">\'+
                    \'<thead><th>'.__('Output', 'dliCore').'</th><th style="color: red">'.__('Errors', 'dliCore').'</th></thead>\' +
                    \'<tr style="background-color: #f3f3f3">\'+
                        \'<td>\'+d.stdout+\'</td>\'+
                        \'<td style="color: red">\'+d.stderr+\'</td>\'+
                \'</table>\';
            }
             
        ', JSManager::LOCATION_DOCUMENT_READY);

        JSManager::getInstance()->registerScript('
            // Add event listener for opening and closing details
            $("#runningProcesses tbody").on("click", "td.details-control", function () {
                var tr = $(this).closest("tr");                
                var row = runningProcesses.row( tr );
                var tdi = tr.find("span.ui-icon");                
                var pid = row.data().pid;
         
                if ( row.child.isShown() ) {
                    $("#"+pid+"_MetricsChart_table").detach().appendTo("#chartContainer");
                    // This row is already open - close it                    
                    row.child.hide();                    
                    tr.removeClass("shown");
                    tdi.first().removeClass("ui-icon-minusthick");
                    tdi.first().addClass("ui-icon-plusthick");                    
                }
                else {
                    // Open this row
                    row.child( formatProcessData(row.data()) ).show();
                    $("#"+pid+"_MetricsChart_table").detach().prependTo($("td:first", row.child()));
                    tr.addClass("shown");
                    tdi.first().removeClass("ui-icon-plusthick");
                    tdi.first().addClass("ui-icon-minusthick");
                }
            } );
            
            $("#closedProcesses tbody").on("click", "td.details-control", function () {
                var tr = $(this).closest("tr");
                var row = closedProcesses.row( tr );
                var tdi = tr.find("span.ui-icon");
                var pid = row.data().pid;                
         
                if ( row.child.isShown() ) {
                    $("#"+pid+"_MetricsChart_table").detach().appendTo("#chartContainer");
                    // This row is already open - close it
                    row.child.hide();
                    tr.removeClass("shown");
                    tdi.first().removeClass("ui-icon-minusthick");
                    tdi.first().addClass("ui-icon-plusthick");
                }
                else {
                    // Open this row
                    row.child( formatProcessData(row.data()) ).show();
                    $("#"+pid+"_MetricsChart_table").detach().prependTo($("td:first", row.child()));
                    tr.addClass("shown");                    
                    tdi.first().removeClass("ui-icon-plusthick");
                    tdi.first().addClass("ui-icon-minusthick");
                }
            } );
        ', JSManager::LOCATION_DOCUMENT_READY);

        $runningProcessTable->setData(ProcessManager::getInstance()->getRunningProcesses(), function($process) use (&$metricCharts) {
            $chart = new Chart($process->getPid() . '_MetricsChart');
            $chart->setType('LineChart');
            $chart->setColumns(['Timestamp', 'CPU', 'Memory']);
            foreach($process->getProcessMetrics() as $timestamp => $metric) {
                $chart->addRow([(string)dliDateTime::createFromTimestamp($timestamp), $metric['cpu'], $metric['mem']]);
            }
            $metricCharts[] = $chart;

           return [
               'pid' => $process->getPid(),
               'command' => ($process->getName() ? $process->getName() : $process->getExecutedCommand()),
               'started' => $process->getStartTime(true) . ' (' . dliDateTime::createFromString($process->getStartTime(true))->diffForHumans(dliDateTime::create(), true) . ' ago)',
               'name' => $process->getName(),
               'description' => $process->getDescription(),
               'killUrl' => $this->getActionRoute('kill')->getUrl(['pid' => $process->getPid()]),
               'stdout' => nl2br($process->getStdOut()),
               'stderr' => nl2br($process->getStdErr())];
        });

        $this->_exportVariableToView('runningProcessTable', $runningProcessTable);

        $closedProcessTable = new DataTable('closedProcesses');
        $closedProcessTable->setAttribute('class', 'table');
        $closedProcessTable->setColumns(
            [
                '',
                'pid' => 'PID',
                'command' => __('Command', 'dliCore'),
                'started' => __('Started', 'dliCore'),
                'finished' => __('Finished', 'dliCore'),
                'runtime' => __('Runtime', 'dliCore'),
                'status' => __('Exit Status', 'dliCore'),
            ]
        );
        $closedProcessTable->addOption('columnDefs',
            [
                [
                    'className' => 'details-control',
                    'sortable' => false,
                    'data' => null,
                    'defaultContent' => '',
                    'render' => new JSWrapper('function() {
                        return "<span class=\"ui-icon ui-icon-plusthick\"></span>";
                    }'),
                    'targets' => 0
                ]
            ])->
        addOption('order', [[1, 'desc']])->
        addOption('dom', 'ft');

        $closedProcessTable->setData(ProcessManager::getInstance()->getClosedProcesses(), function($process) use (&$metricCharts) {
            $chart = new Chart($process->getPid() . '_MetricsChart');
            $chart->setType('LineChart');
            $chart->setColumns(['Timestamp', 'CPU', 'Memory']);
            foreach($process->getProcessMetrics() as $timestamp => $metric) {
                $chart->addRow([(string)dliDateTime::createFromTimestamp($timestamp), $metric['cpu'], $metric['mem']]);
            }
            $metricCharts[] = $chart;

            return [
                'pid' => $process->getPid(),
                'command' => ($process->getName() ? $process->getName() : $process->getExecutedCommand()),
                'started' => $process->getStartTime(true) . ' (' . dliDateTime::createFromString($process->getStartTime(true))->diffForHumans(dliDateTime::create(), true) . ' ago)',
                'finished' => $process->getEndTime(true) . ' (' . dliDateTime::createFromString($process->getEndTime(true))->diffForHumans(dliDateTime::create(), true) . ' ago)',
                'runtime' => dliDateTime::createFromString($process->getStartTime(true))->diffForHumans(dliDateTime::createFromString($process->getEndTime(true)), true),
                'status' => $process->getStatus(true),
                'stdout' => nl2br($process->getStdOut()),
                'stderr' => nl2br($process->getStdErr())
            ];
        });

        CSSManager::getInstance()->registerStyle('
            th.details-control {
                max-width: 8px;
                margin: 0 0 0 0;
                padding: 0 0 0 0;
            }
            td.details-control {
                text-align:center;
                color:forestgreen;
                cursor: pointer;
                max-width: 8px;
                margin: 0 0 0 0;
                padding: 0 0 0 0;
            }
            tr.shown td.details-control {
                text-align:center; 
                color:red;
            }
        ');

        $this->_exportVariableToView('runningProcessTable', $runningProcessTable);
        $this->_exportVariableToView('closedProcessTable', $closedProcessTable);
        $this->_exportVariableToView('metricCharts', $metricCharts);
    }

    public function killAction($pid) {
        ProcessManager::getInstance()->processProcesses(true);
        $process = ProcessManager::getInstance()->getProcessByPid($pid);
        if($process) {
            $process->kill();
        }
        $this->getActionRoute('list')->redirect();
    }

    public function enableAction() {
        ProcessManager::getInstance()->processProcesses(true);
        ProcessManager::getInstance()->enable();
        $this->getActionRoute('list')->redirect();
    }

    public function disableAction() {
        ProcessManager::getInstance()->processProcesses(true);
        ProcessManager::getInstance()->disable();
        $this->getActionRoute('list')->redirect();
    }
}