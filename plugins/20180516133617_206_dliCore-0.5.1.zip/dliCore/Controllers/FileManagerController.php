<?php
namespace dliCore\Controllers;

use dliLib\Html\Form;
use dliLib\Html\Widgets\FileManager;
use dliLib\Plugin\Controller\AdminSecBaseController;

/**
 * Provides functionality to request support for any installed Plugin
 *
 * @author danlil
 *
 */
class FileManagerController extends AdminSecBaseController
{
    public function indexAction() {
        $this->_setHeading(__('dliCore FileManager', 'dliCore'));
    }

    public function configureAction() {
        $this->_setHeading(__('dliCore FileManager Configuration', 'dliCore'));

        $form = FileManager::getGlobalConfigurationForm();
        $form->addDecorator(new Form\Admin\VerticalDecorator());

        // Check if form is submitted and valid
        if($form->isSubmitted()) {
            $form->populate();
            if ($form->validate()) {
                $form->store();
                osc_add_flash_info_message(__('Settings Saved', 'dliCore'), 'admin');
            }
        }

        $this->_exportVariableToView('configForm', $form);
    }

    public function openAction()
    {
        $this->_setHeading(__('dliCore FileManager', 'dliCore'));
        $fileManager = new FileManager('dliCoreFileManager');
        $fileManager->setType(FileManager::TYPE_URL);
        $fileManager->setRoot('');

        $this->_exportVariableToView('fileManager', $fileManager);
    }
}

?>