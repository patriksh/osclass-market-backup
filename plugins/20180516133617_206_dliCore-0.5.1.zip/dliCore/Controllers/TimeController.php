<?php
namespace dliCore\Controllers;
use dliLib\Plugin\Controller\BaseController;

/**
 * Provides functionality to request support for any installed Plugin
 *
 * @author danlil
 *
 */
class TimeController extends BaseController
{
    public function serverTimeAction() {
        $now = new \DateTime();
        echo $now->format("M j, Y H:i:s O")."\n";
    }
}

?>