<?php
namespace dliCore\Controllers;

use dliLib\Plugin\Controller\AdminSecBaseController;
use FluentDOM;

/**
 * Provides functionality to request support for any installed Plugin
 *
 * @author danlil
 *
 */
class AdminController extends AdminSecBaseController
{
    public function indexAction() {
        $this->_setHeading(__('dliCore Dashboard', 'dliCore'));

        $plugins = [];

        $query = FluentDOM::QueryCss(osc_file_get_contents('https://market.osclass.org/user/profile/665'), 'text/html');
        $query->find('h2.t-heading')->next('.row')->find('.col-xs-12')->each(
            function($node, $index) use (&$plugins) {
                $pluginDoc = FluentDOM::QueryCss($node, 'text/html');

                $plugin['name']         = trim($pluginDoc->find('.title')->first()->text());
                $plugin['description']  = trim($pluginDoc->find('.description')->first()->text());
                $plugin['url']          = trim($pluginDoc->find('a')->first()->attr('href'));
                $plugin['image']        = trim($pluginDoc->find('img')->first()->attr('src'));
                $plugin['price']        = trim($pluginDoc->find('.price')->first()->text());
                $plugin['sales']        = trim($pluginDoc->find('.sales-container')->first()->text());
                $plugin['tag']          = explode('_', substr($plugin['url'], strrpos($plugin['url'], '/') + 1))[0];

                $plugins[] = $plugin;
            }
        );
        //$query->find('h2.t-heading')->siblings('div.row')->find('div.col-xs-12');

        $this->_exportVariableToView('dliPlugins', $plugins);
    }

    public function phpinfoAction() {
        ob_start();
        @phpinfo();
        $phpinfo = ob_get_contents();
        ob_end_clean();
        $this->_exportVariableToView('phpinfo', $phpinfo);
    }
}

?>