<?php
namespace dliCore\Forms\Settings;


use dliLib\Html\AjaxForm;
use dliLib\Html\Element\H2;
use dliLib\Html\Form\Admin\VerticalDecorator;
use dliLib\Html\Form\Element\Preference;
use dliLib\Html\Form\Element\Submit;
use dliLib\IO\FileSystem;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Validator\ClosureValidator;
use dliLib\Validator\Required;
use dliLib\Validator\WritableFolder;

class StorageForm extends AjaxForm
{
    /**
     * StorageForm constructor.
     * @param $id
     * @param array $attributes
     * @throws \Exception
     */
    public function __construct($id, array $attributes = array())
    {
        parent::__construct($id, $attributes);
        $this->setAjaxSubmitText(__('Saving', 'dliCore'));
        $this->setAjaxDoneText(__('Settings Saved', 'dliCore'));
        $this->setAjaxErrorText(__('An error occurred while saving settings', 'dliCore'));
        $this->addDecorator(new VerticalDecorator());

        $this->setStoreDataCallbackFunction(
            function($form) {
                /** @var $form AjaxForm */
                foreach($form->getAllFormElements() as $element) {
                    if($element instanceof Preference) {
                        if($element->isValueChanged()) {
                            $oldLocation = $element->getValueBeforeChange();
                            $newLocation = rtrim($element->getValue(), '/\\');
                            PluginManager::getInstance()->getCorePlugin()->runHook($element->getAttribute('id').'Changed', $oldLocation, $newLocation);
                            $element->setValue($newLocation);
                            $element->storeValue();
                        }
                    }
                }
            }
        );

        $notPublic = function($value) {
            if(FileSystem::isPublic($value, true)) {
                return false;
            }
            return true;
        };

        $isPublic = function($value) {
            if(FileSystem::isPublic($value, true)) {
                return true;
            }
            return false;
        };

        $this->addChild(new H2(null, __('Temporary Storage Directory', 'dliCore')));
        $prefElement = new Preference(PluginManager::getInstance()->getCorePlugin()->getPreference('PluginsTempBaseDirectory'));
        $prefElement->addValidator(new Required());
        $prefElement->addValidator(new WritableFolder());
        $prefElement->addValidator(new ClosureValidator($notPublic, __('Folder is publicly available', 'dliCore')));
        $this->addChild($prefElement);

        $this->addChild(new H2(null, __('Private Storage Directory', 'dliCore')));
        $prefElement = new Preference(PluginManager::getInstance()->getCorePlugin()->getPreference('PluginsPrivateBaseDirectory'));
        $prefElement->addValidator(new Required());
        $prefElement->addValidator(new WritableFolder());
        $prefElement->addValidator(new ClosureValidator($notPublic, __('Folder is publicly available', 'dliCore')));

        $this->addChild($prefElement);

        $this->addChild(new H2(null, __('Public Storage Directory', 'dliCore')));
        $prefElement = new Preference(PluginManager::getInstance()->getCorePlugin()->getPreference('PluginsPublicBaseDirectory'));
        $prefElement->addValidator(new Required());
        $prefElement->addValidator(new WritableFolder());
        $prefElement->addValidator(new ClosureValidator($isPublic, __('Folder must be publicly available', 'dliCore')));
        $this->addChild($prefElement);

        $this->addChild(new Submit('null', __('Save', 'dliCore')));
    }
}