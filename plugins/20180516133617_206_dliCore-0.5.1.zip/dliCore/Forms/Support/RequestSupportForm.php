<?php

namespace dliCore\Forms\Support;

use dliLib\Html\Element\P;
use dliLib\Html\Form;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Validator\Email;
use dliLib\Validator\Required;

class RequestSupportForm extends Form
{
    protected $_domainInfo = [];

    public function __construct($id, array $attributes = [], $needEmail = true, $needName = true)
    {
        parent::__construct($id, $attributes);
        $this->setTitle(__('Request support', 'dliCore'));
        $this->setDescription(__('Allows you to request support for dliCore based plugins from the plugins author', 'dliCore'));

        $plugins = PluginManager::getInstance()->getAllPlugins();

        $pluginSelect = new Form\Element\Select('pluginName');
        $pluginSelect->setLabel(__('Plugin', 'dliCore'));
        $pluginSelect->addValidator(new Required(__('You must select a Plugin to be able to request any support', 'dliCore')));
        foreach($plugins as $plugin) {
            $pluginSelect->addOption($plugin->getDisplayName(), $plugin->getName());
            $this->_domainInfo[$plugin->getName()] = sprintf(__('Make sure you have whitelisted <strong>%s</strong> so you do not miss any reply regarding your inquery.', 'dliCore'), $plugin->getSupportEmail());
        }
        $this->addChild($pluginSelect);

        $helpBlock = new P(null);
        $helpBlock->setAttribute('class', 'help-block');
        $helpBlock->setInnerHtml(__('Note that support through this form is only available for the plugins listed above.', 'dliCore'));
        $this->addChild($helpBlock);

        $helpBlock = new P('supportWhitelistInfo');
        $helpBlock->setAttribute('class', 'help-block');
        $this->addChild($helpBlock);

        $email = new Form\Element\Email('senderEmail');
        $email->setAttribute('autocomplete', 'off');
        $email->setLabel(__('Email address', 'dliCore'));
        $email->setValue(osc_logged_admin_email());
        $email->addValidator(new Email(__('You must provide your email address in order to receive a reply', 'dliCore')));
        $this->addChild($email);

        $subject = new Form\Element\Input('subject');
        $subject->setAttribute('autocomplete', 'off');
        $subject->setLabel(__('Subject', 'dliCore'));
        $subject->addValidator(new Required(__('You must enter a descriptive subject', 'dliCore')));
        $this->addChild($subject);

        $message = new Form\Element\TextArea('message');
        $message->setAttribute('style', 'height: 200px; width: 80%; max-width: 700px');
        $message->setLabel(__('Message', 'dliCore'));
        $message->addValidator(new Required(__('You can not send an empty message', 'dliCore')));
        $this->addChild($message);

        $this->addChild(new Form\Element\Submit(null, __('Send', 'dliSocialConnector')));
    }

    public function setDefaultPlugin($name) {
        $this->getFormElementByName('pluginName')->setValue($name);
    }

    protected function _build()
    {
        $html = parent::_build();
        $html .= '<script>
                    $( document ).ready(function() {
                        var selectedPlugin = $("#pluginName").val();
                        $("#pluginName").append($("#pluginName option").remove().sort(function(a, b) {
                            var at = $(a).text().toLowerCase(), bt = $(b).text().toLowerCase();
                            return (at > bt)?1:((at < bt)?-1:0);
                        }));
                        $("#pluginName").val(selectedPlugin);

                        $("#pluginName").change(function() {
                            switch($(this).val()) {';

        foreach($this->_domainInfo as $pluginName => $infoText) {
            $html .= 'case "' . $pluginName . '":
                        $("#supportWhitelistInfo").html("' . $infoText . '");
                              break;';
        }

                $html .= '}
                    });
                    $("#pluginName").change();
                });</script>';
        return $html;
    }

    public function store() {
        try {
            $this->_sendSupportRequest($this->getValue('pluginName'), $this->getValue('senderEmail'), $this->getValue('subject'),$this->getValue('message'));
            osc_add_flash_info_message(__('Support request sent', 'dliCore'), 'admin');
        }
        catch(\Exception $e) {
            osc_add_flash_error_message(__('Error sending support request', 'dliCore'), 'admin');
        }
    }

    private function _sendSupportRequest($pluginName, $senderEmail, $subject, $message) {
        $pluginsStr = '';
        foreach(PluginManager::getInstance()->getAllPlugins() as &$plugin) {
            $pluginsStr .= $plugin->getName() . ' (' . $plugin->getVersion() . ') - ' . ($plugin->isEnabled() ? 'enabled' : 'disabled') . "\n";
        }

        $message = "Website: " . osc_page_title() . "\n" .
            "Site: " . osc_base_url() . "\n" .
            "Contact date: " . date('c', time()) . "\n" .
            "Contact email: " . $senderEmail . "\n" .
            "\n" .
            "Support requested for: " . $pluginName . "\n" .
            "Subject: " . $subject . "\n".
            "Message: \n\n" .
            $message .
            "\n\n\n\n" .
            "Installed dliPlugins: \n" .
            "---------------------\n" .
            $pluginsStr .
            "---------------------\n";


        $emailParams =  array('subject'  => 'OSC Support - ' . $pluginName . ''
        ,'to'       => $plugin->getSupportEmail()
        ,'reply_to' => $senderEmail
        ,'body'     => nl2br($message)
        ,'alt_body' => $message);

        osc_sendMail($emailParams);
    }
}