<link href="<?php echo $this->plugin->getPluginUrl().'assets/css/animate.css'?>" rel="stylesheet" type="text/css">
<script>
    Number.prototype.formatMoney = function (places, symbol, thousand, decimal) {
        places = !isNaN(places = Math.abs(places)) ? places : 2;
        symbol = symbol !== undefined ? symbol : "$";
        thousand = thousand || ",";
        decimal = decimal || ".";
        var number = this,
            negative = number < 0 ? "-" : "",
            i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
        return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
    };

    var serverTimeLastFetched = null;
    var serverCurrentTime = null;

    (function ($) {
        $.countdown.regionalOptions['<?php echo osc_current_user_locale()?>'] = {
            labels: ['<?php _e('Years', 'dliCore')?>', '<?php _e('Months', 'dliCore')?>', '<?php _e('Weeks', 'dliCore')?>', '<?php _e('Days', 'dliCores')?>', '<?php _e('Hours', 'dliCores')?>', '<?php _e('Minutes', 'dliCores')?>', '<?php _e('Seconds', 'dliCores')?>'],
            labels1: ['<?php _e('Year', 'dliCore')?>', '<?php _e('Month', 'dliCore')?>', '<?php _e('Week', 'dliCore')?>', '<?php _e('Day', 'dliCores')?>', '<?php _e('Hour', 'dliCores')?>', '<?php _e('Minute', 'dliCores')?>', '<?php _e('Second', 'dliCores')?>'],
            compactLabels: ['<?php _e('Y', 'dliCore')?>', '<?php _e('M', 'dliCore')?>', '<?php _e('W', 'dliCore')?>', '<?php _e('D', 'dliCores')?>'],
            whichLabels: null,
            digits: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            timeSeparator: ':', isRTL: false
        };
        $.countdown.setDefaults($.countdown.regionalOptions['<?php echo osc_current_user_locale()?>']);

        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Please check your input."
        );

        $.validator.addMethod("notEqualTo", function(v, e, p) {
            return this.optional(e) || v != p;
        }, "Please specify a different value");

        $.validator.setDefaults({
            ignore: []
        });
    })(jQuery);

    Number.prototype.formatMoney = function (places, symbol, thousand, decimal) {
        places = !isNaN(places = Math.abs(places)) ? places : 2;
        symbol = symbol !== undefined ? symbol : "$";
        thousand = thousand || ",";
        decimal = decimal || ".";
        var number = this,
            negative = number < 0 ? "-" : "",
            i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
        return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
    };

    function serverTime() {
        var time = null;
        if (serverTimeLastFetched == null || new Date().getTime() - serverTimeLastFetched > 60000) {
            var serverTimeFetchStart = new Date().getTime();
            $.ajax({
                url: "<?php echo \dliLib\Plugin\Route\AbstractRoute::getRoute('dliCore', 'Js', 'serverTime')->getAjaxUrl()?>",
                async: true, dataType: "text",
                success: function (text) {
                    serverTimeLastFetched = new Date().getTime();
                    var elapsedTime = serverTimeLastFetched - serverTimeFetchStart;
                    time = new Date(new Date(text).getTime() + elapsedTime);
                    serverCurrentTime = time.getTime();
                }, error: function (http, message, exc) {
                    time = new Date();
                }
            });
        }
        else {
            time = new Date(serverCurrentTime + new Date().getTime() - serverTimeLastFetched);
        }
        return time;
    }
</script>