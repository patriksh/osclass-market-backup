<script>
    Number.prototype.formatMoney = function (places, symbol, thousand, decimal) {
        places = !isNaN(places = Math.abs(places)) ? places : 2;
        symbol = symbol !== undefined ? symbol : "$";
        thousand = thousand || ",";
        decimal = decimal || ".";
        var number = this,
            negative = number < 0 ? "-" : "",
            i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + "",
            j = (j = i.length) > 3 ? j % 3 : 0;
        return symbol + negative + (j ? i.substr(0, j) + thousand : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : "");
    };

    var serverTimeLastFetched = null;
    var serverCurrentTime = null;

    function serverTime() {
        var time = null;
        if (serverTimeLastFetched == null || new Date().getTime() - serverTimeLastFetched > 60000) {
            var serverTimeFetchStart = new Date().getTime();
            $.ajax({
                url: "<?php echo \dliLib\Plugin\Route\AbstractRoute::getRoute('dliCore', 'Js', 'serverTime')->getAjaxUrl()?>",
                async: true, dataType: "text",
                success: function (text) {
                    serverTimeLastFetched = new Date().getTime();
                    var elapsedTime = serverTimeLastFetched - serverTimeFetchStart;
                    time = new Date(new Date(text).getTime() + elapsedTime);
                    serverCurrentTime = time.getTime();
                }, error: function (http, message, exc) {
                    time = new Date();
                }
            });
        }
        else {
            time = new Date(serverCurrentTime + new Date().getTime() - serverTimeLastFetched);
        }
        return time;
    }
</script>