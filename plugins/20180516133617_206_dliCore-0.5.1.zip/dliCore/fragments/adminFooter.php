<style>
    <?php foreach($this->menus as $menu):?>
    <?php if($menu->getIcon() !== null):?>
    .ico-<?php echo $menu->getId()?>{
        background-image: url('<?php echo $menu->getIcon()->getIcon();?>') !important;
    }
    body.compact .ico-<?php echo $menu->getId()?>{
        background-image: url('<?php echo $menu->getIcon()->getIcon();?>') !important;
        background-size: 35px, 35px;
    }
    .ico-<?php echo $menu->getId()?>:hover{
        background-image: url('<?php echo $menu->getIcon()->getHoverIcon();?>') !important;

    }
    body.compact .ico-<?php echo $menu->getId()?>:hover{
        background-image: url('<?php echo $menu->getIcon()->getHoverIcon();?>') !important;
        background-size: 35px, 35px;
    }
    .current .ico-<?php echo $menu->getId()?> {
        background-image: url('<?php echo $menu->getIcon()->getHoverIcon();?>') !important;
    }
    body.compact .current .ico-<?php echo $menu->getId()?>{
        background-image: url('<?php echo $menu->getIcon()->getHoverIcon();?>') !important;
        background-size: 35px, 35px;
    }
    <?php endif;?>
    <?php endforeach;?>
</style>
<script>
    $().ready(function() {
        $.validator.addMethod(
            "regex",
            function(value, element, regexp) {
                var re = new RegExp(regexp);
                return this.optional(element) || re.test(value);
            },
            "Please check your input."
        );

        $.validator.addMethod("notEqualTo", function(v, e, p) {
            return this.optional(e) || v != p;
        }, "Please specify a different value");

        $.validator.setDefaults({
            ignore: []
        });

        $.countdown.regionalOptions['<?php echo osc_current_user_locale()?>'] = {
            labels: ['<?php _e('Years', 'dliCore')?>', '<?php _e('Months', 'dliCore')?>', '<?php _e('Weeks', 'dliCore')?>', '<?php _e('Days', 'dliCores')?>', '<?php _e('Hours', 'dliCores')?>', '<?php _e('Minutes', 'dliCores')?>', '<?php _e('Seconds', 'dliCores')?>'],
            labels1: ['<?php _e('Year', 'dliCore')?>', '<?php _e('Month', 'dliCore')?>', '<?php _e('Week', 'dliCore')?>', '<?php _e('Day', 'dliCores')?>', '<?php _e('Hour', 'dliCores')?>', '<?php _e('Minute', 'dliCores')?>', '<?php _e('Second', 'dliCores')?>'],
            compactLabels: ['<?php _e('Y', 'dliCore')?>', '<?php _e('M', 'dliCore')?>', '<?php _e('W', 'dliCore')?>', '<?php _e('D', 'dliCores')?>'],
            whichLabels: null,
            digits: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            timeSeparator: ':', isRTL: false
        };
        $.countdown.setDefaults($.countdown.regionalOptions['<?php echo osc_current_user_locale()?>']);

        serverTime();

        $("li #menu_dliCore").insertAfter($("li #menu_market"));

        $('body').onCreate('select, div.ms-container', function(elements) {
            $(elements).each( function(){
                if($(this).hasClass('ms-container')) {
                    $(this).parent().find('.select-box').hide();
                    $(this).parent().find('.select-box-trigger').hide();
                }
                else {
                    if($(this).parent().hasClass('select-box')) {
                        return;
                    }
                    selectUi($(this));
                }
            });
        }, true);
    });

    function get_center_pos(width, top) {
        // top is empty when creating a new notification and is set when recentering
        if (!top) {
            top = 30;
            // this part is needed to avoid notification stacking on top of each other
            $(".ui-pnotify").each(function() {
                top += $(this).outerHeight() + 20;
            });
        }

        return {
            "top": top,
            "left": ($(window).width() / 2) - (width / 2)
        }
    }

    PNotify.prototype.options.styling = "jqueryui";
    PNotify.prototype.options.delay = 1500;

    $(window).resize(function() {
        $(".ui-pnotify").each(function() {
            $(this).css(get_center_pos($(this).width(), $(this).position().top))
        });
    });
</script>