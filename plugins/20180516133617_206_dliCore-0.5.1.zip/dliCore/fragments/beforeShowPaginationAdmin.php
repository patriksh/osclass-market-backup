<script>
    //<![CDATA[
    var dependencies = <?php echo \json_encode($this->dependencies)?>;
    $( document ).ready(
        function() {
            $("form#dialog-uninstall div.form-horizontal div.form-row").prepend("<div id='plugin-dependencies-info'></div>");

            $("a[href*='action=disable&plugin=']").each(function() {
                $(this).on("click", function() {
                    var pluginName = $(this).attr("href").match(/plugin=([a-zA-Z0-9_]+)/)[1];

                    if(dependencies[pluginName] != undefined) {
                        var question = "<?php _e('The following plugins depends on', 'dliCore')?> " + pluginName + " <?php _e('and will be disabled', 'dliCore')?>\n\n";
                        for(var i = 0; i < dependencies[pluginName].length; ++i) {
                            question += "* " + dependencies[pluginName][i] + "\n";
                        }

                        question += "\n<?php _e('Are you sure you wan\'t to continue?', 'dliCore')?>";
                        return confirm(question);
                    }
                    else {
                    }
                });
            });

            $("a[href*='action=uninstall&plugin=']").each(function() {
                $(this).on("click", function() {
                    var pluginName = $(this).attr("href").match(/plugin=([a-zA-Z0-9_]+)/)[1];
                    if(dependencies[pluginName] != undefined) {
                        var question = "<?php _e('The following plugins depends on', 'dliCore')?> " + pluginName + " <?php _e('and will be disabled', 'dliCore')?><br/><br/>";

                        for(var i = 0; i < dependencies[pluginName].length; ++i) {
                            question += "* " + dependencies[pluginName][i] + "<br/>";
                        }

                        question += "<br/>";
                        $("#plugin-dependencies-info").html(question);
                    }
                    else {
                        $("#plugin-dependencies-info").html("");
                    }
                });
            });
        });
    //]]>
</script>