$.validator.addMethod("nifES",function(value,element){"use strict";if(this.optional(element)){return!0}
value=value.toUpperCase();if(!value.match("((^[A-Z]{1}[0-9]{7}[A-Z0-9]{1}$|^[T]{1}[A-Z0-9]{8}$)|^[0-9]{8}[A-Z]{1}$)")){return!1}
if(/^[0-9]{8}[A-Z]{1}$/.test(value)){return("TRWAGMYFPDXBNJZSQVHLCKE".charAt(value.substring(8,0)%23)===value.charAt(8))}
if(/^[KLM]{1}/.test(value)){return(value[8]==="TRWAGMYFPDXBNJZSQVHLCKE".charAt(value.substring(8,1)%23))}
return!1},"Please specify a valid NIF number.")