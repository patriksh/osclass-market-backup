$.validator.addMethod("creditcard",function(value,element){if(this.optional(element)){return"dependency-mismatch"}
if(/[^0-9 \-]+/.test(value)){return!1}
var nCheck=0,nDigit=0,bEven=!1,n,cDigit;value=value.replace(/\D/g,"");if(value.length<13||value.length>19){return!1}
for(n=value.length-1;n>=0;n--){cDigit=value.charAt(n);nDigit=parseInt(cDigit,10);if(bEven){if((nDigit*=2)>9){nDigit-=9}}
nCheck+=nDigit;bEven=!bEven}
return(nCheck%10)===0},"Please enter a valid credit card number.")