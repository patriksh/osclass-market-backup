$.validator.addMethod("cifES",function(value,element){"use strict";if(this.optional(element)){return!0}
var cifRegEx=new RegExp(/^([ABCDEFGHJKLMNPQRSUVW])(\d{7})([0-9A-J])$/gi);var letter=value.substring(0,1),number=value.substring(1,8),control=value.substring(8,9),all_sum=0,even_sum=0,odd_sum=0,i,n,control_digit,control_letter;function isOdd(n){return n%2===0}
if(value.length!==9||!cifRegEx.test(value)){return!1}
for(i=0;i<number.length;i++){n=parseInt(number[i],10);if(isOdd(i)){n*=2;odd_sum+=n<10?n:n-9}else{even_sum+=n}}
all_sum=even_sum+odd_sum;control_digit=(10-(all_sum).toString().substr(-1)).toString();control_digit=parseInt(control_digit,10)>9?"0":control_digit;control_letter="JABCDEFGHI".substr(control_digit,1).toString();if(letter.match(/[ABEH]/)){return control===control_digit}else if(letter.match(/[KPQS]/)){return control===control_letter}
return control===control_digit||control===control_letter},"Please specify a valid CIF number.")