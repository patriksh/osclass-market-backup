$.validator.addMethod("bankaccountNL",function(value,element){if(this.optional(element)){return!0}
if(!(/^[0-9]{9}|([0-9]{2} ){3}[0-9]{3}$/.test(value))){return!1}
var account=value.replace(/ /g,""),sum=0,len=account.length,pos,factor,digit;for(pos=0;pos<len;pos++){factor=len-pos;digit=account.substring(pos,pos+1);sum=sum+factor*digit}
return sum%11===0},"Please specify a valid bank account number")