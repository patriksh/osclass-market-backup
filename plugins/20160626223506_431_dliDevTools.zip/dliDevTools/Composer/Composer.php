<?php
namespace dliDevTools\Composer;
use dliLib\IO\FileSystem;
use dliLib\Plugin;
use dliLib\Plugin\Manager\PluginManager;
use dliLib\Shell\ClosureProcess;
use dliLib\Shell\PhpProcess;
use dliLib\Shell\Process;
use dliLib\Shell\ProcessManager;
use dliLib\Singleton;
use dliLib\dliString;

/**
 *
 * Abstract base class for Singleton pattern
 * @author danlil
 *
 */
class Composer extends Singleton
{
    protected $_composerHome = __DIR__.DIRECTORY_SEPARATOR.'ComposerHome';
    static protected $_installedVersions = array();

    protected function __construct() {
        putenv('COMPOSER_HOME='.$this->_composerHome);
        putenv('COMPOSER_NO_INTERACTION=1');

        if(!file_exists($this->_composerHome . DIRECTORY_SEPARATOR . 'composer.phar')) {
            $this->_installComposer();
        }
        else {
            $out = $this->command('about');
            if(strpos(implode(PHP_EOL, $out), 'self-update" to get the latest version.') !== false) {
                unlink(__DIR__ . DIRECTORY_SEPARATOR . 'ComposerHome' . DIRECTORY_SEPARATOR . 'composer.phar');
                $this->_installComposer();
            }
            /*$config = '{
    "config": {
        "vendor-dir": '.escapeshellarg(PluginManager::getInstance()->getCorePlugin()->getPluginPath() . 'vendor').'
    },
    "autoload": {
        "psr-4": {"dliLib\\\\": "library/dliLib"}
    }
}';
            file_put_contents($this->_composerHome . '\config.json', $config);*/
        }
    }

    /*public function checkLibraryVersion($library) {
        $out = $this->command('global show -i');
        static::$_installedVersions = $out;

    }*/

    protected function _installComposer()
    {
        $dir = __DIR__;
        $composerHome = $this->_composerHome;

        $fn = function() use ($dir, $composerHome) {
            //chdir($dir);
            putenv('COMPOSER_HOME='.$composerHome);
            putenv('COMPOSER_NO_INTERACTION=1');
            $installerURL = 'https://getcomposer.org/installer';
            $installerFile = 'composerInstaller.php';

            echo __('Downloading', 'dliDevTools') . ' ' . $installerURL . PHP_EOL;

            if (osc_downloadFile('https://getcomposer.org/installer', $installerFile) && file_exists(osc_content_path() . 'downloads' . DIRECTORY_SEPARATOR . $installerFile)) {
                echo __('Success downloading', 'dliDevTools') . ' ' . $installerURL . PHP_EOL;
                if (file_exists($dir . '/' . $installerFile)) {
                    unlink($dir . '/' . $installerFile);
                }

                copy(osc_content_path() . 'downloads' . DIRECTORY_SEPARATOR . $installerFile, $dir . DIRECTORY_SEPARATOR . $installerFile);
                unlink(osc_content_path() . 'downloads' . DIRECTORY_SEPARATOR . $installerFile);
            }
            else
            {
                echo __('Error downloading', 'dliDevTools') . ' ' . $installerURL . PHP_EOL;
            }

            if(file_exists($dir . '/' . $installerFile)) {
                echo __('Installer found : ', 'dliDevTools') . $installerFile . PHP_EOL;
                echo __('Starting installation...', 'dliDevTools') . PHP_EOL;

                $argv = array('--install-dir', $composerHome);
                include $dir . '/' . $installerFile;
            }
        };

        $installProcess = new ClosureProcess($fn, [], $dir);
        $installProcess->setName('Composer Installer');
        $installProcess->setDescription('Installs Composer for the dliDevTools plugin');
        $installProcess->executeAndWait();
    }

    /**
     * Generates ClassMap for plugin
     *
     * If path is supplied the classmap will be generated and placed in and using the provided path.
     * Without path the plugin path of the supplied plugin is used
     *
     * @param Plugin $plugin
     * @param $path
     */
    public function generatePluginClassMap(Plugin $plugin, $path = null) {
        if(!$path) {
            $path = $plugin->getPluginPath();
        }
        else {
            $path = new dliString($path);
            if(!$path->endsWith('/') && !$path->endsWith('\\') && !$path->endsWith(DIRECTORY_SEPARATOR)) {
                $path = $path . DIRECTORY_SEPARATOR;
            }
        }

        $json = '{
  "autoload": {
    "psr-4": {
      "'.$plugin->getName().'\\\\": ""
    }
  }
}';

        $composerFile = $path.'composer.json';
        $lockFile = $path.'composer.lock';

        if(file_exists($lockFile)) {
            $this->command('install --no-dev -o', $path);
        }
        else if(file_exists($composerFile)) {
            $this->command('update --no-dev -o', $path);
        }
        else {
            file_put_contents($composerFile, $json);
            $this->command('dump-autoload -o', $path);
            unlink($composerFile);
            $classMap = $path . 'vendor/composer/autoload_classmap.php';
            copy($classMap, $path . 'autoloaderClassMap.php');
            FileSystem::deleteDir($path . '/vendor');
            $contents = file_get_contents($path . 'autoloaderClassMap.php');
            $contents = str_replace('$vendorDir = dirname(dirname(__FILE__));', '', $contents);
            $contents = str_replace('$baseDir = dirname($vendorDir);', '$baseDir = dirname(__FILE__);', $contents);
            $contents = str_replace('// autoload_classmap.php @generated by Composer', '// autoloaderClassMap.php @generated by dliDevTools', $contents);
            file_put_contents($path . 'autoloaderClassMap.php', $contents);
            if (file_exists($path . 'composer_bak.json')) {
                copy($path . 'composer_bak.json', $composerFile);
                unlink($path . 'composer_bak.json');
            }
        }

        if(is_dir($this->_composerHome . DIRECTORY_SEPARATOR . 'cache')) {
            FileSystem::deleteDir($this->_composerHome . DIRECTORY_SEPARATOR . 'cache');
        }
    }

    public function command($command, $path = null)
    {
        // Special case
        if($command == 'pluginclassmap') {
            $this->generatePluginClassMap(PluginManager::getInstance()->getPluginOwningFile($path . 'index.php'));
            return;
        }

        set_time_limit(-1);
        $dir = getcwd();
        chdir($this->_composerHome);
        flush();

        $shellCommand = escapeshellcmd(ProcessManager::getInstance()->getPhpExecutable()) . ' ' . escapeshellarg($this->_composerHome.DIRECTORY_SEPARATOR.'composer.phar') . ' ' . $command . ' -v ' . ($path ? ' -d ' . escapeshellarg($path) : ' -d ' . escapeshellarg(PluginManager::getInstance()->getCorePlugin()->getPluginPath()) . ' ');

        exec($shellCommand, $out, $ret);

        chdir($dir);
        flush();
        return $out;
    }
}
