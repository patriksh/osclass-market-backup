<?php
/**
 * Generated using dliCore's dliHelper
 */

namespace dliDevTools\Controllers;

use dliLib\Plugin\Controller\AdminSecBaseController;

/**
 * Provides functionality to administer dliDevTools
 *
 * @author Daniel Liljeberg
 *
 */
class AdminController extends AdminSecBaseController
{
    public function indexAction() {
        $this->_setHeading($this->_getPlugin()->getDisplayName() . ' Admininstration');
    }
}

?>