<?php
/**
 * Generated using dliCore's dliHelper
 */

namespace dliDevTools\Controllers;

use dliLib\Html\Form;
use dliLib\Plugin\Controller\AdminSecBaseController;

/**
 * Provides functionality to administer dliDevTools
 *
 * @author Daniel Liljeberg
 *
 */
class PluginController extends AdminSecBaseController
{
    public function indexAction() {
        $this->_setHeading($this->_getPlugin()->getDisplayName() . ' Admininstration');
    }

    public function createAction() {
        $this->_setHeading(__('Create new plugin', 'dliDevTools'));

        //$pluginForm = new Form('')
    }
}

?>