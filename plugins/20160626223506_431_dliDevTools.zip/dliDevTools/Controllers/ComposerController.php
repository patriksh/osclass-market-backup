<?php
namespace dliDevTools\Controllers;

use dliDevTools\Composer\Composer;
use dliLib\Plugin\Controller\AdminSecBaseController;
use dliLib\Plugin\Manager\PluginManager;

/**
 *
 *
 * @author danlil
 *
 */
class ComposerController extends AdminSecBaseController
{
    public function indexAction() {
        $this->_setHeading(__('dliDevTools Composer', 'dliDevTools'));
        $this->_exportVariableToView('plugins', PluginManager::getInstance()->getAllPlugins());
        $this->_exportVariableToView('composer', Composer::getInstance());
    }

    public function executeAction($command, $path) {
        Composer::getInstance()->command($command, $path);
    }
}

?>