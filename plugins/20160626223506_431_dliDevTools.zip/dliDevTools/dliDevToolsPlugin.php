<?php
/**
 * Generated using dliCore's dliHelper
 */
namespace dliDevTools;

use dliLib\Plugin;

/**
 * dliDevTools plugin class
 *
 * @author Daniel Liljeberg
 *
 */
class dliDevToolsPlugin extends Plugin
{
    protected $_configAction = 'Admin-index';
    protected $_controllers = ['dliDevTools\Controllers\AdminController'];

    protected function _init() {
        /* Register Dependencies */
        $this->_registerDependency(new Plugin\Dependency\PluginDependency('dliCore', '0.3.1'));

        /* Register Preferences */

        /* Register Tables */

        /* Register Emails */

        /*$this->registerController('dliDevTools\Controllers\ComposerController', 'ComposerController');
        $this->registerController('dliDevTools\Controllers\PluginController', 'PluginController');

        $devGroup = new Group('dliDevTools_DevGroup', __('Development Tools', 'dliDevTools'));
        //$composerGroup->addSubItem(new Item('dliCore_ComposerConfig', __('Composer', 'dliDevTools'), 'dliDevTools/Composer/index'));
        $devGroup->addSubItem(new Item('dliDevTools_CreateNewPlugin', __('Create New Plugin', 'dliDevTools'), 'dliDevTools/Plugin/create'));
        MenuRegistry::getInstance()->get('dliCore')->addSubItemGroup($devGroup);*/
    }

    public function getSupportEmail() {
        return 'osc-support@danielliljeberg.se';
    }

    protected function installHook() {

    }

    protected function uninstallHook() {

    }
}