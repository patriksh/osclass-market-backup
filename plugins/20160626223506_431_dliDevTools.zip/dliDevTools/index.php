<?php
namespace dliDevTools;
/*
Plugin Name: dliDevTools
Plugin URI:
Description: Development tools to enable rapid Plugin development using dliCore
Version: 1.1.0
Author: Daniel Liljeberg
Author URI: http://www.danielliljeberg.se
Short Name: dliDevTools
Plugin update URI: dlidevtools
Support URI: /oc-admin/index.php?page=plugins&action=renderplugin&route=dliCore-Support-requestSupport&defaultPlugin=dliDevTools
*/
use dliLib\Plugin\Manager\PluginManager;

if(osc_plugin_is_enabled('dliCore/index.php')) {
    require_once(osc_plugins_path() . 'dliCore/index.php');
    \dliCore\dliCore_createAutoloader(__NAMESPACE__, osc_plugins_path());
    PluginManager::getInstance()->registerPlugin(__NAMESPACE__.'\\'.__NAMESPACE__.'Plugin');
}
else {
    function dliDevTools_install() {
        die(sprintf(__('This plugin requires dliCore to be installed and enabled. If you don\'t already have it you can find it for download <a href="%s" target="_blank">here</a>.'), 'http://market.osclass.org/plugins/miscellaneous/dlicore_206'));
    }
    osc_register_plugin(osc_plugin_path(__FILE__), 'dliDevTools\dliDevTools_install');
    \Plugins::deactivate(osc_plugins_path() . 'dliDevTools/index.php');
}