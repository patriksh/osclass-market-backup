<style>
    #output
    {
        width:100%;
        height:350px;
        overflow-y:scroll;
        overflow-x:hidden;
    }
</style>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <div class="form">
            <!-- <input type="text" id="path" style="width:300px;" class="form-control disabled" placeholder="absolute path to project directory"/> -->
            <h4>Plugin:</h4>
            <div class="form-group">
                <label for="internalName"><?php _e('Internal Name', 'dliDevTools')?>:</label><input id="internalName"/>
            </div>
            <div class="form-group">
                <label for="pluginName"><?php _e('Plugin Name', 'dliDevTools')?>:</label><input id="pluginName"/>
            </div>
            <div class="form-group">
                <label for="description"><?php _e('Description', 'dliDevTools')?>:</label><input id="Description"/>
            </div>
            <div class="form-group">
                <label for="author"><?php _e('Author', 'dliDevTools')?>:</label><input id="author"/>
            </div>
            <div class="form-group">
                <label for="supportEmailAddress"><?php _e('Support Email Address', 'dliDevTools')?>:</label><input id="supportEmailAddress"/>
            </div>
            <div class="form-group">
                <button id="create-new-plugin" onclick="call('createPlugin')" class="btn btn-success disabled">Create Plugin</button>
            </div>
        </div>
        <h3>Console Output:</h3>
        <pre id="output" class="well"></pre>
    </div>
    <div class="col-lg-1"></div>
</div>
<script type="text/javascript">
    function call(func)
    {
        $("#output").append("\nRunning " + func + " please wait...\n");
        $.post('<?php echo osc_route_admin_ajax_url('dliDevTools-Composer-execute')?>',
            {
                "path":$("#path").val(),
                "command":func,
                "function": "command"
            },
            function(data)
            {
                $("#output").append(data);
                $("#output").append("\nDone\n");
            }
        );
    }
</script>