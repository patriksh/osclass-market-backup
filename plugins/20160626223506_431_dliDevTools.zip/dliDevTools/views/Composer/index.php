<style>
    #output
    {
        width:100%;
        height:350px;
        overflow-y:scroll;
        overflow-x:hidden;
    }
</style>
<div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-10">
        <h3>Commands:</h3>
        <div class="form-inline">
            <button id="self-update" onclick="call('self-update')" class="btn btn-success disabled">Update Composer</button><br /><br />
            <!-- <input type="text" id="path" style="width:300px;" class="form-control disabled" placeholder="absolute path to project directory"/> -->
            <h4>Plugin:</h4>
            <select id="path">
                <?php foreach(\View::newInstance()->_get('plugins') as $plugin):?>
                    <option value="<?php echo $plugin->getPluginPath()?>"><?php echo $plugin->getName()?></option>
                <?php endforeach;?>
            </select>
            <button id="install" onclick="call('install')" class="btn btn-success disabled">install</button>
            <button id="update" onclick="call('update')" class="btn btn-success disabled">update</button>
            <button id="dump-autoload" onclick="call('dump-autoload -o')" class="btn btn-success disabled">dump-autoload</button>
            <button id="dump-class-map" onclick="call('update -o')" class="btn btn-success disabled">Generate Class Map</button>
            <button id="dump-class-map" onclick="call('pluginclassmap')" class="btn btn-success disabled">Generate Plugin Class Map</button>
        </div>
        <div class="form-inline">
            <button id="list-config" onclick="call('config -l')" class="btn btn-success disabled">List Settings</button>
            <button id="diagnose" onclick="call('diagnose')" class="btn btn-success disabled">Diagnose</button>
            <button id="status" onclick="call('status')" class="btn btn-success disabled">Status</button>
            <button id="clear-cache" onclick="call('clear-cache')" class="btn btn-success disabled">Clear Cache</button>
        </div>
        <h3>Console Output:</h3>
        <pre id="output" class="well"></pre>
    </div>
    <div class="col-lg-1"></div>
</div>
<script type="text/javascript">
    function call(func)
    {
        $("#output").append("\nRunning " + func + " please wait...\n");
        $.post('<?php echo osc_route_admin_ajax_url('dliDevTools-Composer-execute')?>',
            {
                "path":$("#path").val(),
                "command":func,
                "function": "command"
            },
            function(data)
            {
                $("#output").append(data);
                $("#output").append("\nDone\n");
            }
        );
    }
</script>