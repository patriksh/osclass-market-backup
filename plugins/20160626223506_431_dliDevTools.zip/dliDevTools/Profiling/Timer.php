<?php
namespace dliDevTools\Profiling;


class Timer
{
    const PRECISION_SECOND      = 0;
    const PRECISION_MILLISECOND = 1;
    const PRECISION_MICROSECOND = 2;

    private $_start = null;
    private $_end   = null;
    private $_tags  = [];

    public function __construct(){
    }

    public function start(){
        $this->_start = microtime(true);
        $this->_end = null;
    }

    public function stop(){
        $this->_end = microtime(true);
    }

    public function tag($tagName) {
        $this->_tags[] = ['name' => $tagName, 'time' => microtime(true)];
    }

    /**
     * This function return the time the code use to process
     * @param $precision the precision wanted, with const. second, millisecond and microsecond available (default PRECISION_SECOND)
     * @param $floatingPrecision the number of numbers after the floating point (default 0)
     * @param $showUnit precise if the unit should be returned (default true)
     * @return string the render time in the precision asked. Note that the precision is ±0.5 the precision (eq. 5s is at least 4.5s and at most 5.5s) <br/>
     * The code have an error about 2 or 3µs (time to execute the end function)
     */
    public function getTime($precision = self::PRECISION_SECOND, $floatingPrecision = 0, $showUnit = true) {
        return $this->_getTime($this->_start, $this->_end, $precision, $floatingPrecision, $showUnit);
    }

    public function getTimes($precision = self::PRECISION_SECOND, $floatingPrecision = 0, $showUnit = true) {
        $str = '<br/>';
        $str .= '=======================================================================================================<br/>';
        $str .= 'Total: ' . $this->_getTime($this->_start, $this->_end, $precision, $floatingPrecision, $showUnit) . '<br/>';
        foreach($this->_tags as $index => $tag) {
            $str .= $tag['name'] . ': ' . $this->getTimeForTag($tag['name'], $precision, $floatingPrecision, $showUnit) . '<br/>';
        }
        $str .= '<br/>';
        $str .= '<br/>';
        return $str;
    }

    public function getTimeForTag($tagName, $precision = self::PRECISION_SECOND, $floatingPrecision = 0, $showUnit = true) {
        $last = count($this->_tags) - 1;
        foreach($this->_tags as $index => $tag) {
            if($tagName == $tag['name']) {
                if($index == 0) {
                    $start  = $this->_start;
                    $end    = $tag['time'];
                }
                else {
                    $start  = $this->_tags[$index-1]['time'];
                    $end    = $tag['time'];
                }

                return $this->_getTime($start, $end, $precision, $floatingPrecision, $showUnit);
            }
        }

        return "Unknown tag \"" . $tagName . "\"";
    }

    protected function _getTime($start, $end, $precision = self::PRECISION_SECOND, $floatingPrecision = 0, $showUnit = true) {
        $test = is_int($precision) && $precision >= self::PRECISION_SECOND && $precision <= self::PRECISION_MICROSECOND &&
            is_float($this->_start) && is_float($this->_end) && $this->_start <= $this->_end &&
            is_int($floatingPrecision) && $floatingPrecision >= 0 &&
            is_bool($showUnit);

        if($test){
            $duration = round(($end - $start) * 10 ** ($precision * 3), $floatingPrecision);

            if($showUnit)
                return $duration.' '.self::getUnit($precision);
            else
                return $duration;
        }else{
            return 'Can\'t return the render time';
        }
    }

    private static function getUnit($precision){
        switch($precision){
            case self::PRECISION_SECOND :
                return 's';
            case self::PRECISION_MILLISECOND :
                return 'ms';
            case self::PRECISION_MICROSECOND :
                return 'µs';
            default :
                return '(no unit)';
        }
    }
}