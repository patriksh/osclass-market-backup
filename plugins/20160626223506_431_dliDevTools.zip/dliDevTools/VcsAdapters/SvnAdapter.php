<?php
namespace dliDevTools\VcsAdapters;


use Colors\Color;
use dliLib\IO\Console;
use dliLib\IO\FileSystem;

class SvnAdapter extends AbstractVcsAdapter
{
    public function getName() {
        return "Subversion";
    }

    public function checkoutToDestination($destinationPath) {
        $rows = [];
        exec("svn checkout " . escapeshellarg($this->_getRepoPath()) . " " . escapeshellarg($destinationPath), $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function hasLocalModifications() {
        $rows = [];
        exec("svn status " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
        foreach($rows as $row) {
            if(mb_substr($row, 0, 1, 'utf-8') == 'M') {
                return true;
            }
        }
        return false;
    }

    public function commit($commitMessage) {
        $rows = [];
        $commitMessage = str_replace("\"", "'", $commitMessage);
        exec("svn commit -m \"".$commitMessage."\" " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function diff() {
        $c = new Color();
        $rows = [];
        exec("svn diff " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
        $response = '';
        foreach($rows as $row) {
            if (substr($row, 0, 1) == '+') {
                $response .= $c($row)->green() . PHP_EOL;
            } else if (substr($row, 0, 1) == '-') {
                $response .= $c($row)->red() . PHP_EOL;
            } else {
                $response .= $row . PHP_EOL;
            }
        }

        return $response;
    }

    public function tag($tagName, $commitMessage) {
        $rows = [];
        $commitMessage = str_replace("\"", "'", $commitMessage);
        exec("svn copy " . escapeshellarg($this->_getRepoPath()) . " " . escapeshellarg(str_replace('trunk', 'tags', $this->_getRepoPath()) . '/' . $tagName) . " -m \"" . $commitMessage . "\"", $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function removeTag($tagName, $commitMessage) {
        $rows = [];
        $commitMessage = str_replace("\"", "'", $commitMessage);
        exec("svn rm " . escapeshellarg(str_replace('trunk', 'tags', $this->_getRepoPath()) . '/' . $tagName) . " -m \"" . $commitMessage . "\"", $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function getTags() {
        $rows = [];
        exec("svn ls -v " . escapeshellarg(str_replace('trunk', 'tags', $this->_getRepoPath()) . '/'), $rows);
        $rows = array_splice($rows, 1);
        foreach($rows as &$row) {
            $pos = strrpos($row, ' ');
            $row = $pos === false ? $row : substr($row, $pos + 1);
            $row = str_replace('/', '', $row);
            $row = str_replace('\\', '', $row);
        }
        return $rows;
    }

    public function cleanupRelease($path) {
        $c = new Color();
        if(FileSystem::deleteDir($path . DIRECTORY_SEPARATOR . '.svn')) {
            return "Removed .svn folder from " . $path . PHP_EOL;
        } else {
            return $c("Failed ")->red() . " to remove .svn folder from " . $path . ". Delete it manually!" . PHP_EOL;
            //$this->_restoreBackup($plugin->getName());
            //return false;
        }
    }

    public function update() {
        $rows = [];
        exec("svn update " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function revert() {
        $rows = [];
        exec("svn revert " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
        $response = '';
        foreach($rows as $row) {
            $response .= $row . PHP_EOL;
        }

        return $response;
    }

    public function getLog($limit = 1) {
        $rows = [];
        exec("svn log " . escapeshellarg($this->_plugin->getPluginPath()) . " -l " . escapeshellarg($limit), $rows);

        return $rows;
    }

    private function _getRepoPath() {
        static $repoPath = null;

        if(!$repoPath) {
            $rows = [];
            exec("svn info " . escapeshellarg($this->_plugin->getPluginPath()), $rows);
            $repoPath = str_replace("URL: ", "", $rows[2]);
        }

        return $repoPath;
    }
}