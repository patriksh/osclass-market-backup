<?php
namespace dliDevTools\VcsAdapters;


use dliLib\Plugin;

abstract class AbstractVcsAdapter
{
    protected $_plugin = null;

    public function __construct(Plugin $plugin)
    {
        $this->_plugin = $plugin;
    }

    abstract public function getName();
    abstract public function checkoutToDestination($destinationPath);
    abstract public function hasLocalModifications();
    abstract public function commit($commitMessage);
    abstract public function diff();
    abstract public function tag($tagName, $commitMessage);
    abstract public function removeTag($tagName, $commitMessage);
    abstract public function getTags();
    abstract public function getLog($limit = 1);
    abstract public function cleanupRelease($path);
    abstract public function update();
    abstract public function revert();

    /***
     * Identifies if plugin is under controll of a VCS and returns correct adapter
     * @param $path
     */
    final public static function getAdapter(Plugin $plugin) {
        if(file_exists($plugin->getPluginPath().'.svn')) {
            return new SvnAdapter($plugin);
            //svn status
        }
        elseif(file_exists($plugin->getPluginPath().'.hg')) {
            throw new \Exception("Mercurial Adapter not implemented yet. You should manually check if " . $plugin->getName() . " contains local modifications!");
            //return new MercurialAdapter($plugin);
        }
        elseif(file_exists($plugin->getPluginPath().'.git')) {
            throw new \Exception("Git Adapter not implemented yet. You should manually check if " . $plugin->getName() . " contains local modifications!");
            //return new GitAdapter($plugin);
            //git rev-parse
        }
        else {
            return null;
        }
    }
}