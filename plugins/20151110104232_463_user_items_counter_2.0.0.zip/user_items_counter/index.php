<?php if(!defined('ABS_PATH')) exit();
/*
Plugin Name: User Items Counter
Plugin URI: http://www.osclass.org/
Description: Update Database with True User Items Count (i_item field @ t_user) + add Total Items column
Version: 2.0.0
Author: dev101 & teseo
Author URI:
Short Name: user-items-counter
Plugin update URI: user-items-counter
*/

## MODEL

// Model
require_once 'model/ModelUserItemsCounter.php';

## INSTALL / UNINSTALL

function user_items_counter_install() {
	// enter maintenance mode
	$maintenance_file = ABS_PATH . '.maintenance';
	$fileHandler = @fopen($maintenance_file, 'w');
	fclose($fileHandler);

	// sleep
	sleep(5);

	// i_items_total @ t_user table
	$DAO = new DAO;
	$sql = sprintf("ALTER TABLE %st_user ADD i_items_total INT(10) UNSIGNED NULL DEFAULT 0 AFTER i_items", DB_TABLE_PREFIX);
	$DAO->dao->query($sql);

	// exit maintenance mode
	@unlink(ABS_PATH . '.maintenance');

	ModelUserItemsCounter::newInstance()->updateUserItemsCount();
	ModelUserItemsCounter::newInstance()->updateUserItemsTotalCount();
}

function user_items_counter_uninstall() {
	// enter maintenance mode
	$maintenance_file = ABS_PATH . '.maintenance';
	$fileHandler = @fopen($maintenance_file, 'w');
	fclose($fileHandler);

	// sleep
	sleep(5);

	// remove i_items_total @ t_user table
	$DAO = new DAO;
	$sql = sprintf("ALTER TABLE %st_user DROP i_items_total", DB_TABLE_PREFIX);
	$DAO->dao->query($sql);

	// exit maintenance mode
	@unlink(ABS_PATH . '.maintenance');
}

## USER ITEMS COUNTS UPDATE

function user_items_counter_update() {
	ModelUserItemsCounter::newInstance()->updateUserItemsCount();
	ModelUserItemsCounter::newInstance()->updateUserItemsTotalCount();
}

## HOOKS

// init_admin  = run counter stats update instantly on every admin page load (for testing)
// cron_hourly = run counter stats update every hour
// cron_daily  = run counter stats update every day
// cron_weekly = run counter stats update every week

osc_add_hook('cron_daily', 'user_items_counter_update');

// Activate Plugin
osc_register_plugin(osc_plugin_path(__FILE__), 'user_items_counter_install');

// Uninstall Plugin
osc_add_hook(osc_plugin_path(__FILE__) . '_uninstall', 'user_items_counter_uninstall');

function user_items_counter_col($table) {
	$table->addColumn('user_items_counter', __('Total Items'), 6);
}
function user_items_counter_adm($row, $aRow) {
	$row['user_items_counter'] = $aRow['i_items_total'];
	return $row;
} 
osc_add_hook('admin_users_table', 'user_items_counter_col');
osc_add_filter("users_processing_row", "user_items_counter_adm" );

?>