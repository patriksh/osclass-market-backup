<?php

class ModelUserItemsCounter extends DAO
{

		/**
		 * It references to self object: ModelUserItemsCounter.
		 * It is used as a singleton
		 * 
		 * @access private
		 * @since 3.0
		 * @var ModelUserItemsCounter
		 */
		private static $instance ;

		/**
		 * It creates a new ModelUserItemsCounter object class or if it has been created
		 * before, it return the previous object
		 * 
		 * @access public
		 * @since 3.0
		 * @return ModelUserItemsCounter
		 */
		public static function newInstance()
		{
			if( !self::$instance instanceof self ) {
				self::$instance = new self ;
			}
			return self::$instance ;
		}

		/**
		 * Construct
		 */
		function __construct()
		{
			parent::__construct();
		}

		/**
		 * Update user items count
		 *
		 */
		public function updateUserItemsCount()
		{
			$this->dao->query('UPDATE' . ' ' . DB_TABLE_PREFIX.'t_user' . ' ' . 'AS u SET i_items = (SELECT COUNT(*) AS count FROM' . ' ' . DB_TABLE_PREFIX.'t_item' . ' ' . 'WHERE b_enabled = 1 AND b_active = 1 AND b_spam = 0 AND dt_expiration >= NOW() AND fk_i_user_id = u.pk_i_id)');
		}

		/**
		 * Update user items TOTAL count
		 *
		 */
		public function updateUserItemsTotalCount()
		{
			$this->dao->query('UPDATE' . ' ' . DB_TABLE_PREFIX.'t_user' . ' ' . 'AS u SET i_items_total = (SELECT COUNT(*) AS count FROM' . ' ' . DB_TABLE_PREFIX.'t_item' . ' ' . 'WHERE fk_i_user_id = u.pk_i_id)');
		}

}