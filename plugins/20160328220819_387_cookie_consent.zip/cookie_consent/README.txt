This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

GNU GENERAL PUBLIC LICENSE v3

*********************************************************************
Brought to you by SmaRTeY - 2015
*FREE* Osclass "Cookie Consent" Plugin

Working Demo (Front-end):
Http://www.spulleboel.nl

Cookie Consent on Github:
https://github.com/silktide/cookieconsent2

NOTE: (thanks teseo & dev101 for review)
- Works with both *root* installs as with *sub-folder* installs
- Prefixed functions for best compatability
- index.php in *all* folders to prevend possible directory listing
*********************************************************************

Howto install?

1) In Admin go to Plugin management
2) Upload the zip file
3) Install the plugin
4) Config: Change settings to your personal likings
5) Add new language PO/MO file in case you need it

The Plugin comes with Dutch and English PO/MO files pre-installed.

NB1. MAKE SURE YOU HAVE PO/MO FILES SETUP FOR ALL ACTIVE LANGUAGES ON WEBSITE!
NB2. Read 'HowTo add additional languages' (languages folder) before asking in Forums or Market
NB3. Please use Osclass Forums in case of any issues: http://forums.osclass.org/plugins/*new*-free-cookie-consent-plugin/

ENJOY!
 
PS. Don't forget to check out my other Plugins in Osclass Market ;)