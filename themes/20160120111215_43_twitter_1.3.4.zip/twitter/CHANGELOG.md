#CHANGELOG

### v1.3.4 - 20/01/2015

* Added support for highlight listings

### v1.3.3 - 03/10/2013

* Added the following languages:
    * German
    * Hungarian
    * Lithuanian
    * Romanian

### v1.3.2 - 03/10/2013

* Fixed issue with permalinks enabled, home page region links.

### v1.3.1 - 01/10/2013

* Fixed issue with richedit plugin.
* Added user-public-profile.php template.
* Recaptcha on contact seller.
* Added report listing links in the listing template.
* Added contact with attachment feature. (contact seller only)
* Fixed search page sidebar, issues with categories when permalinks was enabled.
* Fixed issue with chosen  dropdown and &nbsp;

### v1.3 - 02/09/2013

* Compatible with Osclass 3.2
* Compatible with custom fields (Osclass v3.2).
* Fixed layout issues at user account.
* Fixed issue with plugins and parent categories.
* Fixed issue with chosen javascript library.
* No hot linking to Bootstrap.

### v1.2.4 - 19/07/2012

* Added footer hook

### v1.2.2 - 20/02/2012

* Removed usage of console.log function in js
* Fixed domain of a i18n string

### v1.1.1 - 19/10/2011

* reCAPTCHA in contact form is aligned to send button
* City select is populated even if there is only one region
* topbar color links
* topbar height, it doesn't hover the search form
* title text is now showed if there is a logo