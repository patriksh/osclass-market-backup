<?php

/*
Theme Name: Twitter bootstrap
Theme URI: http://osclass.org
Description: Osclass theme using twitter bootstrap 1.4
Version: 1.3.4
Author: Osclass team
Author URI: http://osclass.org
Widgets: header,footer
Theme update URI: twitter
*/

    function twitter_theme_info() {
        return array(
             'name'        => 'Twitter bootstrap'
            ,'version'     => '1.3.4'
            ,'description' => 'Osclass theme using twitter bootstrap 1.4'
            ,'author_name' => 'Osclass team'
            ,'author_url'  => 'http://osclass.org/'
            ,'locations'   => array('header', 'footer')
        );
    }

?>
