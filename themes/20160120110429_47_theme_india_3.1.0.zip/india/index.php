<?php
/*
Theme Name: Osclass india theme
Theme URI: http://www.osclass.org/
Description: This is the Osclass india theme
Version: 3.1.0
Author: OSClass team
Author URI: http://www.osclass.org/
Widgets: header,footer
Theme update URI: india
*/

    function india_theme_info() {
        return array(
            'name'        => 'Osclass india theme',
            'version'     => '3.1.0',
            'description' => 'This is the Osclass india theme',
            'author_name' => 'Osclass team',
            'author_url'  => 'http://osclass.org',
            'locations'   => array('header', 'footer')
        );
    }

?>
