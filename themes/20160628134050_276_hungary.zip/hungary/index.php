<?php
/*
Theme Name: Osclass hungary theme
Theme URI: http://www.osclass.org/
Description: This is the Osclass hungary theme
Version: 1.3.1
Author: Puiu Calin
Author URI: http://theme.calinbehtuk.ro
Widgets: header,footer
Theme update URI: hungary
*/

    function hungary_theme_info() {
        return array(
            'name'        => 'Osclass hungary theme',
            'version'     => '1.3.1',
            'description' => 'This is the Osclass hungary theme',
            'author_name' => 'Puiu Calin',
            'author_url'  => 'http://theme.calinbehtuk.ro',
            'locations'   => array('header', 'footer')
        );
    }

?>
