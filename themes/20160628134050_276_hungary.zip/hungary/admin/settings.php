<?php if ((!defined('ABS_PATH'))) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if (!OC_ADMIN) exit('User access is not allowed.'); ?>
<div id="fb-root"></div>
<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id))
            return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=651333508343077";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<style>
    .rights {display: block;
             background: #EBF6F6;
             padding: 10px;
             border: 1px solid #D6FFFF;
             line-height:20px;
             margin-bottom:10px;
    }
    .author {
        display: inline-block;
        background: #EBF6F6;
        border: 1px solid #D6FFFF;
        width:100%;
        margin-top:10px;
    }
    .rights .like{
        width:320px;
        display:inline-block;
        float:left;
        line-height:30px;
        margin-left:15px;
    }
    .rights .donate{   
        display:inline-block;
        line-height:30px;
        margin-left:15px;
    }
</style>
<div class="rights">
    <a style="float:left;" href="http://theme.calinbehtuk.ro" title="Premium theme and plugins for oslcass">
        <img src="<?php echo osc_base_url() ?>oc-content/themes/hungary/admin/images/calinbehtuk.png" title="premium theme and plugins for oslcass"/></a>
    <span style="float:right;line-height:40px;font-weight:700;"><?php _e('Follow:', 'telephone'); ?><a target="blank" style="text-decoration:none;" href="https://www.facebook.com/Calinbehtuk-themes-1086739291344584/"> <img style="margin-bottom:-5px;margin-left:5px;" src="<?php echo osc_base_url() ?>oc-content/plugins/telephone/images/facebook.png" title="facebook"/></a></span>
    <div class="like">
        <div class="fb-like" data-href="https://www.facebook.com/Calinbehtuk-themes-1086739291344584/" data-layout="standard" data-action="like" data-show-faces="false" data-share="false"></div>
    </div>
    <div class="donate">
        <form style="display:block;margin-top:10px;" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="hidden" name="hosted_button_id" value="TL5PLDQHJB3XA">
            <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
            <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
        </form>
    </div>
</div>
<?php hungary_content(); ?>
<script type="text/javascript" src="<?php echo osc_base_url(). 'oc-content/themes/hungary/jscolor/jscolor.js'; ?>"></script>
<h2 class="render-title <?php echo (osc_get_preference('footer_link', 'hungary') ? '' : 'separate-top'); ?>"><?php _e('Theme settings', 'hungary'); ?></h2>
<form action="<?php echo osc_admin_render_theme_url('oc-content/themes/hungary/admin/settings.php'); ?>" method="post">
    <input type="hidden" name="action_specific" value="settings" />
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"><?php _e('Search placeholder', 'hungary'); ?></div>
                <div class="form-controls"><input type="text" class="xlarge" name="keyword_placeholder" value="<?php echo osc_esc_html( osc_get_preference('keyword_placeholder', 'hungary') ); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Footer link', 'hungary'); ?></div>
                <div class="form-controls">
                    <div class="form-label-checkbox"><input type="checkbox" name="footer_link" value="1" <?php echo (osc_get_preference('footer_link', 'hungary') ? 'checked' : ''); ?> > <?php _e("I want to help OSClass by linking to <a href=\"http://osclass.org/\" target=\"_blank\">osclass.org</a> from my site with the following text:", 'hungary'); ?></div>
                    <span class="help-box"><?php _e('This website is proudly using the <a title="OSClass web" href="http://osclass.org/">classifieds scripts</a> software <strong>OSClass</strong>', 'hungary'); ?></span>
                </div>
            </div>
        </div>
    </fieldset>
<h2 class="render-title"><?php _e('Location input', 'hungary'); ?></h2>
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"><?php _e('Show location input as:', 'hungary'); ?></div>
                <div class="form-controls">
                    <select name="defaultLocationShowAs">
                        <option value="dropdown" <?php
                        if (hungary_default_location_show_as() == 'dropdown') {
                            echo 'selected="selected"';
                        }
                        ?>><?php _e('Dropdown', 'hungary'); ?></option>
                        <option value="autocomplete" <?php
                        if (hungary_default_location_show_as() == 'autocomplete') {
                            echo 'selected="selected"';
                        }
                        ?>><?php _e('Autocomplete', 'hungary'); ?></option>
                    </select>
                </div>
            </div>
        </div>
    </fieldset>
    <h2 class="render-title"><?php _e('Hover color on map', 'hungary'); ?></h2>
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"><?php _e('Set fill color', 'hungary'); ?></div>
                <div class="form-controls">
                    <input type="text" class="color {hash:true}" name="hover_color" id="hover_color" value="<?php echo osc_esc_html( osc_get_preference('hover_color', 'hungary') ); ?>" />
                </div>
            </div>
        </div>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"><?php _e('Set line color', 'hungary'); ?></div>
                <div class="form-controls">
                    <input type="text" class="color {hash:true}" name="line_color" id="line_color" value="<?php echo osc_esc_html( osc_get_preference('line_color', 'hungary') ); ?>" />
                </div>
            </div>
        </div>
    </fieldset>

    <h2 class="render-title"><?php _e('Ads management', 'hungary'); ?></h2>
    <div class="form-row">
        <div class="form-label"></div>
        <div class="form-controls">
            <p><?php _e('In this section you can configure your site to display ads and start generating revenue.', 'hungary'); ?><br/><?php _e('If you are using an online advertising platform, such as Google Adsense, copy and paste here the provided code for ads.', 'hungary'); ?></p>
        </div>
    </div>
    <fieldset>
        <div class="form-horizontal">
            <div class="form-row">
                <div class="form-label"><?php _e('Header 728x90', 'hungary'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 115px; width: 500px;"name="header-728x90"><?php echo osc_esc_html( osc_get_preference('header-728x90', 'hungary') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"><?php _e('This ad will be shown at the top of your website, next to the site title and above the search results. Note that the size of the ad has to be 728x90 pixels.', 'hungary'); ?></div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Homepage 728x90', 'hungary'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 115px; width: 500px;" name="homepage-728x90"><?php echo osc_esc_html( osc_get_preference('homepage-728x90', 'hungary') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"><?php _e('This ad will be shown on the main site of your website. It will appear both at the top and bottom of your site homepage. Note that the size of the ad has to be 728x90 pixels.', 'hungary'); ?></div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Search results 728x90 (top of the page)', 'hungary'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 115px; width: 500px;" name="search-results-top-728x90"><?php echo osc_esc_html( osc_get_preference('search-results-top-728x90', 'hungary') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"><?php _e('This ad will be shown on top of the search results of your site. Note that the size of the ad has to be 728x90 pixels.', 'hungary'); ?></div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Search results 728x90 (middle of the page)', 'hungary'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 115px; width: 500px;" name="search-results-middle-728x90"><?php echo osc_esc_html( osc_get_preference('search-results-middle-728x90', 'hungary') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"><?php _e('This ad will be shown among the search results of your site. Note that the size of the ad has to be 728x90 pixels.', 'hungary'); ?></div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Sidebar 300x250', 'hungary'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 115px; width: 500px;" name="sidebar-300x250"><?php echo osc_esc_html( osc_get_preference('sidebar-300x250', 'hungary') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"><?php _e('This ad will be shown at the right sidebar of your website, on the product detail page. Note that the size of the ad has to be 300x350 pixels.', 'hungary'); ?></div>
                </div>
            </div>
            <div class="form-actions">
                <input type="submit" value="<?php _e('Save changes', 'hungary'); ?>" class="btn btn-submit">
            </div>
        </div>
    </fieldset>
</form>
<div class="author">
<span style="float:right;"class="text"><a href="http://theme.calinbehtuk.ro/"><?php _e('2015 All rights reserved HUNGARY Theme by Puiu Calin', 'one'); ?></a></span>
</div>