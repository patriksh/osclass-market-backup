<?php
/*
 *      Osclass – software for creating and publishing online classified
 *                           advertising platforms
 *
 *                        Copyright (C) 2012 OSCLASS
 *
 *       This program is free software: you can redistribute it and/or
 *     modify it under the terms of the GNU Affero General Public License
 *     as published by the Free Software Foundation, either version 3 of
 *            the License, or (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful, but
 *         WITHOUT ANY WARRANTY; without even the implied warranty of
 *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *             GNU Affero General Public License for more details.
 *
 *      You should have received a copy of the GNU Affero General Public
 * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

define('HUNGARY_THEME_VERSION', '1.3.1');

osc_enqueue_script('php-date');

if (!OC_ADMIN) {
    if (!function_exists('add_close_button_action')) {

        function add_close_button_action() {
            echo '<script type="text/javascript">';
            echo '$(".flashmessage .ico-close").click(function(){';
            echo '$(this).parent().hide();';
            echo '});';
            echo '</script>';
        }

        osc_add_hook('footer', 'add_close_button_action');
    }
}

function theme_hungary_actions_admin() {
    if (Params::getParam('file') == 'oc-content/themes/hungary/admin/settings.php') {
        if (Params::getParam('donation') == 'successful') {
            osc_set_preference('donation', '1', 'hungary');
            osc_reset_preferences();
        }
    }

    switch (Params::getParam('action_specific')) {
        case('settings'):
            $footerLink = Params::getParam('footer_link');
            $defaultLogo = Params::getParam('default_logo');
            osc_set_preference('keyword_placeholder', Params::getParam('keyword_placeholder'), 'hungary');
            osc_set_preference('footer_link', ($footerLink ? '1' : '0'), 'hungary');
            osc_set_preference('default_logo', ($defaultLogo ? '1' : '0'), 'hungary');
            osc_set_preference('defaultLocationShowAs', Params::getParam('defaultLocationShowAs'), 'hungary');
            echo Params::getParam('defaultLocationShowAs') . "...";
            osc_set_preference('hover_color', (Params::getParam('hover_color')), 'hungary');
            osc_set_preference('line_color', (Params::getParam('line_color')), 'hungary');
            osc_set_preference('header-728x90', trim(Params::getParam('header-728x90', false, false, false)), 'hungary');
            osc_set_preference('homepage-728x90', trim(Params::getParam('homepage-728x90', false, false, false)), 'hungary');
            osc_set_preference('sidebar-300x250', trim(Params::getParam('sidebar-300x250', false, false, false)), 'hungary');
            osc_set_preference('search-results-top-728x90', trim(Params::getParam('search-results-top-728x90', false, false, false)), 'hungary');
            osc_set_preference('search-results-middle-728x90', trim(Params::getParam('search-results-middle-728x90', false, false, false)), 'hungary');

            osc_add_flash_ok_message(__('Theme settings updated correctly', 'hungary'), 'admin');
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/hungary/admin/settings.php'));
            exit;
            break;
        case('upload_logo'):
            $package = Params::getFiles('logo');
            if ($package['error'] == UPLOAD_ERR_OK) {
                if (move_uploaded_file($package['tmp_name'], WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg")) {
                    osc_add_flash_ok_message(__('The logo image has been uploaded correctly', 'hungary'), 'admin');
                } else {
                    osc_add_flash_error_message(__("An error has occurred, please try again", 'hungary'), 'admin');
                }
            } else {
                osc_add_flash_error_message(__("An error has occurred, please try again", 'hungary'), 'admin');
            }
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/hungary/admin/header.php'));
            exit;
            break;
        case('remove'):
            if (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg")) {
                @unlink(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg");
                osc_add_flash_ok_message(__('The logo image has been removed', 'hungary'), 'admin');
            } else {
                osc_add_flash_error_message(__("Image not found", 'hungary'), 'admin');
            }
            header('Location: ' . osc_admin_render_theme_url('oc-content/themes/hungary/admin/header.php'));
            exit;
            break;
    }
}

if (!function_exists('logo_header')) {

    function logo_header() {
        $html = '<img border="0" alt="' . osc_page_title() . '" src="' . osc_current_web_theme_url('images/logo.jpg') . '" />';
        if (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg")) {
            return $html;
        } else if (osc_get_preference('default_logo', 'hungary') && (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/default-logo.jpg"))) {
            return '<img border="0" alt="' . osc_page_title() . '" src="' . osc_current_web_theme_url('images/default-logo.jpg') . '" />';
        } else {
            return osc_page_title();
        }
    }

}

// install update options
if (!function_exists('hungary_theme_install')) {

    function hungary_theme_install() {
        osc_set_preference('keyword_placeholder', __('ie. PHP Programmer', 'hungary'), 'hungary');
        osc_set_preference('version', '1.3.1', 'hungary');
        osc_set_preference('footer_link', true, 'hungary');
        osc_set_preference('donation', '0', 'hungary');
        osc_set_preference('default_logo', '1', 'hungary');
        osc_reset_preferences();
    }

}

if (!function_exists('check_install_hungary_theme')) {

    function check_install_hungary_theme() {
        $current_version = osc_get_preference('version', 'hungary');
        //check if current version is installed or need an update
        if (!$current_version) {
            hungary_theme_install();
        }
    }

}

if (!function_exists('hungary_default_location_show_as')) {

    function hungary_default_location_show_as() {
        return osc_get_preference('defaultLocationShowAs', 'hungary');
    }

}

require_once WebThemes::newInstance()->getCurrentThemePath() . 'inc.functions.php';

check_install_hungary_theme();

/* ads  SEARCH */

function search_ads_listing_top_fn() {
    if (osc_get_preference('search-results-top-728x90', 'hungary') != '') {
        echo '<div class="clear"></div>' . PHP_EOL;
        echo '<div class="ads_728">' . PHP_EOL;
        echo osc_get_preference('search-results-top-728x90', 'hungary');
        echo '</div>' . PHP_EOL;
    }
}

osc_add_hook('search_ads_listing_top', 'search_ads_listing_top_fn');

function search_ads_listing_medium_fn() {
    if (osc_get_preference('search-results-middle-728x90', 'hungary') != '') {
        echo '<div class="clear"></div>' . PHP_EOL;
        echo '<div class="ads_728">' . PHP_EOL;
        echo osc_get_preference('search-results-middle-728x90', 'hungary');
        echo '</div>' . PHP_EOL;
    }
}

osc_add_hook('search_ads_listing_medium', 'search_ads_listing_medium_fn');

/* remove theme */

function hungary_delete_theme() {
    osc_remove_preference('keyword_placeholder', 'hungary');
    osc_remove_preference('footer_link', 'hungary');
    osc_remove_preference('default_logo', 'hungary');
    osc_remove_preference('donation', 'hungary');

    osc_remove_preference('header-728x90', 'hungary');
    osc_remove_preference('homepage-728x90', 'hungary');
    osc_remove_preference('sidebar-300x250', 'hungary');
    osc_remove_preference('search-results-top-728x90', 'hungary');
    osc_remove_preference('search-results-middle-728x90', 'hungary');
}

osc_add_hook('theme_delete_hungary', 'hungary_delete_theme');

function hungary_content() {
    $url = 'http://theme.calinbehtuk.ro/content/data.php?data=true';
    $json = file_get_contents($url);
    $obj = json_decode($json, true);

    $title = $obj['info_data']['title'];
    $image_url = $obj['info_data']['image_url'];
    $style = $obj['info_data']['style'];
    if (!empty($obj)) {
        ?>
        <link rel="stylesheet" href="<?php echo $style; ?>">
        <div class="p_content">
            <h2 class="h_title"><?php echo $title; ?></h2>
        <?php
        unset($obj['info_data']);
        shuffle($obj);
        $obj = array_slice($obj, 0, 5);
        foreach ($obj as $value) {
            ?> 
                <a href="<?php echo $value['link']; ?>" target="blank">
                    <div class="individual_content">
                        <div class="p_image">
                            <img src="<?php echo $image_url; ?>/<?php echo $value['image']; ?>/<?php echo $value['image_id']; ?>.png" title="<?php echo $value['title']; ?>"/>
                        </div>
                        <div class="p_title">
            <?php echo $value['title']; ?>
                        </div>
                        <div class="p_description">
            <?php echo $value['description']; ?>
                        </div>
                    </div>
                </a>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('.individual_content').hover(function () {
                            $(this).find('.p_description').toggle();
                        });
                    });
                </script>
            <?php
        }
        ?></div><?php
    }
}
