                <!-- map -->
                <div id="main-map" style="float:left; margin-bottom:15px; margin-top:15px" >
                    <?php osc_current_web_theme_path('map.php') ; ?>
                </div>
                <!-- /map -->