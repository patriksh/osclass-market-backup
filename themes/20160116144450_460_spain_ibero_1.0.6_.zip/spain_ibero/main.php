<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','spain_ibero_follow_construct');

    spain_ibero_add_body_class('home');


    $buttonClass = '';
    $listClass   = '';
    if(spain_ibero_show_as() == 'gallery'){
          $listClass = 'listing-grid';
          $buttonClass = 'active';
    }
?>

<?php osc_current_web_theme_path('header.php') ; ?>
<div class="clear"></div>

<?php osc_current_web_theme_path('map-spain.php') ; ?>

<div class="latest_ads">

<h1><strong><?php _e('Latest Listings', 'spain_ibero') ; ?></strong></h1>
 <?php if( osc_count_latest_items() == 0) { ?>
    <div class="clear"></div>
    <p class="empty"><?php _e("There aren't listings available at this moment", 'spain_ibero'); ?></p>
<?php } else { ?>
    <div class="actions">
      <span class="doublebutton <?php echo $buttonClass; ?>">
           <a href="<?php echo osc_base_url(true); ?>?sShowAs=list" class="list-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><span><?php _e('List', 'spain_ibero'); ?></span></a>
           <a href="<?php echo osc_base_url(true); ?>?sShowAs=gallery" class="grid-button" data-class-toggle="listing-grid" data-destination="#listing-card-list"><span><?php _e('Grid', 'spain_ibero'); ?></span></a>
      </span>
    </div>
    <?php
    View::newInstance()->_exportVariableToView("listType", 'latestItems');
    View::newInstance()->_exportVariableToView("listClass",$listClass);
    osc_current_web_theme_path('loop.php');
    ?>
    <div class="clear"></div>
    <?php if( osc_count_latest_items() == osc_max_latest_items() ) { ?>
        <p class="see_more_link"><a href="<?php echo osc_search_show_all_url() ; ?>">
            <strong><?php _e('See all listings', 'spain_ibero') ; ?> &raquo;</strong></a>
        </p>
    <?php } ?>
<?php } ?>
</div>
</div><!-- main -->
<div id="sidebar">
<div class="visible-md visible-lg vista_300 maps">
<div class="map-btn btn btn-block" data-toggle="collapse" data-target="#collapsible-2"></div> 
<div class="map-tex-box">
<h3 class="text-center">Haz Clik Sobre el Mapa</h3>
<h3 class="text-center">Para filtrar y buscar por Regiones</h3>
</div>
</div>
<div class="category-box">
 <?php osc_run_hook('sidebar-catmain-spain-ibero'); ?>
</div>
        <?php if( osc_get_preference('sidebar-300x250', 'italia_azzurro') != '') {?>
    <!-- sidebar ad 350x250 -->
    <div class="vista_300">
        <?php echo osc_get_preference('sidebar-300x250', 'italia_azzurro'); ?>
    </div><div class="widget-box">
    <!-- /sidebar ad 350x250 -->
    <?php } else { echo '<div class="widget-box col-12">'; }?>

    <?php if(osc_count_list_regions() > 0 ) { ?>
        <div class="box-location">
            <h3><strong><?php _e("Location", 'italia_azzurro') ; ?></strong></h3>
            <ul>
            <?php while(osc_has_list_regions() ) { ?>
                <li><a href="<?php echo osc_list_region_url(); ?>"><?php echo osc_list_region_name() ; ?> <em>(<?php echo osc_list_region_items() ; ?>)</em></a></li>
            <?php } ?>
            </ul>
        </div>
        <?php } ?>

    </div>


</div>
<div class="clear"><!-- do not close, use main clossing tag for this case -->
<?php if( osc_get_preference('homepage-728x90', 'spain_ibero') != '') { ?>
<!-- homepage ad 728x60-->
<div class="vista_728">
    <?php echo osc_get_preference('homepage-728x90', 'spain_ibero'); ?>
</div>
<!-- /homepage ad 728x60-->
<?php } ?>
        <!-- map js -->
        <?php osc_current_web_theme_path('footer.php') ; ?>
        <script type="text/javascript" src="<?php echo osc_current_web_theme_js_url('jquery.maphilight.min.js') ; ?>"></script>
        <script type="text/javascript">
        $(function() {
            var linksRegions = new Array();
            var statsRegions = new Array();
        <?php
            $regions = json_decode(osc_get_preference('region_maps','spain_ibero'),true);
            if($regions){
                foreach($regions as $key => $value){
                    $regionData  = Region::newInstance()->findByPrimaryKey($value);
                    $regionStats = RegionStats::newInstance()->findByRegionId($value);
                    echo "    linksRegions['$key'] = '".map_spain_region_url($value)."';".PHP_EOL;
                    echo "    statsRegions['$key'] = {name:'".osc_esc_js($regionData['s_name'])."', count:'".$regionStats['i_num_items']."'};".PHP_EOL;
                }
            }
        ?>
            //find all regions map has assigned a location
            $('area').each(function(){
                var $_hasClass  = $(this).attr('class'); //catching
                var $_index     = $('area:not([class^="group"])').index($(this));
                var colorStatus = true;

                $(this).click(function(){
                    var key = $_index;
                    if(typeof $_hasClass != 'undefined' && $_hasClass != ''){
                         key = $_hasClass;
                    }
                    if(typeof linksRegions[key] != 'undefined'){
                        window.location.href = linksRegions[key];
                    }
                    return false;
                }).hover(function(e){
                    var key     = $_index;
                    var canvas  = undefined;
                    if(typeof $_hasClass != 'undefined' && $_hasClass != ''){
                         key = $_hasClass;
                    }
                    if(typeof statsRegions[key] != 'undefined') {
                        $('#map-tooltip').html(statsRegions[key].name + ': '+statsRegions[key].count + ' anuncios').css({
                            top: e.pageY,
                            left: e.pageX
                        }).show();
                        canvas = document.getElementById("map-hover");
                        canvas.width = canvas.width;
                        options = {
                            lineColor:  '#ffffff',
                            fillColor:  '#3AD003'
                        }
                        if($(this).attr('class') != '' && typeof $(this).attr('class') != 'undefined'){
                            $('.'+$(this).attr('class')).each(function(){
                                drawCanvas('map-hover', $(this).attr('coords'), options);
                            });
                        } else {
                            drawCanvas('map-hover', $(this).attr('coords'), options);
                        }
                    }
                },function(){
                    canvas       = document.getElementById("map-hover");
                    canvas.width = canvas.width;
                    $('#map-tooltip').hide();
                });
            });
        });
        </script>
        <div id="map-tooltip"></div>
        <!-- /map js -->
