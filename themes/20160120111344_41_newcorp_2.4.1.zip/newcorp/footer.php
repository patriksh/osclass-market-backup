<div id="footer">
    <div class="inner">
        <?php _e('This website is proudly using the classifieds scripts software <strong><a href="http://osclass.org/">Osclass</a></strong>', 'newcorp'); ?>.
    </div>
</div>