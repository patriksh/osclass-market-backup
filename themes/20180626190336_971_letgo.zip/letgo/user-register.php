<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');

    letgo_add_body_class('page sub-page');
    osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header3.php') ;
?>
<!--============ Page Title =========================================================================-->
                
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>

        <!--************ CONTENT ************************************************************************************-->
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-4 box">
                        <div class="">
                                <h3 align="center"><i class="fa fa-user"></i> <?php _e('My account', 'letgo'); ?></h3>
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="one-tab" data-toggle="tab" href="#one" role="tab" aria-controls="one" aria-expanded="true"><i class="fa fa-pencil"></i> <?php _e('Create', 'letgo'); ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="two-tab" data-toggle="tab" href="#two" role="tab" aria-controls="two"><i class="fa fa-sign-in"></i> <?php _e('Login', 'letgo'); ?></a>
                                    </li>
                                    
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="one" role="tabpanel" aria-labelledby="one-tab">
                                        <form name="register" action="<?php echo osc_base_url(true); ?>" method="post" enctype="multipart/form-data" class="form clearfix">
        <input type="hidden" name="page" value="register" />
        <input type="hidden" name="action" value="register_post" />
                                <div class="form-group">
                                    <label for="name" class="col-form-label required"><?php _e('Name', 'letgo'); ?></label>
                                    <?php UserForm::name_text(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="form-group">
                                    <label for="email" class="col-form-label required"><?php _e('E-mail', 'letgo'); ?></label>
                                    <?php UserForm::email_text(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="form-group">
                                    <label for="password" class="col-form-label required"><?php _e('Password', 'letgo'); ?></label>
                                    <?php UserForm::password_text(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="form-group">
                                    <label for="repeat_password" class="col-form-label required"><?php _e('Repeat password', 'letgo'); ?></label>
                                    <?php UserForm::check_password_text(); ?>
            <p id="password-error" style="display:none;">
              <?php _e("Passwords don't match", 'letgo'); ?>
            </p>
                                </div>
                                
                                <div class="form-group">
                                <?php osc_run_hook('user_register_form'); ?>
                                </div>
                                <div class="form-group">
                                <?php osc_show_recaptcha('register'); ?>
                                </div>
                                <!--end form-group-->
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <button type="submit" class="btn btn-success width-100"><?php _e("Create", 'letgo'); ?></button>
                                </div>
                            </form>
                                    </div>
                                    <?php UserForm::js_validation(); ?>
                                    <div class="tab-pane fade" id="two" role="tabpanel" aria-labelledby="two-tab">
                                        <form action="<?php echo osc_base_url(true); ?>" method="post" class="form clearfix">
        <input type="hidden" name="page" value="login" />
        <input type="hidden" name="action" value="login_post" />
                                <div class="form-group">
                                    <label for="email" class="col-form-label required"><?php _e('E-mail', 'letgo'); ?></label>
                                    <?php UserForm::email_login_text(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="form-group">
                                    <label for="password" class="col-form-label required"><?php _e('Password', 'letgo'); ?></label>
                                    <?php UserForm::password_login_text(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <label>
                                        <?php UserForm::rememberme_login_checkbox();?>
                                        <?php _e('Remember me', 'letgo'); ?>
                                    </label>
                                    <button type="submit" class="btn btn-success"><?php _e("Log in", 'letgo');?></button>
                                </div>
                            </form>
                            <hr>
                            <p align="center">
                                <a class="link" href="<?php echo osc_recover_user_password_url(); ?>">
          <?php _e("Forgot password?", 'letgo'); ?>
          </a>
                            </p>
                                    </div>
                                    
                                </div>
                            </div>
                            <!--end col-md-6-->
                            
                        </div>
                        <!--end col-md-6-->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
    
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>
