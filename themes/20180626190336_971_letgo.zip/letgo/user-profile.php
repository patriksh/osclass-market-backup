<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots

    letgo_add_body_class('page sub-page');
    osc_add_hook('before-main','sidebar');
    function sidebar(){
        osc_current_web_theme_path('user-sidebar.php');
    }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return osc_esc_html(__('Update account', 'letgo'));
    }
    osc_current_web_theme_path('header3.php') ;
	$locales = __get('locales');
    $osc_user = osc_user();
?>
<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2012 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    $address = '';
    if(osc_user_address()!='') {
        if(osc_user_city_area()!='') {
            $address = osc_user_address().", ".osc_user_city_area();
        } else {
            $address = osc_user_address();
        }
    } else {
        $address = osc_user_city_area();
    }
    $location_array = array();
    if(trim(osc_user_city()." ".osc_user_zip())!='') {
        $location_array[] = trim(osc_user_city()." ".osc_user_zip());
    }
    if(osc_user_region()!='') {
        $location_array[] = osc_user_region();
    }
    if(osc_user_country()!='') {
        $location_array[] = osc_user_country();
    }
    $location = implode(", ", $location_array);
    unset($location_array);

    osc_enqueue_script('jquery-validate');
?>
<style type="text/css">
/* body select.select_box */ 
body select { 
    display: block;
    padding: 1.5rem !important; 
    max-width: 100%; 
    border: 1px solid #e3e3e3; 
    border-radius: 3px; 
    background: url("<?php echo osc_current_web_theme_url('images/selectbox_arrow.png') ; ?>") right center no-repeat; 
    background-color: #fff; 
    color: #444444; 
    appearance: none; 
    /* this is must */ -webkit-appearance: none; 
    -moz-appearance: none; 
} 
/* body select.select_box option */ 
body select option { 

} 
/* for IE and Edge */ 
select::-ms-expand { 
    display: none; 
} 
select:disabled::-ms-expand { 
    background: #f60; 
}
</style>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php _e('Update account', 'letgo'); ?>
                            </h1>
                            <h4 class="">
                                <i class="fa fa-user"></i> <?php echo osc_logged_user_name(); ?></h4>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
 <!--*********************************************************************************************************-->
        <!--************ CONTENT ************************************************************************************-->
        <!--*********************************************************************************************************-->
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <aside class="sidebar">
                            <h2><?php _e('My account', 'letgo'); ?></h2>
                                <?php
	        osc_current_web_theme_path('user-sidebar.php');

   ?> </aside>
                            
                        </div>
                        <!--end col-md-3-->
                            <?php UserForm::location_javascript(); ?>
                        <div class="col-md-9 box">
                            <form action="<?php echo osc_base_url(true); ?>" method="post" enctype="multipart/form-data" class="form">
                            <input type="hidden" name="page" value="user" />
        <input type="hidden" name="action" value="profile_post" />
                                <div class="row">
                                    <div class="col-md-8">
                                        <h2><?php _e('Update account', 'letgo'); ?></h2>
                                        <section>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="title" class="col-form-label"><?php _e('User type', 'letgo'); ?></label>
                                                        <?php UserForm::is_company_select(osc_user()); ?>
                                                        
                                                    </div>
                                                    <!--end form-group-->
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="name" class="col-form-label required"><?php _e('Name', 'letgo'); ?></label> <?php UserForm::name_text(osc_user()); ?>
                                                        
                                                    </div>
                                                    <!--end form-group-->
                                                </div>
                                                <!--end col-md-8-->
                                                
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="title" class="col-form-label"><?php _e('Phone', 'letgo'); ?></label>
                                                        <?php UserForm::phone_land_text(osc_user()); ?>
                                                    </div>
                                                    <!--end form-group-->
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label for="name" class="col-form-label required"><?php _e('Cell phone', 'letgo'); ?></label>
                                                         <?php UserForm::mobile_text(osc_user()); ?>
                                                    </div>
                                                    <!--end form-group-->
                                                </div>
                                                <!--end col-md-8-->
                                                
                                            </div>
                                            <!--end row-->
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('Country', 'letgo'); ?></label>
                                                <?php UserForm::country_select(osc_get_countries(), osc_user()); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('Region', 'letgo'); ?></label>
                                                <?php UserForm::region_select(osc_get_regions(), osc_user()); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('City', 'letgo'); ?></label>
                                                <?php UserForm::city_select(osc_get_cities(), osc_user()); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('City area', 'letgo'); ?></label>
                                                <?php UserForm::city_area_text(osc_user()); ?>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('Address', 'letgo'); ?></label>
                                                <?php UserForm::address_text(osc_user()); ?>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="location" class="col-form-label required"><?php _e('Website', 'letgo'); ?></label>
                                                <?php UserForm::website_text(osc_user()); ?>
                                            </div>
                                            
                                            
                                            <!--end form-group-->
                                            <div class="form-group">
                                                <label for="about" class="col-form-label"><?php _e('Description', 'letgo'); ?></label>
                                                <div class="textareauser">
                                                <?php UserForm::info_textarea('s_info', osc_current_user_locale(), @$osc_user['locale'][osc_current_user_locale()]['s_info']); ?></div>
                                            </div>
                                            <!--end form-group-->
                                            
                                        </section>

                                        

                                        <section class="clearfix">
                           <button type="submit" class="btn btn-primary float-left"><?php _e("Update", 'letgo');?></button> 
                            <a class="btn btn-danger float-right" onclick="return confirm('<?php echo osc_esc_js(__('Are you sure you want to delete your account? This action cannot be undone', 'letgo')); ?>?')" href="<?php echo osc_base_url(true).'?page=user&action=delete&id='.osc_user_id().'&secret='.osc_user_field("s_secret").''; ?>"><?php _e('Delete account', 'letgo'); ?></a>
                                        </section>
                                    </div>
                                    <!--end col-md-8-->
                                    <div class="col-md-4">
                                        <div class="profile-image">
                                            <div class="image background-image">
                                                <?php if (function_exists('profile_picture_show')){profile_picture_show();} else{ echo '<img src="' . osc_current_web_theme_url('images/no-user-photo.jpg') . '">'; } ?>
                                            </div>
                                            <div class="single-file-input">
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <!--end col-md-3-->
                                </div>
                    <?php osc_run_hook('user_profile_form', osc_user()); ?>
                    <?php osc_run_hook('user_form', osc_user()); ?>
                            </form>
                            <?php if(function_exists('profile_picture_show')) { ?>
                            <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="about" class="col-form-label"><?php _e('Image', 'letgo'); ?></label>
                                                <div class="">
                                                <?php if(function_exists('profile_picture_show')) { profile_picture_upload(); } ?></div>
                                            </div>
                                            <hr />
                                            </div>
                                            <?php } ?>
                        </div>
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
    
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post2.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>
