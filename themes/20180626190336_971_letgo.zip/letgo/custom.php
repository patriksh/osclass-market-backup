<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    letgo_add_body_class('page sub-page');
	function sidebar(){
        osc_current_web_theme_path('search-sidebar.php');
    }
    osc_current_web_theme_path('header3.php') ;
?>
                <div class="background">
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <aside class="sidebar">
                            <h3 class="icon"><i class="fa fa-folder"></i> <?php _e('Category', 'letgo'); ?></h3>
                            <section>
                                <ul class="sidebar-list list-unstyled">                                     
                    	 <?php
         osc_goto_first_category();
         $i= 0;
         while ( osc_has_categories() ) {
            $liClass = '';
            if($i%3 == 0){
                $liClass = '';
            }
            $i++;
         ?> <li ><a class="nav-link icon" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name() ; ?> <span class="float-right">(<?php echo osc_category_total_items() ; ?>)</span></a></li><?php } ?>
         
                                     </ul> </section> </aside>
                        </div>
                        <!--end col-md-3-->
<div class="col-md-9">
<div class="box">
<?php osc_render_file(); ?>
</div>
     </div>
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
<?php osc_current_web_theme_path('footer.php') ; ?>