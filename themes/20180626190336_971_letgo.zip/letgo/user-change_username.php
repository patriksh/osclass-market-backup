<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');

    osc_enqueue_script('jquery-validate');

    letgo_add_body_class('page sub-page');
    osc_add_hook('before-main','sidebar');
    function sidebar(){
        osc_current_web_theme_path('user-sidebar.php');
    }
    osc_add_filter('meta_title_filter','custom_meta_title');
    function custom_meta_title($data){
        return osc_esc_html(__('Change username', 'letgo'));
    }
    osc_current_web_theme_path('header3.php') ;
    $osc_user = osc_user();
?>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php _e('Change username', 'letgo'); ?>
                            </h1>
                            <h4 class="">
                                <i class="fa fa-user"></i> <?php echo osc_logged_user_name(); ?></h4>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
<script type="text/javascript">
$(document).ready(function() {
    $('form#change-username').validate({
        rules: {
            s_username: {
                required: true
            }
        },
        messages: {
            s_username: {
                required: '<?php echo osc_esc_js(__("Username: this field is required", 'letgo')); ?>.'
            }
        },
        errorLabelContainer: "#error_list",
        wrapper: "li",
        invalidHandler: function(form, validator) {
            $('html,body').animate({ scrollTop: $('h1').offset().top }, { duration: 250, easing: 'swing'});
        },
        submitHandler: function(form){
            $('button[type=submit], input[type=submit]').attr('disabled', 'disabled');
            form.submit();
        }
    });

    var cInterval;
    $("#s_username").keydown(function(event) {
        if($("#s_username").attr("value")!='') {
            clearInterval(cInterval);
            cInterval = setInterval(function(){
                $.getJSON(
                    "<?php echo osc_base_url(true); ?>?page=ajax&action=check_username_availability",
                    {"s_username": $("#s_username").attr("value")},
                    function(data){
                        clearInterval(cInterval);
                        if(data.exists==0) {
                            $("#available").text('<?php echo osc_esc_js(__("The username is available", 'letgo')); ?>');
                        } else {
                            $("#available").text('<?php echo osc_esc_js(__("The username is NOT available", 'letgo')); ?>');
                        }
                    }
                );
            }, 1000);
        }
    });

});
</script>

<!--************ CONTENT ************************************************************************************-->
        <!--*********************************************************************************************************-->
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <aside class="sidebar">
                            <h2><?php _e('My account', 'letgo'); ?></h2>
                                <?php
	        osc_current_web_theme_path('user-sidebar.php');

   ?> </aside>
                            
                        </div>
                        <!--end col-md-3-->

<div class="col-md-9 box">
<ul id="error_list">
      </ul>
                            <form action="<?php echo osc_base_url(true); ?>" method="post" id="change-username" class="form">
      <input type="hidden" name="page" value="user" />
      <input type="hidden" name="action" value="change_username_post" />
                                <div class="row justify-content-center">
                                    <div class="col-md-6">
                                        <h2><?php _e('Change username', 'letgo'); ?></h2>
                                        <section>
                                        <div>
                                                    
                                                    <div class="form-group">
                                                        <label for="name" class="col-form-label"><?php _e('Change username', 'letgo'); ?>
            </label> <input type="text" name="s_username" id="s_username" value="" class="form-control" />
                      <div id="available"></div>

                                                        
                                                    <!--end form-group-->
                                                </div>

<section class="clearfix">
                           <button type="submit" class="btn btn-success float-left width-100"><?php _e("Update", 'letgo');?></button> 
                            </section> </div>
                                        </section>
                                        </div></div>
                                        </form>
                                       
     </div>
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
    
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>