<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php
$type = 'items';
if(View::newInstance()->_exists('listType')){
    $type = View::newInstance()->_get('listType');
}

?>

                            <!--============ Section Title===================================================================-->
                            <div class="section-title clearfix">
                                <div class="float-left float-xs-none">
                                    <h2><?php _e('My listings', 'letgo'); ?></h2>
                                    

                                </div>
                                <div class="float-right d-xs-none thumbnail-toggle">
                                     <a href="#" class="change-class active" data-change-from-class="list" data-change-to-class="grid" data-parent-class="items">
                                        <i class="fa fa-th"></i>
                                    </a>
                                    <a href="#" class="change-class" data-change-from-class="grid" data-change-to-class="list" data-parent-class="items">
                                        <i class="fa fa-th-list"></i>
                                    </a>
                                </div>
                            </div>
                            <!--============ Items ==========================================================================-->

                            <div class="items grid compact grid-xl-3-items grid-lg-2-items grid-md-2-items">
  <?php
	$i = 0;
	
	//latest items
	if($type == 'latestItems'){

    while ( osc_has_latest_items() ) {
?>
  <div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->

<h4>
                                    <a href="#"><?php echo osc_format_date(osc_item_pub_date()); ?></a>                                </h4>
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                <?php if($admin){ ?>
                <div class="admin-controls">
                                            
                                                <a href="<?php echo osc_item_edit_url(); ?>" rel="nofollow">
            <i class="fa fa-pencil"></i><?php _e('Edit item', 'letgo'); ?>
            </a>
                                            
                                                <a class="delete" onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'letgo')); ?>')" href="<?php echo osc_item_delete_url();?>" >
           <i class="fa fa-trash"></i><?php _e('Delete', 'letgo'); ?>
            </a>
                                            
                                                <?php if(osc_item_is_inactive()) {?>
             <a href="<?php echo osc_item_activate_url();?>">
            <i class="fa fa-eye-slash"></i><?php _e('Activate', 'letgo'); ?>
            </a>
            <?php } ?>
                                            
                                        </div>
                                        <!--end admin-controls-->
                                        <?php } ?>
                                
                                
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_title() ,75) ; ?> <?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                
                                
                                
                                                        <a href="<?php echo osc_item_url() ; ?>" class="detail text-caps underline"><i class="fa fa-arrow-right"></i></a>   </div>
                        </div>
  <?php	
        }

    } 
		
	// premium items
	elseif($type == 'premiums'){
		while ( osc_has_premiums() ) {
?>
  <div class="item">
                            <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_premium_category() ; ?></a>
                                        <a href="<?php echo osc_premium_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_premium_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_premium_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_premium_resources()) { ?>
            <a href="<?php echo osc_premium_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_premium_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_premium_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_premium_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->

<h4>
                                    <a href="#"><?php echo osc_format_date(osc_premium_pub_date()); ?></a>                                </h4>
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_premium_category_id()) ) { echo osc_premium_formated_price(); ?><?php } ?></div>
                                <?php if($admin){ ?>
                <div class="admin-controls">
                                            
                                                <a href="<?php echo osc_item_edit_url(); ?>" rel="nofollow">
            <i class="fa fa-pencil"></i><?php _e('Edit item', 'letgo'); ?>
            </a>
                                            
                                                <a class="delete" onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'letgo')); ?>')" href="<?php echo osc_item_delete_url();?>" >
           <i class="fa fa-trash"></i><?php _e('Delete', 'letgo'); ?>
            </a>
                                            
                                                <?php if(osc_item_is_inactive()) {?>
             <a href="<?php echo osc_item_activate_url();?>">
            <i class="fa fa-eye-slash"></i><?php _e('Activate', 'letgo'); ?>
            </a>
            <?php } ?>
                                            
                                        </div>
                                        <!--end admin-controls-->
                                        <?php } ?>
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_premium_title() ,75) ; ?> <?php echo osc_highlight( osc_premium_description() ,250) ; ?></p>
                                </div>
                                
                                
                                
                                                        <a href="<?php echo osc_premium_url() ; ?>" class="detail text-caps underline"><i class="fa fa-arrow-right"></i></a>   </div>
                        </div>
  <?php
            }
        }
		else {
            while(osc_has_items()) {

                $admin = false;
                if(View::newInstance()->_exists("listAdmin")){
                    $admin = true;
                }
?>
  <div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->


                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                
            <?php if($admin){ ?>
                <div class="admin-controls">
                                            
                                                <a href="<?php echo osc_item_edit_url(); ?>" rel="nofollow">
            <i class="fa fa-pencil"></i><?php _e('Edit item', 'letgo'); ?>
            </a>
                                            
                                                <a class="delete" onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'letgo')); ?>')" href="<?php echo osc_item_delete_url();?>" >
           <i class="fa fa-trash"></i><?php _e('Delete', 'letgo'); ?>
            </a>
                                            
                                                <?php if(osc_item_is_inactive()) {?>
             <a href="<?php echo osc_item_activate_url();?>">
            <i class="fa fa-eye-slash"></i><?php _e('Activate', 'letgo'); ?>
            </a>
            <?php } ?>
                                            
                                        </div>
                                        <!--end admin-controls-->
                                        <?php } ?>
                                
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_title() ,75) ; ?> <?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                
                                
                                
                                                        <a href="<?php echo osc_item_url() ; ?>" class="detail text-caps underline"><i class="fa fa-arrow-right"></i></a>   </div><!-- letgo end wrapper -->
                        </div>
  <?php
        }
  }
?>
</div>
