<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
	 $category = (array)__get("category");
     if(!isset($category['pk_i_id']) ) {
         $category['pk_i_id'] = null;
     }

?>
                        
                        
                        <!-- LETGO SEARCH SIDEBAR -->
  <div class="col-md-12">
                            <!--============ Side Bar ===============================================================-->
                            <aside class="sidebar">
                                <section>
                                    <h2><?php _e('Search', 'letgo'); ?></h2>
                                    <!--============ Side Bar Search Form ===========================================-->
                                    
                            
                            <?php letgo_sidebar_category_search($category['pk_i_id']); ?>
                                
                                    <form action="<?php echo osc_base_url(true); ?>" method="get" class="sidebar-form form">
              <input type="hidden" name="page" value="search"/>
              <input type="hidden" name="sOrder" value="<?php echo osc_search_order(); ?>" />
              <input type="hidden" name="iOrderType" value="<?php $allowedTypesForSorting = Search::getAllowedTypesForSorting() ; echo $allowedTypesForSorting[osc_search_order_type()]; ?>" />
              <?php foreach(osc_search_user() as $userId) { ?>
              <input type="hidden" name="sUser[]" value="<?php echo $userId; ?>"/>
              <?php } ?> <br />
                                        <div class="form-group">
                                            
                                            
                                            <input class="form-control" type="text" name="sPattern"  id="query" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'letgo'), 'letgo')); ?>" value="<?php echo osc_esc_html(osc_search_pattern()); ?>" />
                                        </div>
                                        <!--end form-group-->
                                        <div class="form-group">
                                            <?php osc_categories_select('sCategory', null, osc_esc_html(__('Select a category', 'letgo'))) ; ?>
                                        </div>
                                        
                                        			  <?php if(osc_get_preference('show_search_country', 'letgo') == '1'){?>
                                        <div class="form-group">
                                            
                                            <?php letgo_countries_select('sCountry', 'sCountry', __('Country', 'letgo'), osc_esc_html(Params::getParam('sCountry')));?>
                                        </div>
                                        
                                        <div class="form-group">    
                                            <input placeholder="<?php echo osc_esc_html(__('Region', 'letgo')) ; ?>" class="form-control" type="text" id="" name=" sRegion" value="<?php echo osc_esc_html(osc_search_region()); ?>" />
                                            <span class="geo-location input-group-addon" data-toggle="tooltip" data-placement="top"><i class="fa fa-map-marker"></i></span>
                                        </div>
                                        <?php } ?>
                                        <!--end form-group-->                                                    
                                                    <?php if( osc_price_enabled_at_items() ) { ?>
                                                    <div class="form-group">
                                                    <div class="form-row">
    
    <div class="col">
      <input id="priceMin" name="sPriceMin" value="<?php echo osc_esc_html(osc_search_price_min()); ?>" type="text" class="form-control" placeholder="&euro; <?php echo osc_esc_html(__('Min', 'letgo')) ; ?>">
    </div>
    <div class="col">
      <input id="priceMax" name="sPriceMax" value="<?php echo osc_esc_html(osc_search_price_max()); ?>" type="text" class="form-control" placeholder="&euro; <?php echo osc_esc_html(__('Max', 'letgo')) ; ?>">
    </div>
  </div>
               </div>    <?php } ?>                                 
                                        
              <?php
        $aCategories = osc_search_category();
        foreach($aCategories as $cat_id) { ?>
              <input type="hidden" name="sCategory[]" value="<?php echo osc_esc_html($cat_id); ?>"/>
              <?php } ?>
                                        <!--end form-group-->
                                        <!--Alternative Form-->
                                        <div class="alternative-search-form">
                                            <a href="#collapseAlternativeSearchForm" class="btn btn-framed small btn-light width-100" data-toggle="collapse"  aria-expanded="false" aria-controls="collapseAlternativeSearchForm"><i class="fa fa-caret-down"></i> <?php _e('Custom fields') ; ?></a>
                                            <div class="collapse" id="collapseAlternativeSearchForm">
                                                <div class="wrapper">
                                                    
                                                    <div class="form-group">
                                        
                <?php
            if(osc_search_category_id()) {
                osc_run_hook('search_form', osc_search_category_id()) ;
            } else {
                osc_run_hook('search_form') ;
            }
            ?>
              
                                                    </div>
                                                    
                                                    <?php if( osc_images_enabled_at_items() ) { ?>
                                        <div class="form-group">
                                        
                                        <label>
                                                        <?php _e('Show only', 'letgo') ; ?> <?php _e('listings with pictures', 'letgo') ; ?>? <input type="checkbox" name="bPic" id="withPicture" value="1" <?php echo (osc_search_has_pic() ? 'checked' : ''); ?> />
                                                    </label>
                                                    </div>
                                                    <?php } ?>
                                                    
                                                    <!--end form-group-->
                                                </div>
                                                <!--end wrapper-->
                                            </div>
                                            <!--end collapse-->
                                        </div>
                                        <!--end alternative-search-form-->
                                        <br />
                                        <button type="submit" class="btn btn-primary width-100"><?php _e('Apply', 'letgo') ; ?></button>

                                    </form>
                                    <br />
                                    <div class="form-group">
      <?php osc_alert_form(); ?>
      </div>
                                    <!--============ End Side Bar Search Form =======================================-->
                                    <?php if( osc_get_preference('search-results-middle-728x90', 'letgo') != '') {?>
  <br /> <div class="box" align="center"> <?php echo osc_get_preference('search-results-middle-728x90', 'letgo'); ?> </div>
  <?php } ?>
                                </section>
                            </aside>
                            <!--============ End Side Bar ===========================================================-->
</div>
  <!-- END LETGO SEARCH SIDEBAR -->