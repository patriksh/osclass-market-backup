<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php
    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');
    letgo_add_body_class('page home-page');
    osc_current_web_theme_path('header.php') ;
?>

<section class="content">
        
            <!--============ Categories =============================================================================-->
            <section class="block">        
                
<div class="container">
<h1 align="center">
        <?php _e("Sorry but I can't find the page you're looking for", 'letgo') ; ?>
      </h1>
      <div class="box" align="center"><i class="fa fa-exclamation-triangle fa-5x" style="color:#FF9900"></i></div>
      <h2 align="center">
          <?php _e("<strong>Look</strong> for it in the most popular categories.", 'letgo') ; ?>
        </h2>
<h3 align="center"><?php _e('Select a category', 'letgo');?></h3>

<ul class="categories-list clearfix">
<?php

	$total_categories   = osc_count_categories();
	$col1_max_cat       = ceil($total_categories/1);
	osc_goto_first_category();
	$catcount	=	0;
	while ( osc_has_categories() ) {
?>
  <li>
    
     <a href="javascript:void(0)" data-toggle="modal" data-target="#<?php echo osc_esc_html(osc_category_id()) ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon fa-lg"></i></a>
      <?php
			$_slug      = osc_category_slug();
			$_url       = osc_search_category_url();
			$_name      = osc_category_name();
			$_total_items = osc_category_total_items();
			if ( osc_count_subcategories() > 0 ) { ?>
      <?php } ?>
      <?php if($_total_items > 0) { ?>
      <h3><a class="ellipsis <?php echo osc_esc_html(osc_category_slug()) ; ?>" href="<?php echo $_url; ?>"><?php echo $_name ; ?></a></h3>
      <?php } else { ?>
      <h3><a class="ellipsis <?php echo osc_esc_html(osc_category_slug()) ; ?>" href="<?php echo $_url; ?>"><?php echo $_name ; ?></a></h3>
      <?php } ?>
    
    
    <?php if ( osc_count_subcategories() > 0 ) { $m=1; ?>
    <div class="sub-categories ellipsis">
      <?php while ( osc_has_subcategories() ) { if( $m<=(osc_get_preference('sub_cat_limit', 'letgo'))){?>
      
        <?php if( osc_category_total_items() > 0 ) { ?>
        <a class=" <?php echo osc_esc_html(osc_category_slug()) ; ?>" href="<?php echo $_url; ?>"><?php _e('Listings', 'letgo'); ?></a> <span><?php echo $_total_items ; ?></span>
        <?php } else { ?>
        <a class=" <?php echo osc_esc_html(osc_category_slug()) ; ?>" href="<?php echo $_url; ?>"><?php _e('Listings', 'letgo'); ?></a> <span><?php echo $_total_items ; ?></span>
        <?php } ?>
      
      <?php } $m++; } if($m>(osc_get_preference('sub_cat_limit', 'letgo'))+1) {?>
      
      <?php } ?>
    </div>
    <?php } ?>
    
  </li>
  <?php
		$catcount++;
		if($catcount%4==0)
		{
			echo '</ul><ul class="categories-list clearfix">';
		}
    }
 ?>
</ul>
 </div>
                <!--end categories-list-->
                <!--end container-->
            </section>
            </section>
            <?php

	$total_categories   = osc_count_categories();
	$col1_max_cat       = ceil($total_categories/1);
	osc_goto_first_category();
	$catcount	=	0;
	while ( osc_has_categories() ) {
?>
            <!-- LETGO CATEGORY MODAL -->
<div class="modal fade" id="<?php echo osc_esc_html(osc_category_id()) ; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabelhelp">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <a class="btn btn-success small width-100" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name() ; ?></a>
      </div>
      <div class="modal-body">
      <?php while( osc_has_subcategories() > 0 ) { ?>  <a href="<?php echo osc_search_category_url() ; ?>" class="btn btn-light btn-framed small width-100"><?php echo osc_category_name() ; ?></a> <?php } ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info small width-100" data-dismiss="modal"><?php _e('Close', 'letgo'); ?></button>
      </div>
    </div>
  </div>
</div>
<!-- END LETGO CATEGORY MODAL -->
<?php } ?>
<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<?php osc_current_web_theme_path('footer.php') ; ?>