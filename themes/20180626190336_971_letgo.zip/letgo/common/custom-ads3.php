<?php $random = ''; 
$random = rand(0, 15); //more info about the rand function can be found at the link below. ?>
	<?php osc_query_item(array(
    "category_name" => osc_esc_html(osc_get_preference('slidercatname3', 'letgo')),
	"results_per_page" => "4",
	// "offset" => $random
    
));
if( osc_count_custom_items() == 0) { ?>
   
<?php } else { ?>
    <!-- normal ads -->
                <div class="container">
                    <!--============ Section Title===================================================================-->
                    
                    <!--============ Items ==========================================================================-->
                    <div class="items compact grid grid-xl-4-items grid-lg-3-items grid-md-2-items">
			<?php while ( osc_has_custom_items() ) { ?>
<div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                                <div class="meta">
                                    <figure>
                                                        <i class="fa fa-calendar"></i><?php echo osc_format_date(osc_item_pub_date()); ?>
                                                    </figure>
                                    <figure>
                                        <a href="#">
                                            <i class="fa fa-user"></i><?php echo osc_item_contact_name(); ?>                                        </a>                                    </figure>
                                </div>
                                <!--end meta-->
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                                           </div>
                        </div> <?php } ?> </div>
                    <!--============ End Items ======================================================================-->  
                </div>
                <!--end container-->
<!-- LETGO --> <?php } ?>
<!-- end custom ads -->