<?php $random = ''; 
            $random = rand(0, 12); //more info about the rand function can be found at the link below. ?>
	<?php osc_query_item(array(
    "category_name" => "",
	"results_per_page" => "6",
	"offset" => $random
    
));
if( osc_count_custom_items() == 0) { ?>
    
<?php } else { ?>
                                    
                                    <h3 class="text-center"><i class="fa fa-random" aria-hidden="true"></i> <?php _e('Listings', 'letgo'); ?> <?php _e('Random', 'letgo'); ?></h3>

                                <div class="read-more" data-read-more-link-more="<i class='fa fa-chevron-down'></i>" data-read-more-link-less="<i class='fa fa-chevron-up'></i>">
<div class="items grid compact grid-xl-2-items grid-lg-2-items grid-md-2-items">    
<?php while ( osc_has_custom_items() ) { ?>
            <div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->

                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                                <div class="meta">
                                    <figure>
                                                    <i class="fa fa-calendar-o"></i><?php echo osc_format_date(osc_item_pub_date()); ?>
                                                </figure>
                                    <figure>
                                        <a href="#">
                                            <i class="fa fa-user"></i><?php echo osc_item_contact_name(); ?>                                        </a>                                    </figure>
                                </div>
                                <!--end meta-->
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_title() ,75) ; ?> <?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                
                                <?php $admin = false; ?>
            <?php if($admin){ ?>
                                <!--end description-->
                                <div class="additional-info">
                                    <ul>
                                        <li>
                                            <figure><a href="<?php echo osc_item_edit_url(); ?>" rel="nofollow">
            <?php _e('Edit item', 'letgo'); ?>
            </a></figure>
                                        </li>
                                        <li>
                                            <figure><a class="delete" onclick="javascript:return confirm('<?php echo osc_esc_js(__('This action can not be undone. Are you sure you want to continue?', 'letgo')); ?>')" href="<?php echo osc_item_delete_url();?>" >
            <?php _e('Delete', 'letgo'); ?>
            </a></figure>
                                        </li>
                                        <li>
                                            <figure><?php if(osc_item_is_inactive()) {?>
             <a href="<?php echo osc_item_activate_url();?>" >
            <?php _e('Activate', 'letgo'); ?>
            </a>
            <?php } ?></figure>
                                        </li>
                                    </ul>
                                </div>
                                <!--end addition-info-->
                                <?php } ?>
                               </div>
                        </div> <?php } ?>
            
    </div>
</div>
<?php } ?>