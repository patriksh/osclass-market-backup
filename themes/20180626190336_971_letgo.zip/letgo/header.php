<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<!doctype html>
<html  dir="ltr" lang="<?php echo str_replace('_', '-', osc_current_user_locale()); ?>">
<head>
<?php osc_current_web_theme_path('common/head.php') ; ?>
</head>
<body>
<div <?php letgo_body_class(); ?>>
<!-- LETGO -->
<header class="hero">
            <div class="hero-wrapper">
                <!--============ Secondary Navigation ===============================================================-->
                <div class="secondary-navigation">
                    <div class="container">
                        <ul class="left">
                            <li class="d-none d-sm-block">
                            <span><?php if( osc_get_preference('welcome_message', 'letgo') != '') {?> <?php echo osc_esc_html( osc_get_preference('welcome_message', 'letgo') ); ?> <?php } else { ?> <?php echo osc_page_title(); ?> <?php } ?></span>
                            </li>
                            <li><?php if( osc_get_preference('facebook-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('facebook-top', 'letgo')); ?>"><i class="fa fa-facebook"></i></a>
                    <?php } else { ?><a href="javascript:void(0)"><i class="fa fa-facebook"></i></a><?php } ?></li>    <li><?php if( osc_get_preference('twitter-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('twitter-top', 'letgo')); ?>"> <i class="fa fa-twitter"></i></a> <?php } else { ?> <a href="javascript:void(0)"> <i class="fa fa-twitter"></i></a> <?php } ?></li> <li><?php if( osc_get_preference('google-plus-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('google-plus-top', 'letgo')); ?>"><i class="fa fa-google-plus"></i></a>  <?php } else { ?> <a href="javascript:void(0)"><i class="fa fa-google-plus"></i></a> <?php } ?></li>
                        </ul>
                        <!--end left-->
                        <ul class="right">
                        <li class="d-block d-sm-none">
                                        <a href="<?php echo osc_item_post_url(); ?>"><i class="fa fa-pencil" aria-hidden="true"></i> <?php _e('Publish', 'letgo');?></a>
                                    </li>
                            <?php if( osc_users_enabled() ) { ?>
            <?php if( osc_is_web_user_logged_in() ) { ?>
                            <li>
                                <a href="<?php echo osc_user_profile_url(); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Dashboard', 'letgo'); ?></a>
                            </li> <li><a href="<?php echo osc_user_logout_url(); ?>"><i class="fa fa-sign-out"></i>
          <?php _e('Logout', 'letgo'); ?>
          </a></li>
                            <?php } else { ?>
            <li><a href="<?php echo osc_user_login_url(); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i> <?php _e('Login', 'letgo') ; ?></a></li>
            <?php if(osc_user_registration_enabled()) { ?>
        <li><a href="<?php echo osc_register_account_url() ; ?>"><i class="fa fa-user"></i> 
          <?php _e('Create', 'letgo'); ?>
          </a></li> <?php }; ?>
            <?php } ?>
            <?php } ?> 
                        </ul>
                        <!--end right-->
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Secondary Navigation ===========================================================-->
                <!--============ Main Navigation ====================================================================-->
                <div class="main-navigation">
                    <div class="container">
                        <nav class="navbar navbar-expand-lg navbar-light justify-content-between">
                            <a class="navbar-brand" href="<?php echo osc_base_url(); ?>">
                                <?php echo logo_header(); ?>
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbar">
                                <!--Main navigation list-->
                                <ul class="navbar-nav">
                                    <li class="nav-item active">
                                        <a class="nav-link" href="<?php echo osc_base_url(); ?>"><i class="fa fa-home"></i></a>
                                    </li>
                                    <!-- LETGO CATEGORY -->
                                    <li class="nav-item has-child">
                                        <a class="nav-link" href="#"><i class="fa fa-folder"></i> <?php _e('Category', 'letgo'); ?></a>
                                        <ul class="child">
                                                <?php
         osc_goto_first_category();
         $i= 0;
         while ( osc_has_categories() ) {
            $liClass = '';
            if($i%3 == 0){
                $liClass = '';
            }
            $i++;
         ?> <li class="nav-item"><a class="nav-link icon" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i><?php echo osc_category_name() ; ?> <span class="float-right"><?php echo osc_category_total_items() ; ?></span></a><?php if(osc_count_subcategories() > 0) { ?><!-- 2nd level -->
                                                <ul class="child">
                                                <?php while(osc_has_subcategories()) { ?>
                                                    <li class="nav-item">
                                                        <a href="<?php echo osc_search_category_url() ; ?>" class="nav-link"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name(); ?></a>
                                                    </li>
                                                    <?php } ?>
                                                    
                                                </ul>
                                                <!-- end 2nd level --><?php } ?></li><?php } ?>
                                        </ul>
                                    </li>
                                    <!-- END LETGO CATEGORY -->
                                    <?php ?>
        <?php if ( osc_count_web_enabled_locales() > 1) { ?>
        <?php osc_goto_first_locale(); ?>
                                    <li class="nav-item  has-child">
                                        <a class="nav-link" href="#"><i class="fa fa-flag fa-fw" aria-hidden="true"></i> <?php $local = osc_get_current_user_locale(); echo $local['s_name']; ?></a>
                                        <ul class="child">
                                            <?php $i = 0;  ?>
          <?php while ( osc_has_web_enabled_locales() ) { ?>
          <li class="nav-item"><a class="nav-link" <?php if(osc_locale_code() == osc_current_user_locale() ) echo ""; ?> id="<?php echo osc_locale_code(); ?>" href="<?php echo osc_change_language_url ( osc_locale_code() ); ?>"><?php echo osc_locale_name(); ?></a></li>
          <?php if( $i == 0 ) { echo ""; } ?>
          <?php $i++; ?>
          <?php } ?>
                                        </ul>
                                    </li>
                                    <?php } ?>
                                    <?php if( osc_has_static_pages() ) { ?>
                                    <li class="nav-item  has-child">
                                    
                                        <a class="nav-link" href="#"><i class="fa fa-file-text" aria-hidden="true"></i> <?php _e("Pages"); ?></a>
                                        <ul class="child">
                                        <?php
        osc_reset_static_pages();
        while( osc_has_static_pages() ) { ?>
                                        <li class="nav-item"> <a class="nav-link" href="<?php echo osc_static_page_url(); ?>"><?php echo osc_static_page_title(); ?></a> </li>
                                        <?php
        }
        ?>
                                        </ul>
                                    </li>   
                                    <?php } else { ?>
                                    <?php } ?>                                 
                                    <li class="nav-item">
                                    <a class="nav-link" href="<?php echo osc_contact_url(); ?>"><i class="fa fa-envelope" aria-hidden="true"></i> <?php _e('Contact', 'letgo'); ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo osc_item_post_url(); ?>" class="btn btn-primary text-caps  btn-framed"><i class="fa fa-pencil" aria-hidden="true"></i> <?php _e('Publish', 'letgo');?></a>
                                    </li>
                                </ul>
                                <!--Main navigation list-->
                            </div>
                            <!--end navbar-collapse-->
                        </nav>
                        <!--end navbar-->
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Main Navigation ================================================================-->
                <!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container">
                        <h1 class="opacity-40 center">
                            <?php _e('Search', 'letgo'); ?> in <a href="<?php echo osc_search_show_all_url() ; ?>"><?php echo osc_total_items(); ?></a> <?php _e('Listings', 'letgo'); ?> </h1>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <!--============ Hero Form ==========================================================================-->
        <form action="<?php echo osc_base_url(true); ?>" id="main_search" method="get" class="search nocsrf hero-form form" >
        <input type="hidden" name="page" value="search"/>
                    <div class="container">
                        <!--Main Form-->
                        <div class="main-search-form">
                            <div class="form-row">
                                <div class="col-md-5 col-sm-5">
                                    <div class="form-group">
                                        <input type="text" name="sPattern" id="query" class="form-control" value="" placeholder="<?php echo osc_esc_html(__(osc_get_preference('keyword_placeholder', 'letgo'), 'letgo')); ?>" />
                                        
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-3-->
                                <div class="col-md-3 col-sm-3">
                                    <div class="form-group">
                                        <?php  if ( osc_count_categories() ) { ?>
                
                  <?php osc_categories_select('sCategory', null, osc_esc_html(__('Select a category', 'letgo'))) ; ?>
                
                <?php  } ?>
                                                                            </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-3-->
                                <div class="col-md-3 col-sm-3">
                                    <div class="form-group">
                                        <?php letgo_countries_select('sCountry', 'sCountry', __('Select a country', 'letgo'));?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-3-->
                                <div class="col-md-1 col-sm-1">
                                    <button type="submit" class="btn btn-primary width-100"><i class="fa fa-search"></i>

</button>
                                </div>
                                <!--end col-md-3-->
                            </div>
                            <!--end form-row-->
                        </div>
                        <!--end main-search-form-->
                        <!--Alternative Form-->
                        <?php $showCountry  = (osc_get_preference('show_search_country', 'letgo') == '1') ? true : false; ?>
                        <?php if($showCountry) { ?>
                        <div class="alternative-search-form">
                            <a href="#collapseAlternativeSearchForm" class="icon" data-toggle="collapse"  aria-expanded="false" aria-controls="collapseAlternativeSearchForm"><i class="fa fa-map-marker" aria-hidden="true"></i><?php _e('Listing Location', 'letgo'); ?></a>
                            <div class="collapse" id="collapseAlternativeSearchForm">
                                <div class="wrapper">
                                    <div class="form-row">
                                        <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 d-xs-grid d-flex align-items-center justify-content-between">
                                                    <div class="form-group">
                                                    <i class="fa fa-map-marker" aria-hidden="true"></i> <?php _e('Country', 'letgo'); ?>: <?php if(osc_count_list_countries() > 0 ) { ?>
     <?php while(osc_has_list_countries() ) { ?>
									 <a class="btn btn-framed btn-light small" href="<?php echo osc_list_country_url(); ?>"><?php echo osc_list_country_name(); ?> (<?php echo osc_list_country_items(); ?>)</a>					
 <?php } ?><?php } ?>
                                                    </div>
                                        </div>
                                        <!--end col-xl-6-->
                                        <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12">
                                                <div class="">
                                                    <div class="form-group">
                                                       <i class="fa fa-map-pin" aria-hidden="true"></i> <?php _e('City', 'letgo'); ?>: <?php if(osc_count_list_regions() > 0 ) { ?>
     <?php while(osc_has_list_regions() ) { ?>
									 <a class="btn btn-framed btn-light small" href="<?php echo osc_list_region_url(); ?>"><?php echo osc_list_region_name(); ?> (<?php echo osc_list_region_items(); ?>)</a>					
 <?php } ?><?php } ?>                                                    </div>
                                                    <!--end form-group-->
                                                </div>
                                                <!--end col-md-4-->
                                        </div>
                                        <!--end col-xl-6-->
                                    </div>
                                    <!--end row-->
                                </div>
                                <!--end wrapper-->
                            </div>
                            <!--end collapse-->
                        </div>
                        <!--end alternative-search-form-->
                        <?php } ?>
                    </div>
                    <!--end container-->
                </form>
                <!--============ End Hero Form ======================================================================-->
                <div class="background">
                    <div class="background-image">
<?php 
	if(osc_get_preference('show_banner', 'letgo')=='1'){
				echo homepage_image(); 
			}
?>                    </div>
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>