<div class="items grid compact grid-xl-3-items grid-lg-2-items grid-md-2-items">                            
  
  <?php
            while(osc_has_items()) {                
?>
  <div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                                <div class="meta">
                                    <figure>
                                    <i class="fa fa-calendar"></i><?php echo osc_format_date(osc_item_pub_date()); ?></figure>
                                    <figure>
                                    <figure>
                                        <a href="#">
                                            <i class="fa fa-user"></i><?php echo osc_item_contact_name(); ?>                                        </a>                                    </figure>
                                </div>
                                <!--end meta-->
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_title() ,75) ; ?> <?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                
                                                        <a href="<?php echo osc_item_url() ; ?>" class="detail text-caps underline"><i class="fa fa-arrow-right"></i></a>   </div><!-- letgo end wrapper -->
                        </div>
  <?php 
  }
?>
</div>