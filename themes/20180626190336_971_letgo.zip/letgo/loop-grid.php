<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php
$type = 'items';
if(View::newInstance()->_exists('listType')){
    $type = View::newInstance()->_get('listType');
}

?>
  <?php
	//latest items
	if($type == 'latestItems'){

    while ( osc_has_latest_items() ) {
?>
  <div class="item">
                            <?php if(osc_item_is_premium()){ ?> <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div> <?php } else { ?> <?php } ?>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_item_category() ; ?></a>
                                        <a href="<?php echo osc_item_url() ; ?>" class="title ellipsis" style="max-width: 220px;"><?php echo osc_highlight( osc_item_title() ,22) ; ?></a>
                                        <span class="tag"><?php echo osc_count_item_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_item_resources()) { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_item_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_item_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() ) { ?>
                 <?php echo osc_format_price(osc_item_price()); ?> 
                <?php } ?></div>
                                <div class="meta">
                                    <figure>
                                                        <i class="fa fa-calendar"></i><?php echo osc_format_date(osc_item_pub_date()); ?>
                                                    </figure>
                                    <figure>
                                        <a href="#">
                                            <i class="fa fa-user"></i><?php echo osc_item_contact_name(); ?>                                        </a>                                    </figure>
                                </div>
                                <!--end meta-->
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_item_description() ,250) ; ?></p>
                                </div>
                                                           </div>
                        </div>
                        <!--end item-->
  <?php	
        }
    } 
?>