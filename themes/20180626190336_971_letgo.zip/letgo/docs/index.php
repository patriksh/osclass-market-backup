<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Letgo Osclass Theme - Installation Documentation</title>
<link href="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<aside>
  <div id="nav"> <a class="logo" href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#home"><img src="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/logo.png" alt="logo"></a>
    <ul>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#overview">Theme overview</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#install">Installation &amp; Configuration</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#lfv">Logo and Favicon</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#plugins">Plugins</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#banner">Icons for categories</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#lsh">Listings by custom category</a></li>
      <li><a href="<?php osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>#credits">Credits</a></li>
    </ul>
    <address>
    
    </address>
  </div>
</aside>
<section>
  <article id="overview">
  <br />
    <h2>Letgo Theme - v. 1.0.0</h2>
    <ul>
      <li>Responsive layout</li>
      <li>Div/Tabless HTML5 mark-up</li>
      <li>CSS 2.0 and CSS 3.0 valid</li>
      <li>Based on bootstrap framework by <a target="_blank" href="http://getbootstrap.com/">getbootstrap</a>.</li>
      <li>Cross-browser compatibility. Compatible with latest versions of all major browsers such as IE, Firefox, Safari, Chrome, Opera</li>
      <li>OSclass compatibility up to: 3.7.4</li>
    </ul>
  </article>
  <article id="install">
    <h2>1. Installation &amp; Configuration</h2>
    <p>Here you will find step-by-step instructions for installing and using LETGO theme for your osclass installation.</p>
    <p class="alert"><span>To make things easy for you we have prepared the separate theme package &amp; this theme will not overwrite any files.</span></p>
   
    <h3>System Requirements</h3>
    <p> <span> Installation requirements :<br>
      PHP version: 5.6 or newer / MySQL database (or access to create one) / MySQLi module for PHP / GD module for PHP </span> </p>
    <p>Letgo theme is compatible up to Osclass ver. 3.7.4 which can be downloaded from <a href="http://osclass.org/page/download" target="_blank">http://osclass.org/page/download</a></p>
    <p> Please, make sure you meet the minimum system requirements and test the compatibility of your server.</p>
    <p> For help with installing Osclass theme, please refer to the following links: </p>
    <ul>
      <li><a href="http://osclass.org/page/get-started" target="_blank">Get-started</a></li>
      <li><a href="http://osclass.org/page/tutorials" target="_blank">Tutorials</a></li>
      <li><a href="http://static.osclass.org/installation/guide.pdf" target="_blank"> Osclass Installation Guide</a></li>
    </ul>
    <h3>Uploading letgo Theme</h3>
    <h4>You can either upload the theme via FTP (File Transfer Protocol) or via Osclass admin panel:</h4>
    <h3>1. Upload theme via FTP:</h3>
    <ol>
      <li>Unzip the downloaded theme folder.</li>
      <li>
        <p>Using the FTP client, copy the plugins and themes folders to the Osclass software's root directory. If you are working with a Mac, please make sure you are merging the new folders with Osclass and not replacing the Osclass directory.</p>
      </li>
      <li>
        Make sure all the files are successfully transferred to the root directory.
      </li>
    </ol>
    <h3>2. To upload Osclass theme via Osclass admin panel:</h3>
    <ol>
      <li>
        <p><strong>Go to Appearance &gt; Manage Themes: and click on add new button</strong></p>
      </li>
      <li>
        <p>A window will appear like shown in the image below and unzip the <strong>letgo.zip </strong> and upload the <strong>letgo</strong> theme file inside the <strong>letgo.zip</strong> unzipped folder.</p>
      </li>
    </ol>
    <h3>2.1 To activate the theme:</h3>
    <ol>
      <li>
        <p><strong>Navigate to Appearance &gt; Manage Themes and click Activate button to activate the theme.</strong></p>
      </li>
    </ol>
    
    <h2>3. Logo</h2>
    <article id="lfv">
  <p class="alert"><span><strong>Go to Appearance &gt; LetGo Options</strong>  from tabs choose <strong>Header Logo</strong>, choose your logo and upload it. Recommended logo size is 215px X 50px, is recommended to be .jpg, .png format with transparent background. To change favicon, please choose <strong>Favicon tab</strong> and upload your favicon. Recommended favicon size is: 16px X 16px. Accepted format is: .ico, .jpg, .png, .gif.</p>
  </article>
    
    
    <h3 id="plugins">3.1 How to add Plugins in Osclass:</h3>
     <p><span><strong>Warning</strong> - The theme should be working with all major of plugins from osclass market. So, to install manually the plugins you need to unzip the archive and upload plugins in osclass plugins directory (http://www.yourwebsite.com/oc-content/plugins/). You only need to Upload the theme, activate it, upload the plugins in plugins directory and enable them through admin control panel, then you can configure all the settings.</span></p>
    <ol>
      <li>
        <p><strong>To install automatically plugins: Go to Plugins &gt; Manage Plugins</strong> and click in the <strong>+</strong> icon to add new plugins.</p>
        <p><img src="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/new_plugin.jpg" alt="new_plugin"></p>
      </li>
      <li>
        <h3>Add New Plugin:</h3>
        <p class="alert"><span>There are lots of free and premium plugins available in the osclass theme market.</span></p>
        <p><img src="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/market.jpg" alt="market"></p>
      </li>
      <li>
        <p><strong>Download the plugins from the <a target="_blank" href="http://market.osclass.org/plugins">Osclass Plugin Market</a></strong> and upload the plugins via Add plugin section and enable/disable it as shown in the pic. </p>
        <p><img src="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/upload_plugin.jpg" alt="upload_plugin"></p>
      </li>
    </ol>
    <h3 id="banner">4. How to change icons for categories:</h3>
    <ol>
      <li>
        <p><strong>Go to Appearance &gt; LetGo Options, From tabs choose &gt; Category Icons</strong>, here you can use icons from: https://fontawesome.com/v4.7.0/icons/. In order to get your desired icon, just type icon name, for example: SHOPPING-CART or BULLHORN.
</p>
      </li>
    </ol>
    <h3 id="lsh">5. Listings on HomePage by custom category:</h3>
    <ol>
      <li>
        <p><strong>Go to Appearance &gt; LetGo Options</strong> then choose from tabs: <strong>"Items by custom category"</strong></p>
        <p><span>In this section you can configure to display listings on homepage by custom category name.
Please note that <strong>category name</strong> need to be in <strong>english</strong> and is required to be a <strong>slug</strong> format, for example, in box: <strong>"Category 1"</strong> you need to write your desired category name, for example: <strong>"for-sale"</strong>, in a second box for: <strong>"name to show"</strong> you can write simply: <strong>"For sale"</strong>, or translated in your language.</span></p>
      </li>
    </ol>
    </article>
  <em><em>
  <article id="credits">
    <h3>Credits:</h3>
    <ol>
      <li><a target="_blank" href="http://osclass.org/page/download">Osclass open source classifieds (v3.7.1)</a></li>
      <li><a target="_blank" href="http://getbootstrap.com/">Bootstrap Framework (v4.0.0)</a></li>
      <li><a href="http://fortawesome.github.io/Font-Awesome/" target="_blank">Font Awesome (The iconic font)</a></li>
      <li><a href="https://jquery.com/" target="_blank">jQuery</a></li>
    </ol>
    <br>
  </article>
</em></em></section><em><em>
<script type="text/javascript" src="<?php echo osc_base_url();?>oc-content/themes/letgo/docs/index_files/jquery1.js" type="text/javascript"></script>

</em></em></body></html>