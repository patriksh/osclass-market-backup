<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    if( osc_item_is_spam() || osc_premium_is_spam() ) {
        osc_add_hook('header','letgo_nofollow_construct');
    } else {
        osc_add_hook('header','letgo_follow_construct');
    }

    letgo_add_body_class('page sub-page');
		
	if(letgo_show_as() == 'gallery1'){
        $loop_template	=	'loop-search-grid.php';
		$buttonClass = 'active';
    }else{
		$loop_template	=	'loop-search-list2.php';
		$buttonClass = '';
	}
	
    function sidebar(){
        osc_current_web_theme_path('item-sidebar.php');
    }

    $location = array();
    if( osc_item_city_area() !== '' ) {
        $location[] = osc_item_city_area();
    }
    if( osc_item_city() !== '' ) {
        $location[] = osc_item_city();
    }
    if( osc_item_region() !== '' ) {
        $location[] = osc_item_region();
    }
    if( osc_item_country() !== '' ) {
        $location[] = osc_item_country();
    }
	
    osc_current_web_theme_path('header3.php');
	
?>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php echo osc_item_title(); ?>
                                <span class="tag"><i class="fa fa-eye"></i> <?php if ( osc_item_views() > 0 ) { ?>
                                    <?php echo osc_item_views(); ?>
                                    <?php } else { ?>
                                    0
                                    <?php } ?></span>
                            </h1>
                            <h4 class="location">
                                <?php if ( osc_item_country() != "" ) { ?>
	<i class="fa fa-map-marker"></i> <a href="<?php echo osc_country_url(); ?>"><?php echo osc_item_country(); ?></a>, <?php } ?> <?php if ( osc_item_region() != "" ) { ?> <a href="<?php echo osc_region_url(); ?>"><?php echo osc_item_region(); ?></a><?php } ?>
                            </h4>
                        </div>
                        <div class="float-right float-xs-none price">
                            <div class="number"><?php if( osc_price_enabled_at_items() ) { ?>
          <?php echo osc_item_formated_price(); ?>
          <?php } ?></div>
                            <div class="id opacity-50">
                           <i class="fa fa-calendar"></i> <?php if ( osc_item_pub_date() != '' ) echo __('', '') . ' ' . osc_format_date( osc_item_pub_date() ); ?>
                            </div>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
<section class="content">
            <section class="block">
                <div class="container">
                    <!--Gallery Carousel-->
                    <div class="row ">
                        <!--============ Listing Detail =============================================================-->
                        <div class="col-md-8">
                        <!-- LETGO IMAGES -->
                        <?php if( osc_images_enabled_at_items() ) { ?>
                        <section>
                        <div class="gallery-carousel owl-carousel">
<?php
        if( osc_count_item_resources() > 0 ) {
            $i = 0;
        ?>                        
                            <?php for ( $i = 0; osc_has_item_resources(); $i++ ) { ?>
                            <img src="<?php echo osc_resource_url(); ?>" title="<?php echo osc_esc_html(__('Image', 'letgo')); ?> <?php echo $i+1;?> / <?php echo osc_count_item_resources();?>" data-hash="<?php echo osc_resource_id(); ?>">
                            <?php } ?>
                                <?php } else { ?>
                                <div class="box" align="center"><span class="fa-stack fa-3x">
  <i class="fa fa-camera fa-stack-5x"></i>
  <i class="fa fa-ban fa-stack-2x text-danger" style="color:red;"></i>
</span></div> <?php } ?> 
                        </div>
                        <?php View::newInstance()->_erase('resources'); ?>
                        <div class="gallery-carousel-thumbs owl-carousel">
<?php
        if( osc_count_item_resources() > 1 ) {
            $i = 1;
        ?> <?php for ( $i = 0; osc_has_item_resources(); $i++ ) { ?>
                            <a href="#<?php echo osc_resource_id(); ?>" class="owl-thumb background-image">
                                <img src="<?php echo osc_resource_url(); ?>" title="<?php echo osc_esc_html(__('Image', 'letgo')); ?> <?php echo $i+1;?> / <?php echo osc_count_item_resources();?>" alt="">
                            </a>
                            <?php } ?>
                            <?php } ?>
                        </div>
                         <?php if( osc_get_preference('header-728x90', 'letgo') != ""){ ?>
                        <br />
    <div align="center"> <?php echo osc_get_preference('header-728x90', 'letgo'); ?></div>
                         <?php } ?>
                    </section>
                         <?php } ?>
                        <!-- END LETGO IMAGES -->
                            <!--Description-->
                            <section class="box">
                                <h3><?php _e("Description", 'letgo'); ?></h3>
                                <p>
                                    <?php echo osc_item_description(); ?>
                                </p>
                                <div id="custom_fields">
          <?php if( osc_count_item_meta() >= 1 ) { ?>
          <div class="meta_list">
            <?php while ( osc_has_item_meta() ) { ?>
            <?php if(osc_item_meta_value()!='') { ?>
            <div class="meta"> <strong><?php echo osc_item_meta_name(); ?>:</strong> <?php echo osc_item_meta_value(); ?> </div>
            <?php } ?>
            <?php } ?>
          </div>
          <?php } ?>
        </div>
        <?php osc_run_hook('item_detail', osc_item() ); ?>
        <?php
		if(function_exists('show_qrcode')){
			echo '<div class="" align="left">';
			show_qrcode();
			echo ' </div>';

		}
	?>
                            </section>
                            <!--end Description-->
                            <!--Details-->
                            <section class="box">
                                <dl class="columns-2">
                                    <dt><?php _e("Price", 'letgo'); ?></dt>
                                    <dd><?php if( osc_price_enabled_at_items() ) { ?>
          <?php echo osc_item_formated_price(); ?>
          <?php } ?></dd>
          <dt><?php _e("Published", 'letgo'); ?></dt>
                                    <dd><?php if ( osc_item_pub_date() != '' ) echo __('', '') . ' ' . osc_format_date( osc_item_pub_date() ); ?></dd>
                                   <?php if ( osc_item_country() != "" ) { ?> <dt><?php _e("Location", 'letgo'); ?></dt>
                                    <dd><?php echo osc_item_country(); ?>, <?php } ?> <?php if ( osc_item_region() != "" ) { ?> <?php echo osc_item_region(); ?></dd>  <?php } ?>
                                    <?php if ( osc_item_country() == null ) { ?> <dt><?php _e("Location", 'letgo'); ?></dt>
                                    <dd><i class="fa fa-minus" aria-hidden="true"></i></dd>  <?php } ?>
                                    <dt><?php _e("Category", 'letgo'); ?></dt>
                                    <dd><?php echo osc_item_category(); ?></dd>
                                    <?php if ( osc_item_views() > 0 ) { ?>
                                    <dt><?php _e("Views", 'letgo'); ?></dt>
                                    <dd><?php echo osc_item_views(); ?></dd>
                                    <?php } else { ?>
                                    <dt><?php _e("Views", 'letgo'); ?></dt>
                                    <dd>0</dd>
                                    <?php } ?>
                                    <dt>ID</dt>
                                    <dd><?php echo osc_item_id(); ?></dd>
                                </dl>
                                &nbsp;
                                
                                <div class="form-row">
                                <div class="col">
                                <div class="social"><a class="btn btn-success btn-framed width-100" href="<?php echo osc_item_send_friend_url(); ?>" rel="nofollow"><i class="fa fa-share-square-o" aria-hidden="true"></i> <?php _e('Send to a friend', 'letgo'); ?></a>
                                
                </div>
                                </div>
                                <div class="col">
      <form action="<?php echo osc_base_url(true); ?>" method="post" name="mask_as_form" id="mask_as_form">
        <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
        <input type="hidden" name="as" value="spam" />
        <input type="hidden" name="action" value="mark" />
        <input type="hidden" name="page" value="item" />
        <select name="as" id="as" class="mark_as">
          <option>
          <?php _e("Mark as...", 'letgo'); ?>
          </option>
          <option value="spam">
          <?php _e("Mark as spam", 'letgo'); ?>
          </option>
          <option value="badcat">
          <?php _e("Mark as misclassified", 'letgo'); ?>
          </option>
          <option value="repeated">
          <?php _e("Mark as duplicated", 'letgo'); ?>
          </option>
          <option value="expired">
          <?php _e("Mark as expired", 'letgo'); ?>
          </option>
          <option value="offensive">
          <?php _e("Mark as offensive", 'letgo'); ?>
          </option>
        </select>
      </form>
    </div>
     </div>                       </section>
                            <!--end Details-->
                            <!--Location-->
                            <?php if(function_exists('google_maps_location')) { ?>
                            <section>
                                <h2><?php _e('Location', 'letgo'); ?></h2>
                                <div class="map" id="map-small"><?php osc_run_hook('location'); ?></div>
                            </section>
                            <?php } ?>
                            <!--end Location-->
                            <!--Features-->
                            <section>
                                <h2><?php _e('Useful information', 'letgo'); ?></h2>
                                <ul class="features-checkboxes columns-1">
                                    <li>
            <?php _e('Avoid scams by acting locally or paying with PayPal', 'letgo'); ?>
          </li>
          <li>
            <?php _e('Never pay with Western Union, Moneygram or other anonymous payment services', 'letgo'); ?>
          </li>
          <li>
            <?php _e('Don\'t buy or sell outside of your country. Don\'t accept cashier cheques from outside your country', 'letgo'); ?>
          </li>
          <li>
            <?php _e('This site is never involved in any transaction, and does not handle payments, shipping, guarantee transactions, provide escrow services, or offer "buyer protection" or "seller certification"', 'letgo'); ?>
          </li>
                                </ul>
                                
                            </section>
                            <!--end Features-->
                            <hr>
                            <!--Similar Ads-->
                            <section>
                                <?php osc_current_web_theme_path('common/random-items.php') ; ?>
                                <br />
                            </section>
                            <!--end Similar Ads-->
                        </div>
                        <!--============ End Listing Detail =========================================================-->
                        <!--============ Sidebar ====================================================================-->
                        <div class="col-md-4">
                            <aside class="sidebar">
                                <!--Author-->
<?php osc_current_web_theme_path('item-sidebar.php') ; ?>
                                <!--End Author-->
                                <?php related_listings(); ?>
<?php if( osc_count_items() > 0 ) { ?>
                                <div class="read-more" data-read-more-link-more="<i class='fa fa-chevron-down'></i>" data-read-more-link-less="<i class='fa fa-chevron-up'></i>">

  <h3 class="title" align="center">
    <i class="fa fa-link"></i> <?php _e('Related listings', 'letgo'); ?>
  </h3>
  <?php
		View::newInstance()->_exportVariableToView("listType", 'items');
		osc_current_web_theme_path($loop_template);
    ?>
</div>
<?php } ?>
                            </aside>
                        </div>
                        <!--============ End Sidebar ================================================================-->
                    </div>
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
<!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
    
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>