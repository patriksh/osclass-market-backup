<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_follow_construct');

    letgo_add_body_class('home-page');

	if(letgo_show_as() == 'gallery'){
        $loop_template	=	'loop-grid.php';
		$listClass = 'listing-grid';
    }else{
		$loop_template	=	'loop-list.php';
		$listClass   = '';
	}
	
?>
<?php osc_current_web_theme_path('header.php') ; ?>
<!-- LETGO CONTENT -->
<section class="content">
            <!--============ Categories =============================================================================-->
            <section class="block">
            
                <?php osc_run_hook('inside-main'); ?>
                                    
                    <!--end categories-list-->
                <!--end container-->
            </section>
            
            <!--end block-->
            <!--============ End Categories =========================================================================-->
            <!--============ Featured Ads ===========================================================================-->
            
            <section class="block">
                <div class="container">
                    <!--============ Section Title===================================================================-->
                    <div class="section-title clearfix">
                        <div class="float-xl-none float-md-none float-sm-none">
                            <h2 align="center"><?php _e('Latest Listings', 'letgo') ; ?></h2>
                        </div>
                       
                    </div>
                                        

                    <!--============ Items ==========================================================================-->
                    <div class="items compact grid grid-xl-4-items grid-lg-3-items grid-md-2-items">
                    <?php if( osc_count_latest_items() == 0) { ?>
    <p class="" align="center">
      <?php _e("There aren't listings available at this moment", 'letgo'); ?>
    </p>
    <?php } else { ?>
    <?php
    View::newInstance()->_exportVariableToView("listType", 'latestItems');
    View::newInstance()->_exportVariableToView("listClass",$listClass);
	osc_current_web_theme_path($loop_template);
    ?>
                    </div>
                    <!--============ End Items ======================================================================-->
<?php if( osc_count_latest_items() == osc_max_latest_items() ) { ?>
                    <div class="center">
                        <a href="<?php echo osc_search_show_all_url() ; ?>" class="btn btn-primary btn-framed btn-rounded"><?php _e('See all listings', 'letgo') ; ?></a>                    </div>
                        <?php } ?>
    <?php } ?>
                        
                </div>
                <!--end container-->
                                <div class="background" data-background-color="#fff"></div>
            </section>
            <!--end block-->
            <?php
    osc_get_premiums(letgo_premium_listings_shown_home());
    if(osc_count_premiums() > 0) {
?>
<!-- LETGO -->
<section class="block">
                <div class="container">
                    <!--============ Section Title===================================================================-->
                    <div class="section-title clearfix">
                        <div class="float-xl-none float-md-none float-sm-none">
                            <h2 align="center"><?php _e('Premium listings', 'letgo') ; ?></h2>
                        </div>
                    </div>
                    <!--============ Items ==========================================================================-->
                    <div class="items grid compact grid-xl-3-items grid-lg-3-items grid-md-2-items">
                    <?php
  $listcount = 1;
		while ( osc_has_premiums() ) {
	?>
  <div class="item">
                            <div class="ribbon-featured"><?php _e('Premium', 'letgo') ; ?></div>
                            <div class="wrapper">
                                <div class="image">
                                <h3>
                                        <a href="#" class="tag category"><?php echo osc_premium_category() ; ?></a>
                                        <a href="<?php echo osc_premium_url() ; ?>" class="title"><?php echo osc_highlight( osc_premium_title() ,70) ; ?></a>
                                        <span class="tag"><?php echo osc_count_premium_resources();?> <i class="fa fa-camera" aria-hidden="true"></i></span>                                    </h3>
            <?php if( osc_images_enabled_at_items() ) { ?>
            <?php if(osc_count_premium_resources()) { ?>
            <a href="<?php echo osc_premium_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_resource_url(); ?>" alt="<?php echo osc_esc_html(osc_premium_title()) ; ?>" >                                    </a>            
            <?php } else { ?>
            <a href="<?php echo osc_premium_url() ; ?>" class="image-wrapper background-image">
                                        <img src="<?php echo osc_current_web_theme_url('images/no_photo.gif'); ?>" alt="<?php echo osc_esc_html(osc_premium_title()) ; ?>" >                                    </a>
            <?php } ?>
            <?php } ?>
          </div>
          <!--end image-->
                                <div class="price ellipsis" style="max-width: 220px;"><?php if( osc_price_enabled_at_items() && osc_item_category_price_enabled(osc_premium_category_id()) ) { echo osc_premium_formated_price(); ?><?php } ?></div>
                                <div class="meta">
                                    <figure>
                                    <i class="fa fa-calendar"></i><?php echo osc_format_date(osc_premium_pub_date()); ?></figure>
                                    <figure>
                                        <a href="#">
                                            <i class="fa fa-user"></i><?php echo osc_premium_contact_name(); ?>                                        </a>                                    </figure>
                                </div>
                                <!--end meta-->
                                <div class="description">
                                    <p><?php echo osc_highlight( osc_premium_description() ,250) ; ?></p>
                                </div>
                        </div>
                        </div>
                        <!--end item-->
  <?php	
    } 
?>
                    </div>
                    <!--============ End Items ======================================================================-->  
                </div>
                <!--end container-->
            </section>
<!-- LETGO -->
<?php
	}
 ?>
 <!--============ Features Steps =========================================================================-->
            <section class="block">
                <div class="container">
                    <div class="block">
                        <?php if (osc_get_preference('homepage-block1', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo ' <h2 align="center">Selling with us is easy!</h2> '; } ?>
                   <?php if( osc_get_preference('homepage-block1', 'letgo') != '') {?>
                   <h2 align="center"><?php echo osc_esc_html(osc_get_preference('homepage-block1', 'letgo')); ?></h2>
    <?php } ?>
                        <div class="row">
                            <div class="col-md-3" align="center">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo osc_current_web_theme_url('images/user1.png'); ?>" >
                                        <span>1</span>
                                    </figure>
                                    
                                    <?php if (osc_get_preference('homepage-block2', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo ' <h3 align="center"><a href="'. osc_register_account_url() .'">'.__('Create', 'letgo').'</a></h3> '; } ?>
                   <?php if( osc_get_preference('homepage-block2', 'letgo') != '') {?>
                   <h3 align="center"><a href="<?php echo osc_esc_html(osc_get_preference('homepage-block1l', 'letgo')); ?>"><?php echo osc_esc_html(osc_get_preference('homepage-block2', 'letgo')); ?></a></h3>
    <?php } ?>
                                                                        
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3" align="center">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo osc_current_web_theme_url('images/step2.png'); ?>" >
                                        <span>2</span>
                                    </figure>
                                    
                                    <?php if (osc_get_preference('homepage-block3', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo '<h3><a href="'. osc_item_post_url().'">'. __('Publish', 'letgo').'</a></h3>'; } ?>
                <?php if( osc_get_preference('homepage-block3', 'letgo') != '') {?>
                <h3 align="center"><a href="<?php echo osc_esc_html(osc_get_preference('homepage-block2l', 'letgo')); ?>"><?php echo osc_esc_html(osc_get_preference('homepage-block3', 'letgo')); ?></a></h3>
                
                <?php } ?>
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3" align="center">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo osc_current_web_theme_url('images/step3.png'); ?>" >
                                        <span>3</span>
                                    </figure>
                                    
                                    <?php if (osc_get_preference('homepage-block4', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo '<h3>'. __('Share', 'letgo').'</h3>'; } ?>
                <?php if( osc_get_preference('homepage-block4', 'letgo') != '') {?>
                <h3 align="center"><a href="<?php echo osc_esc_html(osc_get_preference('homepage-block3l', 'letgo')); ?>"><?php echo osc_esc_html(osc_get_preference('homepage-block4', 'letgo')); ?></a></h3>
                
                <?php } ?>
                                    
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                            <div class="col-md-3" align="center">
                                <div class="feature-box">
                                    <figure>
                                        <img src="<?php echo osc_current_web_theme_url('images/step4.png'); ?>" >
                                        <span>4</span>
                                    </figure>
                                    
                                    <?php if (osc_get_preference('homepage-block5', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo '<h3>Enjoy the money!</h3>'; } ?>
                <?php if( osc_get_preference('homepage-block5', 'letgo') != '') {?>
                <h3 align="center"><a href="<?php echo osc_esc_html(osc_get_preference('homepage-block6', 'letgo')); ?>"><?php echo osc_esc_html(osc_get_preference('homepage-block5', 'letgo')); ?></a></h3>
                
                <?php } ?>
                                                                        
                                </div>
                                <!--end feature-box-->
                            </div>
                            <!--end col-->
                        </div>
                        <!--end row-->
                    </div>
                    <!--end block-->
                </div>
                <!--end container-->
                <div class="background" data-background-color="#fff"></div>
                <!--end background-->
            </section>
            <!--end block-->
            <!--============ End Features Steps =====================================================================-->
            <section class="block">
                <div class="container">
            <section>
                        <div class="row">
                            <div class="col-md-12">
                                <h2 align="center"><?php _e('Listings', 'letgo') ; ?></h2>
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="one-tab" data-toggle="tab" href="#one" role="tab" aria-controls="one" aria-expanded="true"><?php if (osc_get_preference('slidercatname1m', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo "N/A"; } ?>
      
      <?php if( osc_get_preference('slidercatname1m', 'letgo') != '') {?>
        <?php echo osc_esc_html(osc_get_preference('slidercatname1m', 'letgo')); ?>
        <?php } ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="two-tab" data-toggle="tab" href="#two" role="tab" aria-controls="two"><?php if (osc_get_preference('slidercatname2m', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo "N/A"; } ?>
      
      <?php if( osc_get_preference('slidercatname2m', 'letgo') != '') {?>
        <?php echo osc_esc_html(osc_get_preference('slidercatname2m', 'letgo')); ?>
        <?php } ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="three-tab" data-toggle="tab" href="#three" role="tab" aria-controls="three"><?php if (osc_get_preference('slidercatname3m', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo "N/A"; } ?>
      
      <?php if( osc_get_preference('slidercatname3m', 'letgo') != '') {?>
        <?php echo osc_esc_html(osc_get_preference('slidercatname3m', 'letgo')); ?>
        <?php } ?></a>
                                    </li>
                                </ul>
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="one" role="tabpanel" aria-labelledby="one-tab">
<?php osc_current_web_theme_path('common/custom-ads1.php') ; ?>                                    </div>
                                    <div class="tab-pane fade" id="two" role="tabpanel" aria-labelledby="two-tab">
<?php osc_current_web_theme_path('common/custom-ads2.php') ; ?>                                    </div>
                                    <div class="tab-pane fade" id="three" role="tabpanel" aria-labelledby="three-tab">
<?php osc_current_web_theme_path('common/custom-ads3.php') ; ?>                                    </div>
                                </div>
                                <?php if( osc_get_preference('homepage-728x90', 'letgo') != ""){ ?>
    <div class="box" align="center"> <?php echo osc_get_preference('homepage-728x90', 'letgo'); ?></div>
    <?php } ?>
                            </div>
                            <!--end col-md-12-->
                        </div>
                        <!--end row-->
                    </section>
                    </div>
                    </section>
        </section>
<!-- LETGO CONTENT -->
<?php

	$total_categories   = osc_count_categories();
	$col1_max_cat       = ceil($total_categories/1);
	osc_goto_first_category();
	$catcount	=	0;
	while ( osc_has_categories() ) {
?>
            <!-- LETGO CATEGORY MODAL -->
<div class="modal fade" id="<?php echo osc_esc_html(osc_category_id()) ; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabelhelp">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <a class="btn btn-success small width-100" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name() ; ?></a>
      </div>
      <div class="modal-body">
      <?php while( osc_has_subcategories() > 0 ) { ?>  <a href="<?php echo osc_search_category_url() ; ?>" class="btn btn-light btn-framed small width-100"><?php echo osc_category_name() ; ?></a> <?php } ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info small width-100" data-dismiss="modal"><?php _e('Close', 'letgo'); ?></button>
      </div>
    </div>
  </div>
</div>
<!-- END LETGO CATEGORY MODAL -->
<?php } ?>
<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<?php osc_current_web_theme_path('footer.php') ; ?>