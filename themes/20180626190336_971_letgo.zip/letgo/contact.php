<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');

    letgo_add_body_class('page sub-page');
	
    osc_enqueue_script('jquery-validate');
    osc_current_web_theme_path('header3.php');
?>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php _e('Contact us', 'letgo'); ?>
                            </h1>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
        <!--************ CONTENT ************************************************************************************-->
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <h2><?php _e('Description', 'letgo'); ?></h2>
                            <p>
                                <?php if( osc_get_preference('contact-text', 'letgo') != '') {?> <?php echo osc_esc_html( osc_get_preference('contact-text', 'letgo') ); ?> <?php } else { ?> <?php echo osc_page_title(); ?> <?php } ?>
                            </p>
                            
                            <br>
                            <figure class="with-icon">
                            <i class="fa fa-phone"></i><?php if( osc_get_preference('youtube-top', 'letgo') != '') {?> <span><?php echo osc_esc_html( osc_get_preference('youtube-top', 'letgo') ); ?></span> <?php } else { ?> <span>-</span> <?php } ?>
                                
                            </figure>
                            <figure class="with-icon">
                                <?php if( osc_get_preference('email-top', 'letgo') != '') {?> <i class="fa fa-envelope" aria-hidden="true"></i> <a target='_blank' href="mailto:<?php echo osc_esc_html(osc_get_preference('email-top', 'letgo')); ?>"> <?php echo osc_esc_html(osc_get_preference('email-top', 'letgo')); ?></a> &nbsp; <?php } else { ?> <i class="fa fa-envelope" aria-hidden="true"></i> - <?php } ?>
                            </figure>
                            <figure class="with-icon">
                                <i class="fa fa-clock-o"></i> <?php if( osc_get_preference('skype-top', 'letgo') != '') {?> <?php echo osc_esc_html( osc_get_preference('skype-top', 'letgo') ); ?> <?php } else { ?> - <?php } ?>
                            </figure>
                            
                            <figure><?php if( osc_get_preference('facebook-top', 'letgo') != '') {?><a target='_blank' href="<?php echo osc_esc_html(osc_get_preference('facebook-top', 'letgo')); ?>"><i class="fa fa-facebook fa-3x" style="color:#0099CC"></i></a>
                    <?php } else { ?><i class="fa fa-facebook fa-3x" style="color:#0099CC"></i><?php } ?> &nbsp;&nbsp;
                
                <?php if( osc_get_preference('twitter-top', 'letgo') != '') {?><a target='_blank' href="<?php echo osc_esc_html(osc_get_preference('twitter-top', 'letgo')); ?>"> <i class="fa fa-twitter fa-3x" style="color:#00CCFF"></i></a> <?php } else { ?> <i class="fa fa-twitter fa-3x" style="color:#00CCFF"></i> <?php } ?>
                &nbsp;&nbsp;
				  		
					    <?php if( osc_get_preference('google-plus-top', 'letgo') != '') {?><a target='_blank' href="<?php echo osc_esc_html(osc_get_preference('google-plus-top', 'letgo')); ?>"><i class="fa fa-google-plus fa-3x" style="color:#FF0000"></i></a> &nbsp; <?php } else { ?> <i class="fa fa-google-plus fa-3x" style="color:#FF0000"></i> <?php } ?></figure>
                        </div>
                        <!--end col-md-4-->
                        <div class="col-md-8">
                            <h2><?php _e('Send', 'letgo'); ?> <?php _e('E-mail', 'letgo'); ?></h2>
                            <ul id="error_list">
        </ul>
        <form name="contact_form" action="<?php echo osc_base_url(true); ?>" method="post" class="form email">
          <input type="hidden" name="page" value="contact" />
          <input type="hidden" name="action" value="contact_post" />
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
<label for="name" class="col-form-label"><?php _e('Your name', 'letgo'); ?> (<?php _e('optional', 'letgo'); ?>)</label>
              <?php ContactForm::your_name(); ?>
                                        </div>
                                        <!--end form-group-->
                                    </div>
                                    <!--end col-md-6-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                    <label for="email" class="col-form-label required"><?php _e('Your email address', 'letgo'); ?></label>
              <?php ContactForm::your_email(); ?>
                                        </div>
                                        <!--end form-group-->
                                    </div>
                                    <!--end col-md-6-->
                                </div>
                                <!--end row-->
                                <div class="form-group">
                                    <label for="subject" class="col-form-label"><?php _e('Subject', 'letgo'); ?> (<?php _e('optional', 'letgo'); ?>)</label>
              <?php ContactForm::the_subject(); ?>
                                </div>
                                <!--end form-group-->
                                <div class="form-group">
                                    <label for="message" class="col-form-label required"><?php _e('Message', 'letgo'); ?></label>
                                    <div class="textareauser">
<?php ContactForm::your_message(); ?>              </div>                  </div>
                                <!--end form-group-->
		  <div class="form-group">
            <div class="recap" align="left">
			<?php osc_show_recaptcha(); ?>
			</div>
		 </div>
           <div class="form-group">
              <?php osc_run_hook('contact_form'); ?>
              <?php osc_run_hook('admin_contact_form'); ?>
          </div>
          <div class="form-row">
                                <div class="col"><button type="submit" class="btn btn-success width-100"><?php _e("Send", 'letgo');?> <i class="fa fa-paper-plane"></i></button></div> <div class="col"><button type="reset" class="btn btn-light btn-framed width-100"><?php _e("Cancel", 'letgo');?> <i class="fa fa-undo"></i></button></div></div>
                                              <?php osc_run_hook('admin_contact_form'); ?>
                            </form>
                                    <?php ContactForm::js_validation(); ?>
                            <!--end form-->
                        </div>
                        <!--end col-md-8 -->
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>