<?php
    /*
     *      Osclass вЂ“ software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');

    osc_enqueue_script('jquery-validate');
    letgo_add_body_class('page sub-page');
    $action = 'item_add_post';
    $edit = false;
    if(Params::getParam('action') == 'item_edit'){
        $action = 'item_edit_post';
        $edit = true;
    }
	
    ?>
<?php osc_current_web_theme_path('header5.php') ; ?>
<?php 
	echo '<script>item_edit = '.(($edit)? "1":"0");
	echo "\n";
	if($edit){
		echo 'item_id = '.osc_item_id();
	}
	echo '</script>';

	if(letgo_locations_input_as() =='select'){ 
		ItemForm::location_javascript();
	}else{
		ItemForm::location_javascript_new();
	}
?>
<style type="text/css">
/* body select.select_box */ 
body select { 
    display: block;
    padding: 1.5rem !important; 
    max-width: 100%; 
    border: 1px solid #e3e3e3; 
    border-radius: 3px; 
    background: url("<?php echo osc_current_web_theme_url('images/selectbox_arrow.png') ; ?>") right center no-repeat; 
    background-color: #fff; 
    color: #444444; 
    appearance: none; 
    /* this is must */ -webkit-appearance: none; 
    -moz-appearance: none; 
} 
/* body select.select_box option */ 
body select option { 

} 
/* for IE and Edge */ 
select::-ms-expand { 
    display: none; 
} 
select:disabled::-ms-expand { 
    background: #f60; 
}
</style>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php if($edit) { _e("Edit your listing", 'letgo'); } else { _e("Publish a listing", 'letgo'); } ?></h1>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
        <section class="content">
            <section class="block">
                <div class="container">
<form class="form form-submit" name="item" action="<?php echo osc_base_url(true);?>" method="post" enctype="multipart/form-data" id="item-post">
<input type="hidden" name="action" value="<?php echo $action; ?>" />
          <input type="hidden" name="page" value="item" />
          <?php if($edit){ ?>
          <input type="hidden" name="id" value="<?php echo osc_item_id();?>" />
          <input type="hidden" name="secret" value="<?php echo osc_item_secret();?>" />
          <?php } ?>
          <section>
                            <h2><?php _e('General Information', 'letgo'); ?></h2>
                            <div class="form-group">
                                <label for="type" class="required"><?php _e('Category', 'letgo'); ?></label>
                                <figure>
                                    <?php  if ( osc_count_categories() ) { ?>
			<?php if(osc_get_preference('category_multiple_selects', 'letgo') == '1'){ ?>
			  <div class="cat_multiselect"><?php ItemForm::category_multiple_selects(null, null, null, __('Select a category', 'letgo')); ?></div>
			<?php }else{ ?>
              <?php ItemForm::category_select(null, null, __('Select a category', 'letgo')); ?>
			<?php } ?>
              <?php  } ?>
                                </figure>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label for="title" class="col-form-label required"><?php _e('Title', 'letgo'); ?></label>
                                         <?php ItemForm::title_input('title',osc_current_user_locale(), osc_esc_html( letgo_item_title() )); ?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-8-->
                                <?php if( osc_price_enabled_at_items() ) { ?>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="price" class="col-form-label required"><?php _e('Price', 'letgo'); ?></label>
                                       <div class="form-row">
                                       <div class="col">
        
          <?php ItemForm::currency_select(); ?>
        </div>
        <div class="col">
      <?php ItemForm::price_input_text(); ?>
    </div>
    </div>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <?php } ?>
                            </div>
                            <div class="row">
                                
<div class="col-md-12">                                <div class="form-group">
                                            
                                                <label for="computers___other_details" class="col-form-label"><?php _e('Description', 'letgo'); ?></label>
                                                             <div class="textareauser"><?php ItemForm::description_textarea('description',osc_current_user_locale(), osc_esc_html( letgo_item_description() )); ?></div>

                                            </div>  </div>
                            </div>
                        </section>
                        <!--end basic information-->
                        <section>
                            <h2><?php _e('Listing Location', 'letgo'); ?></h2>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="city" class="col-form-label"><?php _e('Country', 'letgo'); ?></label>
                                        <?php ItemForm::country_select(osc_get_countries(), osc_user()); ?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-6-->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="street" class="col-form-label"><?php _e('Region', 'letgo'); ?></label>
                                        <?php 
				if(letgo_locations_input_as() =='select'){ 
					ItemForm::region_select(osc_get_regions(),osc_user());
				}else{
					ItemForm::region_text(osc_user());
				}
			?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <!--end col-md-6-->
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="street" class="col-form-label"><?php _e('City', 'letgo'); ?></label>
                                        <?php 
				if(letgo_locations_input_as() =='select'){ 
					ItemForm::city_select(osc_get_cities(),osc_user());
				}else{
					ItemForm::city_text(osc_user());
				}
			?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                
                                </div>
                            <!--end row-->
                            <!--end form-group-->
                        </section>
                        <section>
                        <div class="row">
                        <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="street" class="col-form-label"><?php _e('City Area', 'letgo'); ?></label>
                                        <?php ItemForm::city_area_text(osc_user()); ?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="street" class="col-form-label"><?php _e('Address', 'letgo'); ?></label>
                                        <?php ItemForm::address_text(osc_user()); ?>
                                    </div>
                                    <!--end form-group-->
                                </div>
                                </div>
                                </section>
                        <?php if(!osc_is_web_user_logged_in() ) { ?>
                        <!-- SELLER INFO LETGO -->
                        <section>
                            <h2><?php _e("Seller's information", 'letgo'); ?></h2>
                            <div class="row">
                            <div class="col-md-4">
                            <div class="form-group">
                                <label for="input-location" class="col-form-label"><?php _e('Name', 'letgo'); ?></label>
                                <?php ItemForm::contact_name_text(); ?>
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="form-group">
                                <label for="input-location" class="col-form-label"><?php _e('E-mail', 'letgo'); ?></label>
                                <?php ItemForm::contact_email_text(); ?>
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="form-group">
                                <label for="input-location" class="col-form-label"><?php ItemForm::show_email_checkbox(); ?></label> 
                                <?php _e('Show e-mail on the listing page', 'letgo'); ?> 
                            </div>
                            </div>
                            </div>
                            </section>
                            <!-- END SELLER INFO LETGO -->
                            <?php } ?>
                        <?php if( osc_images_enabled_at_items() ) { ?>
                        <section>
                                                  
                            <h2><?php _e('Photos') ; ?></h2>
                            <div class=""></div>
                            <div class="">
<?php 
                            ItemForm::ajax_photos();
                          ?>                            </div>
                        </section>
                        <?php } ?>
                        <section>
                        <div class="col-md-6 box">
                        <div class="form-group">
                        <?php		
                        if($edit) {
                            ItemForm::plugin_edit_item();
                        } else {
                            ItemForm::plugin_post_item();
                        }
                        ?>
                        </div>
                        <div class="form-group">
            <div class="" align="center">
              <?php osc_show_recaptcha(); ?>
            </div>
                        </div>
                        </div>
                        </section>
                        <section class="clearfix">
                            <div class="form-group">
                            <div class="form-row">
                            <div class="col">
                                <button type="submit" class="btn btn-success large icon width-100"><?php if($edit) { _e("Update", 'letgo'); } else { _e("Publish", 'letgo'); } ?><i class="fa fa-chevron-right"></i></button></div> <div class="col"><button type="reset" class="btn btn-framed btn-secondary large icon width-100"><?php _e('Cancel', 'letgo'); ?><i class="fa fa-undo"></i></button></div>
                                </div>
                            </div>
                        </section>
                    </form>
                    <!--end form-submit-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
<?php osc_current_web_theme_path('common/footer2.php'); ?>