<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_nofollow_construct');

    letgo_add_body_class('page sub-page');
    osc_current_web_theme_path('header3.php') ;
?>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php _e('Send to a friend', 'letgo'); ?></h1>
                            <h4 class="location">
                            <a href="<?php echo osc_item_url() ; ?>"><i class="fa fa-share-square-o"></i> <?php echo osc_item_title(); ?></a>
                            </h4>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
<!--************ CONTENT ************************************************************************************-->
        <!--*********************************************************************************************************-->
        <section class="content">
            <section class="block">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <aside class="sidebar">
                            <h3 class="icon"><i class="fa fa-reorder"></i> <?php _e('Category', 'letgo'); ?></h3>
                            <section>
                                <ul class="sidebar-list list-unstyled">                                     
                    	 <?php
         osc_goto_first_category();
         $i= 0;
         while ( osc_has_categories() ) {
            $liClass = '';
            if($i%3 == 0){
                $liClass = '';
            }
            $i++;
         ?> <li ><a class="nav-link icon" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name() ; ?> <span class="float-right">(<?php echo osc_category_total_items() ; ?>)</span></a></li><?php } ?>
         
                                     </ul> </section> </aside>
                            
                        </div>
                        <!--end col-md-3-->

<div class="col-md-9">
<div class="box">
<h2><i class="fa fa-share-square-o"></i> <?php _e('Send', 'letgo'); ?>: <a class="small" href="<?php echo osc_item_url() ; ?>"><?php echo osc_item_title(); ?></a></h2>
<form name="sendfriend" action="<?php echo osc_base_url(true); ?>" method="post" class="form email">
            <input type="hidden" name="action" value="send_friend_post" />
            <input type="hidden" name="page" value="item" />
            <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" />
            <?php if(osc_is_web_user_logged_in()) { ?>
                            <input type="hidden" name="yourName" value="<?php echo osc_esc_html( osc_logged_user_name() ); ?>" />
                            <input type="hidden" name="yourEmail" value="<?php echo osc_logged_user_email();?>" />
            <?php } else { ?>
            <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
              <label for="name" class="col-form-label"><?php _e('Your name', 'letgo'); ?></label>
                    <?php SendFriendForm::your_name(); ?>
                </div>
                                        <!--end form-group-->
                                    </div>
                                    <!--end col-md-6-->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email" class="col-form-label"><?php _e('Your email', 'letgo'); ?></label>
                    <?php SendFriendForm::your_email(); ?>
                </div>
                                        <!--end form-group-->
                                    </div>
                                    <!--end col-md-6-->
                                </div>
                                <!--end row-->
            <?php } ?>
            <div class="row">
            <div class="col-md-6">
            <div class="form-group">
                <label class="col-form-label" for="friendName"><?php _e("Your friend's name", 'letgo'); ?></label>
                    <?php SendFriendForm::friend_name(); ?>
                </div>
            </div>
            
            <div class="col-md-6">
            <div class="form-group">
            <label class="col-form-label" for="friendEmail"><?php _e("Your friend's e-mail address", 'letgo'); ?></label>
                    <?php SendFriendForm::friend_email(); ?>
                </div>
            </div>
            </div>
            
            <div class="form-group">
                <label class="col-form-label" for="subject">
                    <?php _e('Subject (optional)', 'letgo'); ?>
                </label>
                    <?php ContactForm::the_subject(); ?>
            </div>
            
            <div class="form-group">
                <label class="col-form-label" for="message">
                    <?php _e('Message', 'letgo'); ?></label>
                <div class="textareauser">
                    <?php SendFriendForm::your_message(); ?>
                </div>
            </div>
            
            <div class="form-group">
            <?php osc_run_hook('contact_form'); ?>
            <div class="recap" align="left">
			<?php osc_show_recaptcha(); ?>
			</div>
            
                       <div class="form-row">
                       <div class="col"><button type="submit" class="btn btn-success width-100"><?php _e("Send", 'letgo');?> <i class="fa fa-paper-plane"></i></button></div> <div class="col"><button type="reset" class="btn btn-light btn-framed width-100"><?php _e("Cancel", 'letgo');?> <i class="fa fa-undo"></i></button></div></div>
                       <?php osc_run_hook('admin_contact_form'); ?>
            </div>
        </form>
        <?php SendFriendForm::js_validation(); ?></div>
     </div>
                    </div>
                    <!--end row-->
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
    
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>