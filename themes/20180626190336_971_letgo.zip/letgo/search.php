<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    if( osc_count_items() == 0 || stripos($_SERVER['REQUEST_URI'], 'search') ) {
        osc_add_hook('header','letgo_nofollow_construct');
    } else {
        osc_add_hook('header','letgo_follow_construct');
    }

    letgo_add_body_class('sub-page');
	
	if(letgo_show_as() == 'gallery'){
        $loop_template	=	'loop-search-grid.php';
		$listClass = 'listing-grid';
        $buttonClass = 'active';
    }else{
		$loop_template	=	'loop-search-list.php';
		$listClass = '';
		$buttonClass = '';
	}
	
    osc_add_hook('before-main','sidebar');
    function sidebar(){
        osc_current_web_theme_path('search-sidebar.php');
    }
    osc_add_hook('footer','autocompleteCity');
    function autocompleteCity(){ ?>

<?php
    }
?>
<?php osc_current_web_theme_path('header2.php') ; ?>

<style type="text/css">
/* body select.select_box */ 
body select { 
    display: block;
    padding: 1.5rem !important; 
    max-width: 100%; 
    border: 1px solid #e3e3e3; 
    border-radius: 3px; 
    background: url("<?php echo osc_current_web_theme_url('images/selectbox_arrow.png') ; ?>") right center no-repeat; 
    background-color: #fff; 
    color: #444444; 
    appearance: none; 
    /* this is must */ -webkit-appearance: none; 
    -moz-appearance: none; 
} 
/* body select.select_box option */ 
body select option { 

} 
/* for IE and Edge */ 
select::-ms-expand { 
    display: none; 
} 
select:disabled::-ms-expand { 
    background: #f60; 
}

</style>

<!-- LETGO CONTENT -->
<section class="content">
<section class="block">
                <div class="container">
                    <div class="row flex-column-reverse flex-md-row">
<!-- Search Sidebar -->
  <!-- LETGO -->
  <div class="col-md-9">
                            <!--============ Section Title===================================================================-->
                            <div class="section-title clearfix">
                                <div class="float-left float-xs-none">
                                    
                                    <select onChange="SortListingM(this.value)" name="sorting" id="sorting" class="small width-200px" data-placeholder="<?php echo osc_esc_html(__('Sort by', 'letgo')); ?>" >
                                    <option value=''><?php _e('Sort by', 'letgo'); ?></option>
                                    <?php
              $orders = osc_list_orders();
              $current = '';
              foreach($orders as $label => $params) {
                  $orderType = ($params['iOrderType'] == 'asc') ? '0' : '1';
                  if(osc_search_order() == $params['sOrder'] && osc_search_order_type() == $orderType) {
                      $current = $label;
                  }
              }
              ?>
        <?php $i = 0; ?>
                                        
                                        <?php
                  foreach($orders as $label => $params) {
                      $orderType = ($params['iOrderType'] == 'asc') ? '0' : '1'; ?>
          <?php if(osc_search_order() == $params['sOrder'] && osc_search_order_type() == $orderType) { ?>
          <option value="<?php echo osc_esc_html(osc_update_search_url($params)); ?>"><?php echo $label; ?></option>
          <?php } else { ?>
          <option value="<?php echo osc_esc_html(osc_update_search_url($params)); ?>"><?php echo $label; ?></option>
          <?php } ?>
          <?php $i++; ?>
          <?php } ?>
                                    </select> 
                                    <script language="javascript">//<!--   
    function SortListingM(val) {
        if (val != '') { window.location = val;}
    }
//--></script>

                                </div>
                                <div class="float-right float-xs-none d-xs-none thumbnail-toggle">
                                
                                 <a href="<?php echo osc_esc_html(osc_update_search_url(array('sShowAs'=> 'list'))); ?>" class="change-class <?php if(letgo_show_as()=='list')echo "active"; ?>" data-change-from-class="grid" data-change-to-class="list" data-parent-class="items"><i class="fa fa-th-list"></i></a> 
                                 
                                 <a href="<?php echo osc_esc_html(osc_update_search_url(array('sShowAs'=> 'gallery'))); ?>" class="change-class <?php if(letgo_show_as()=='gallery')echo "active"; ?>" data-change-from-class="list" data-change-to-class="grid" data-parent-class="items"><i class="fa fa-th"></i></a>
                                                                </div>
                            </div>
  <!-- LETGO -->  
   
    <?php if( osc_get_preference('header-728x90', 'letgo') != ""){ ?>
    <div class="box" align="center"> <?php echo osc_get_preference('header-728x90', 'letgo'); ?></div>
    <?php } ?>
    <br />
    <?php
            $i = 0;
            osc_get_premiums(letgo_premium_listings_shown());
            if(osc_count_premiums() > 0) {
            echo '';
			?>
    <?php 
			
            View::newInstance()->_exportVariableToView("listType", 'premiums');
            View::newInstance()->_exportVariableToView("listClass",$listClass.' premium-list');
            osc_current_web_theme_path($loop_template);
            }
        ?>
    
    <?php if(osc_count_items() > 0) {
        echo '';
		?>
    <?php 
		
        View::newInstance()->_exportVariableToView("listType", 'items');
        View::newInstance()->_exportVariableToView("listClass",$listClass);
            osc_current_web_theme_path($loop_template);
    ?>
    
    <?php } ?>
    <?php if( osc_get_preference('search-results-top-728x90', 'letgo') != "" ){ ?>
    <div class="box" align="center"> <?php echo osc_get_preference('search-results-top-728x90', 'letgo'); ?></div>
    <?php } ?>
    <!-- LETGO PAGINATION --> 
                            <div class="page-pagination">
                                    <div class="pagination" align="center">
                                    <?php echo osc_search_pagination(); ?>
                            </div>
                            </div>
                            <!-- END LETGO PAGINATION -->
    
  </div> <!-- LETGO COL-MD-9 -->
  
  <!-- LETGO SEARCH SIDEBAR -->
  <div class="col-md-3">
  
  <?php osc_current_web_theme_path('search-sidebar.php') ; ?>
 </div>
  <!-- END LETGO SEARCH SIDEBAR -->
  </div> <!--end LETGO ROW-->
  </div> <!--end container-->
  </section><!-- LETGO block end-->
</section><!-- LETGO CONTENT -->
<!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post2.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>
