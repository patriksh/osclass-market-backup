var is_loading = true ;



/* PHOTO */
function add_photo_field() {
    var num_img = $('.photos input[name="photos[]"]').size() + $(".photos ul li").length ;
    if( letgo.max_number_photos != 0 && num_img < letgo.max_number_photos ) {
		var file        = $("<input>").attr('type', 'file').attr('name', 'photos[]') ;
		var remove_link = $("<a>").attr('href', 'javascript://').addClass('remove').html(letgo.photo_remove_text) ;
		remove_link.bind('click', function(event) {
			$(this).parent().parent().remove() ;
		}) ;
        var remove      = $("<span>").addClass("help-inline").html(letgo.remove_link) ;
		var div         = $("<div>").addClass('input-file').append(file).append(remove) ;

		$(".more-photos").append(div) ;
    } else {
        alert(letgo.max_images_fields_txt) ;
    }
}

function delete_image(photo_id, item_id, name, secret) {
    var result = confirm(letgo.delete_photo_txt);

    if(result) {
        $.ajax({
            type: "POST",
            url: letgo.ajax_url,
			data: { action: "delete_image", id: photo_id, item: item_id, code: name, secret: secret },
            dataType: 'json',
            success: function(data) {
                if(data.success) {
					$("li[name=" + name + "]").fadeOut('slow') ;
                    $("li[name=" + name + "]").remove() ;
                }
            }
        }) ;
    }
} ;


