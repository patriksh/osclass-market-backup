<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<section>
                                    <div class="box">
                                    <h4 class="icon"><i class="fa fa-reorder category-icon"></i> <?php _e('All categories', 'letgo'); ?></h4>
                            
                                <ul class="sidebar-list list-unstyled">                                     
                    	 <?php
         osc_goto_first_category();
         $i= 0;
         while ( osc_has_categories() ) {
            $liClass = '';
            if($i%3 == 0){
                $liClass = '';
            }
            $i++;
         ?> <li ><a class="nav-link icon" href="<?php echo osc_search_category_url() ; ?>"><i class="fa fa-<?php echo osc_esc_html(letgo_category_icon( osc_category_id() )); ?> category-icon"></i> <?php echo osc_category_name() ; ?> <span class="float-right">(<?php echo osc_category_total_items() ; ?>)</span></a></li><?php } ?>
         
                                     </ul> 
                                     </div>
                                     </section>