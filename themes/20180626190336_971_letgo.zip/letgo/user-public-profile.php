<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','letgo_follow_construct');
	
    if(letgo_show_as() == 'gallery'){
        $loop_template	=	'loop-user-public-grid.php';
    }else{
		$loop_template	=	'loop-user-public-list.php';
	}
	
    $address = '';
    if(osc_user_address()!='') {
        if(osc_user_city_area()!='') {
            $address = osc_user_address().", ".osc_user_city_area();
        } else {
            $address = osc_user_address();
        }
    } else {
        $address = osc_user_city_area();
    }
    $location_array = array();
    if(trim(osc_user_city()." ".osc_user_zip())!='') {
        $location_array[] = trim(osc_user_city()." ".osc_user_zip());
    }
    if(osc_user_region()!='') {
        $location_array[] = osc_user_region();
    }
    if(osc_user_country()!='') {
        $location_array[] = osc_user_country();
    }
    $location = implode(", ", $location_array);
    unset($location_array);

    osc_enqueue_script('jquery-validate');

    letgo_add_body_class('page sub-page');
	
    osc_add_hook('before-main','sidebar');
	
    function sidebar(){
        osc_current_web_theme_path('user-public-sidebar.php');
    }

    osc_current_web_theme_path('header3.php');
?>
<!--============ Page Title =========================================================================-->
                <div class="page-title">
                    <div class="container clearfix">
                        <div class="float-left float-xs-none">
                            <h1><?php _e('Public Profile', 'letgo'); ?>
                            </h1>
                            <h4 class="">
                                <i class="fa fa-user"></i> <?php echo osc_user_name(); ?></h4>
                        </div>
                    </div>
                    <!--end container-->
                </div>
                <!--============ End Page Title =====================================================================-->
                <div class="background">
                    
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
            <!--end hero-wrapper-->
        </header>
<!-- LETGO -->
<div class="wrapper wrapper-flash"><?php osc_show_flash_message(); ?></div>
<!--************ CONTENT ************************************************************************************-->
        <section class="content">
            <section class="block">
                <section>
                    <div class="container">
                        <div class="author big">
                            <div class="author-image">
                                <div class="background-image">
                                    <?php if (function_exists('profile_picture_show')){profile_picture_show();} else{ echo '<img src="' . osc_current_web_theme_url('images/no-user-photo.jpg') . '">'; } ?>
                                </div>
                            </div>
                            <!--end author-image-->
                            <div class="author-description">
                                <div class="section-title">
                                    <h2><?php echo osc_user_name(); ?></h2>
                                    <h4 class="location">
                                        <i class="fa fa-map-marker"></i> <?php echo $location; ?>. <?php if( $address !== '' ) { ?>
        <strong><?php _e('Address', 'letgo');?></strong>: <?php echo $address; ?>
        <?php } ?>
                                    </h4>
                                    <figure>
                                        <div class="float-left">
                                           <i class="fa fa-check-square-o"></i> <?php echo osc_format_date(osc_user_field('dt_reg_date')); ?> &nbsp; <?php if ( osc_user_phone_mobile() != '' ) { ?>
                                            <i class="fa fa-phone"></i>
                                            <?php printf('%s', osc_user_phone_mobile()); ?>
                                            <?php } else { ?>
                                            <i class="fa fa-phone"></i>
                                            <i class="fa fa-minus"></i>
                                            <?php } ?>
                                            &nbsp;
                                            <?php if ( osc_user_phone_land() != '' ) { ?>
                                            <i class="fa fa-mobile"></i>
                                            <?php echo osc_user_phone_land(); ?>
                                            <?php } else { ?>
                                            <i class="fa fa-mobile"></i>
                                            <i class="fa fa-minus"></i>
                                            <?php } ?>
                                        </div>
                                        <div class="text-align-right social">
                                            <a href="#sendemail">
                                                <i class="fa fa-envelope-o"></i> <?php _e("Send", 'letgo'); ?> <?php _e("E-mail", 'letgo'); ?>
                                            </a>
                                        </div>
                                    </figure>
                                </div>
                                <div class="additional-info">
                                    <ul>
                                        <li>
                                            <figure><?php _e('Listings', 'letgo'); ?></figure>
                                            <aside><?php echo osc_user_items_validated() ?></aside>
                                        </li>
                                        <li>
                                            <figure><?php _e('Last active', 'letgo'); ?></figure>
                                            <aside><?php echo osc_format_date(osc_user_field('dt_access_date')); ?></aside>
                                        </li>
                                        <li>
                                            <figure><?php _e("Phone", 'letgo'); ?></figure>
                                            <aside><?php echo osc_user_phone(); ?>&nbsp;</aside>
                                        </li>
                                        <li>
                                            <figure><?php _e("Website", 'letgo'); ?></figure>
                                            <aside><a href="<?php echo osc_user_website(); ?>" target="_blank" rel="nofollow"><?php echo osc_user_website(); ?></a>&nbsp;</aside>
                                        </li>
                                    </ul>
                                </div>
                                <!--end addition-info-->
                                <p><?php if( osc_user_info() !== '' ) { ?>
                                   <?php _e('Description', 'letgo'); ?>: <?php echo osc_user_info(); ?>
                                   <?php } ?>
                                </p>
                            </div>
                            <!--end author-description-->
                        </div>
                        <!--end author-->
                    </div>
                    <div class="background">
                        <div class="background-image original-size background-repeat-x">
                            <img src="<?php echo osc_current_web_theme_url('assets/img/gradient-background.png') ; ?>" alt="">
                        </div>
                        <!--end background-image-->
                    </div>
                    <!--end background-->
                </section>
                
<div class="container">
                    <div class="row flex-column-reverse flex-md-row">
                        <div class="col-md-9">
                            <section>

<?php if( osc_count_items() > 0 ) { ?>        
      <?php osc_current_web_theme_path($loop_template); ?>
<div class="page-pagination">
                                
                                    <div class="pagination" align="center">
                                
                                    <?php echo osc_pagination_items(); ?>
                                        
                            </div>
                                
                            </div>    <?php } ?>

</section>
<section>
                                
                                <?php if(osc_logged_user_id() !=  osc_user_id()) { ?>
  <?php     if(osc_reg_user_can_contact() && osc_is_web_user_logged_in() || !osc_reg_user_can_contact() ) { ?>
                                <h2 id="sendemail"><?php _e("Contact seller", 'letgo'); ?>: <?php echo osc_user_name(); ?></h2>
<form action="<?php echo osc_base_url(true); ?>" method="post" name="contact_form" id="contact_form" class="form email">
      <input type="hidden" name="action" value="contact_post" />
      <input type="hidden" name="page" value="user" />
      <input type="hidden" name="id" value="<?php echo osc_user_id();?>" /> 
                                      <div class="row">
                                      <div class="col-md-6">
                                      <div class="form-group">
                                                <label for="name" class="col-form-label"><?php _e('Your name', 'letgo'); ?> *</label>
                                                <input class="form-control" id="yourName" name="yourName" type="text" value="" />
                                            </div>
                                            </div>
                                            <!--end form-group-->
                                            <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="email" class="col-form-label"><?php _e('Your e-mail address', 'letgo'); ?> *</label><input class="form-control" id="yourEmail" name="yourEmail"  type="text" value="" />
                                            </div>
                                            </div>
                                            <!--end form-group-->
                                            <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="message" class="col-form-label"><?php _e('Message', 'letgo'); ?> *</label>
                                                
                                                <textarea name="message" class="form-control" rows="4" id="message">
</textarea>
                                            </div>
                                            </div>
                                            <!--end form-group-->
                                            <div class="col-md-6">
                                            <div class="form-group">
                                <?php osc_run_hook('item_contact_form', osc_item_id()); ?>
                                <?php osc_show_recaptcha(); ?>
            </div>
            </div>                                
                                            <div class="col-md-12">
                                            <div class="form-group">
                                            <div class="form-row">
                                            <div class="col">
                                            <button type="submit" class="btn btn-block btn-primary width-100">
               <i class="fa fa-envelope" aria-hidden="true"></i> <?php _e("Send", 'letgo'); ?> <?php _e("E-mail", 'letgo'); ?>
            </button></div> <div class="col"><button type="reset" class="btn btn-light btn-framed width-100"><?php _e("Cancel", 'letgo');?> <i class="fa fa-undo"></i></button></div></div></div></div>
                                        </div></form> 
                                        <?php } ?> <?php } ?>
                                <!--end form-->
                            </section>
                            <?php ContactForm::js_validation(); ?>
                        </div>
                        <!--end col-md-9-->
                        <div class="col-md-3">
                            <!--============ Side Bar ===============================================================-->
                            <aside class="sidebar">
                                <?php osc_current_web_theme_path('user-public-sidebar.php') ; ?>
                            </aside>
                            <!--============ End Side Bar ===========================================================-->
                        </div>
                        <!--end col-md-3-->
                    </div>
                </div>
                <!--end container-->
            </section>
            <!--end block-->
        </section>
        <!--end content-->
        <!-- LETGO -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery-3.2.1.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/popper.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/bootstrap/js/bootstrap.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/selectize.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/masonry.pkgd.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/icheck.min.js') ; ?>"></script>
    <!-- <script type="text/javascript" src="< ? php echo osc_current_web_theme_url('assets/js/jQuery.MultiFile.min.js') ; ?>"></script> -->
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/owl.carousel.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/jquery.validate.min.js') ; ?>"></script>
    <script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/readmore.min.js') ; ?>"></script>
	<script type="text/javascript" src="<?php echo osc_current_web_theme_url('assets/js/custom-item-post.js') ; ?>"></script>
<!-- LETGO -->
<?php osc_current_web_theme_path('footer.php') ; ?>