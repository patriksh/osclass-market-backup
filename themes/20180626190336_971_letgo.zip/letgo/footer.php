<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php osc_run_hook('after-main'); ?>
<?php osc_run_hook('footer'); ?>
<?php if(osc_is_ad_page() || osc_is_search_page()){ ?>

<?php } ?>
<!-- LETGO -->
        <!--************ FOOTER *************************************************************************************-->
        <footer class="footer">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12" align="center">
                            <a href="<?php echo osc_base_url(); ?>" class="brand">
                            <?php echo logo_header(); ?>
                            </a>
                            <p>
            <?php if( osc_is_web_user_logged_in() ) { ?>
            <a href="<?php echo osc_user_profile_url(); ?>"><i class="fa fa-user" aria-hidden="true"></i> <?php _e('Dashboard', 'letgo') ; ?></a> - <a href="<?php echo osc_user_logout_url(); ?>"><i class="fa fa-sign-out"></i>
          <?php _e('Logout', 'letgo'); ?>
          </a>.
            <?php } else { ?>        
        <a href="<?php echo osc_user_login_url(); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i> <?php _e('Login', 'letgo') ; ?></a> -
        <a href="<?php echo osc_register_account_url() ; ?>"><i class="fa fa-user"></i> <?php _e('Create', 'letgo'); ?></a>. 
        <?php } ?> <a href="<?php echo osc_item_post_url(); ?>"><i class="fa fa-pencil" aria-hidden="true"></i> <?php _e('Publish', 'letgo');?></a>. <a href="<?php echo osc_contact_url(); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php _e('Contact us', 'letgo'); ?></a>. <a href="javascript:;" data-toggle="modal" data-target="#myModalhelp" ><?php _e('Help', 'letgo'); ?> <i class="fa fa-question-circle" aria-hidden="true"></i></a></p>
                            <p> &copy; <script>document.write(new Date().getFullYear())</script> <a class="" href="<?php echo osc_base_url(); ?>"><?php echo osc_page_title(); ?></a>. <?php if( (!defined('MULTISITE') || MULTISITE==0) && osc_get_preference('footer_link', 'letgo') !== '0') {
            echo '' . sprintf(__('Powered by <a title="Osclass web" href="%s">Osclass.org</a>.'), 'http://osclass.org/') . '';
        }
        ?>

                            </p>
                            <p><?php if( osc_get_preference('facebook-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('facebook-top', 'letgo')); ?>"><i class="fa fa-facebook" style="color:#0099CC"></i></a>
                    <?php } else { ?><i class="fa fa-facebook" style="color:#0099CC"></i><?php } ?> &nbsp;&nbsp;
                
                <?php if( osc_get_preference('twitter-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('twitter-top', 'letgo')); ?>"> <i class="fa fa-twitter" style="color:#00CCFF"></i></a> <?php } else { ?>  <i class="fa fa-twitter" style="color:#00CCFF"></i> <?php } ?>
                &nbsp;&nbsp;
				  		
					    <?php if( osc_get_preference('google-plus-top', 'letgo') != '') {?><a class="" target='_blank' href="<?php echo osc_esc_html(osc_get_preference('google-plus-top', 'letgo')); ?>"><i class="fa fa-google-plus" style="color:#FF0000"></i></a> &nbsp; <?php } else { ?> <i class="fa fa-google-plus" style="color:#FF0000"></i> <?php } ?></p>
                        </div>
                        <!--end col-md-4-->
                    </div>
                    <!--end row-->
                </div>
                <div class="background">
                    <div class="background-image original-size">
                        <img src="<?php echo osc_current_web_theme_url('assets/img/footer-background-icons.jpg') ; ?>">
                    </div>
                    <!--end background-image-->
                </div>
                <!--end background-->
            </div>
        </footer>
        <!--end footer-->
    </div>
<!-- LETGO -->
<!-- LETGO MODAL -->
<div class="modal fade" id="myModalhelp" tabindex="-1" role="dialog" aria-labelledby="myModalLabelhelp">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel" align="center"><i class="fa fa-question-circle" aria-hidden="true"></i> <?php _e('Help', 'letgo'); ?> - <?php _e('Useful information', 'letgo'); ?></h4>
      </div>
      <div class="modal-body">
      <?php if (osc_get_preference('help-text', 'letgo')){ echo osc_get_preference('', 'letgo');} else { echo "<strong>For sellers.</strong> <br/> 1. When you publish any listing, we recommend to login with your details. If you don't have an account on our website, please feel free to register a new account for free. <br />2. In the ad use a picture, title and description to better describe your product that you sell. <br />3. Use your active e-mail and correct phone number. <br /> <strong>For buyers.</strong> <br />1. Avoid scams by acting locally or paying with PayPal. <br /> 2. Never pay with Western Union, Moneygram or other anonymous payment services. <br /> 3. Don\'t buy or sell outside of your country. Don\'t accept cashier cheques from outside your country. <br /> 4. This site is never involved in any transaction, and does not handle payments, shipping, guarantee transactions, provide escrow services, or offer 'buyer protection' or 'seller certification'."; } ?>
      
      <?php if( osc_get_preference('help-text', 'letgo') != '') {?>
        <?php echo osc_get_preference('help-text', 'letgo'); ?>
        <?php } ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal"><?php _e('Close', 'letgo'); ?></button>
      </div>
    </div>
  </div>
</div>
<!-- END LETGO MODAL -->
</body></html>