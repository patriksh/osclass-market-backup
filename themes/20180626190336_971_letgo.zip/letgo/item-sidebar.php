<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<section>
                                   <!-- <h2>< ?php _e("Contact publisher", 'letgo'); ?></h2> -->
                                    <div class="box">
                                    <h4 align="center"><?php _e("Contact seller", 'letgo'); ?></h4>
                                        <div class="author">
                                            <div class="author-image">
                                                <div class="background-image">
                                                <?php if (function_exists('profile_picture_show')){profile_picture_show();} else{ echo '<img src="' . osc_current_web_theme_url('images/no-user-photo.jpg') . '" alt="No Photo">'; } ?>
                                                </div>
                                            </div>
                                            <!--end author-image-->
                                            <div class="author-description">
                                            <?php if( osc_item_user_id() != null ) { ?>
                                            <u><a href="<?php echo osc_user_public_profile_url( osc_item_user_id() ); ?>" ><?php echo osc_item_contact_name(); ?></a></u>
    <?php } else { ?>
                                                <h4><?php printf('%s', osc_item_contact_name()); ?></h4>
                                                <?php } ?>
                                                <?php if(osc_item_user_id() <> 0) { ?>
                      <?php $get_user = User::newInstance()->findByPrimaryKey( osc_item_user_id() ); ?>
                      <?php if(isset($get_user['dt_reg_date']) AND $get_user['dt_reg_date'] <> '') { ?>
                        <div class="" data-rating=""><span class="small"><?php echo __('Registered on', 'letgo'); ?> <?php echo osc_format_date(osc_user_field('dt_reg_date')); ?></span></div>
                        <a href="<?php echo osc_user_public_profile_url( osc_item_user_id() ); ?>" class="text-uppercase"><?php echo __('Listings', 'letgo'); ?>
                                                    <span class="appendix">(<?php echo osc_user_items_validated() ?>)</span>
                                                </a>
                      <?php } else { ?>
                        <div class="" data-rating=""><span class="small"><?php echo __('Unknown registration date', 'letgo'); ?></span></div>
                      <?php } ?>
                    <?php } else { ?>
                      <div class="" data-rating=""><span class="small"><?php echo __('Unregistered user', 'letgo'); ?></span></div>
                    <?php } ?>
                                            </div>
                                            <!--end author-description-->
                                        </div>
                                        <hr>
                                            <?php if(function_exists('osc_telephone_number')){ osc_telephone_number();} ?>
                                        <dl><?php if ( osc_user_phone_mobile() != '' ) { ?>
                                            <dt><i class="fa fa-phone"></i></dt>
                                            <dd><?php printf('%s', osc_user_phone_mobile()); ?></dd>
                                            <?php } else { ?>
                                            <dt><i class="fa fa-phone"></i></dt>
                                            <dd><i class="fa fa-minus"></i></dd>
                                            <?php } ?>
                                            <?php if ( osc_user_phone_land() != '' ) { ?>
                                            <dt><i class="fa fa-mobile"></i></dt>
                                            <dd><?php echo osc_user_phone_land(); ?></dd>
                                            <?php } else { ?>
                                            <dt><i class="fa fa-mobile"></i></dt>
                                            <dd><i class="fa fa-minus"></i></dd>
                                            <?php } ?>
                                           <?php if( osc_item_show_email() ) { ?> <dt><?php _e('E-mail', 'letgo'); ?></dt> 
                                            <dd><a href="mailto:<?php echo osc_item_contact_email(); ?>"><?php echo osc_item_contact_email(); ?></a></dd> <?php } ?>
                                        </dl>
                                        <!--end author-->
                                        <?php if( osc_item_is_expired () ) { ?>
                        <p align="center">
                            <?php _e("The listing is expired. You can't contact the publisher.", 'letgo'); ?>
                        </p>
                    <?php } else if( ( osc_logged_user_id() == osc_item_user_id() ) && osc_logged_user_id() != 0 ) { ?>
                        <p align="center">
                            <?php _e("It's your own listing, you can't contact the publisher.", 'letgo'); ?>
                        </p>
                        <div class="form-group"><a href="<?php echo osc_item_edit_url(); ?>" class="btn btn-warning small width-100"><i class="fa fa-edit"></i> <?php _e('Edit item', 'letgo'); ?></a></div>
                        <div class="form-group"><a href="<?php echo osc_user_dashboard_url(); ?>" class="btn btn-success small width-100"><i class="fa fa-cog"></i> <?php _e('Dashboard', 'letgo'); ?></a></div>
                                        <?php } else if( osc_reg_user_can_contact() && !osc_is_web_user_logged_in() ) { ?>
                                        <div class="form-group">
                        <p align="center">
                            <?php _e("You must log in or register a new account in order to contact the advertiser", 'letgo'); ?>
                            </p></div>
                                        <div class="form-group">
                            <a class="btn btn-info small width-100" href="<?php echo osc_user_login_url(); ?>"><i class="fa fa-sign-in"></i> <?php _e('Login', 'letgo'); ?></a> </div> 
                            <div class="form-group">
                            <a class="btn btn-success small width-100" href="<?php echo osc_register_account_url(); ?>"><i class="fa fa-edit"></i> <?php _e('Create', 'letgo'); ?></a>
                        </div>
                                        <?php } else { ?>
<form <?php if( osc_item_attachment() ) { ?>enctype="multipart/form-data"<?php } ?> action="<?php echo osc_base_url(true); ?>" method="post" name="contact_form" class="form email">
                <?php osc_prepare_user_info(); ?>
                    <input type="hidden" name="action" value="contact_post" />
                    <input type="hidden" name="page" value="item" />
                    <input type="hidden" name="id" value="<?php echo osc_item_id(); ?>" /> 
                                      <div class="form-group">
                                                <label for="name" class="col-form-label"><?php _e('Your name', 'letgo'); ?> *</label>
                                                <input class="form-control" id="yourName" name="yourName" type="text" value="" />
                                            </div>
                                            <!--end form-group-->
                                            <div class="form-group">
                                                <label for="email" class="col-form-label"><?php _e('Your e-mail address', 'letgo'); ?> *</label><input class="form-control" id="yourEmail" name="yourEmail"  type="text" value="" />
                                            </div>
                                            <!--end form-group-->
                                            <div class="form-group">
                                                <label for="message" class="col-form-label"><?php _e('Message', 'letgo'); ?> *</label>
                                                
                                                <textarea name="message" class="form-control" rows="4" id="message">
</textarea>
                                            </div>
                                            
                                            <?php if(osc_item_attachment()) { ?>
                    <div class="form-group">
                        <label class="col-form-label" for="attachment"><?php _e('Attachment', 'letgo'); ?>:</label>
                        <div><?php ContactForm::your_attachment(); ?></div>
                    </div>
                <?php }; ?>
                                            
                                            <!--end form-group-->
                                            <div class="form-group">
                <?php osc_run_hook('item_contact_form', osc_item_id()); ?>
                
                                <?php osc_show_recaptcha(); ?>
            </div>
                                            <button type="submit" class="btn btn-block btn-primary width-100">
               <i class="fa fa-envelope" aria-hidden="true"></i> <?php _e("Send", 'letgo'); ?> <?php _e("E-mail", 'letgo'); ?>
            </button>
                                        </form> 
                                        <?php } ?> 
                                    </div>
                                    <!--end box-->
                                    <?php if( osc_get_preference('sidebar-300x250', 'letgo') != '') {?>
  <br /> <div class="box" align="center"> <?php echo osc_get_preference('sidebar-300x250', 'letgo'); ?> </div>
  <?php } ?>
                                </section>