<?php 
/**
* Admin menu page for Theme Colors settings
*
*/
?>
<?php if ( (!defined('ABS_PATH')) ) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if ( !OC_ADMIN ) exit('User access is not allowed.'); ?>
<?php $colorMode = osc_get_preference('theme_color_mode', 'letgo');?>
<?php $google_fonts = osc_get_preference('google_fonts', 'letgo');?>
<h2 class="render-title"><?php _e('Theme Style', 'letgo'); ?></h2>
<form action="<?php echo osc_admin_render_theme_url('oc-content/themes/letgo/admin/settings.php');?>" method="post" enctype="multipart/form-data" class="nocsrf">
    <input type="hidden" name="action_specific" value="theme_style" />
	<fieldset>
		<div class="form-horizontal">
			<div class="form-row">
                <div class="form-label"><?php _e('Theme color mode', 'letgo'); ?></div>
                <div class="form-controls">
                    <select name="theme_color_mode">
                        <option value="blue"><?php  echo osc_esc_html(__('Default','letgo'));?></option>
                    </select>
                </div>
			</div>
			<div class="form-row">
                <div class="form-label"><?php _e('Google fonts', 'letgo'); ?></div>
                <div class="form-controls">
                <select name="google_fonts">
				<option value="Varela+Round">Varela Round</option>
                </select>
                </div>
			</div>
			<div class="form-actions">
				<input id="button" type="submit" value="<?php echo osc_esc_html(__('Save changes','letgo')); ?>" class="btn btn-submit">
			</div>
		</div>
	</fieldset>
</form>