<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php if ( (!defined('ABS_PATH')) ) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if ( !OC_ADMIN ) exit('User access is not allowed.'); ?>
<link rel="stylesheet" href="<?php echo osc_current_web_theme_url('admin/css/jquery.switchButton.css');?>">


<div id="tabs" class="letgo_tab let_main_tabs">
  <ul>
    <li><a href="#general"><?php _e('General','letgo');?></a></li>
    <li><a href="#theme-style"><?php _e('Theme Style','letgo');?></a></li>
    <li><a href="#templates"><?php _e('Templates','letgo');?></a></li>
    <li><a href="#logo"><?php _e('Header Logo','letgo');?></a></li>
    <li><a href="#favicon"><?php _e('Favicon','letgo');?></a></li>
    <li><a href="#banner"><?php _e('HomePage Banner','letgo');?></a></li> 
    <li><a href="#category-icons"><?php _e('Category Icons','letgo');?></a></li>
    <li><a href="#ads"><?php _e('Ads Management','letgo');?></a></li>
    <a class="btn" href="<?php echo osc_admin_render_theme_url('oc-content/themes/letgo/docs/index.php'); ?>"><?php _e('Documentation','letgo');?></a>
  </ul>
  <div id="general">
    <h2 class="render-title">
      <?php _e('Theme settings', 'letgo'); ?>
    </h2>
    <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/letgo/admin/settings.php'); ?>" method="post" class="nocsrf">
      <input type="hidden" name="action_specific" value="settings" />
      <fieldset>
        <div class="form-horizontal">
          <div class="form-row">
            <div class="form-label">
              <?php _e('Top text (welcome message)', 'letgo'); ?>
            </div>
            <div class="form-controls">
              <textarea style="height: 50px; width: 500px;" name="welcome_message"><?php echo osc_get_preference('welcome_message', 'letgo'); ?></textarea>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label">
              <?php _e('Show lists as', 'letgo'); ?>
            </div>
            <div class="form-controls">
              <select name="defaultShowAs@all">
                <option value="gallery" <?php if((letgo_default_show_as()) == 'gallery'){ echo 'selected="selected"'; } ?>>
                <?php echo osc_esc_html(__('Grid','letgo')); ?>
                </option>
                <option value="list" <?php if((letgo_default_show_as()) == 'list'){ echo 'selected="selected"'; } ?>>
                <?php echo osc_esc_html(__('List','letgo')); ?>
                </option>
              </select>
            </div>
          </div>
          
          <?php if(!defined('MULTISITE') || MULTISITE==0) { ?>
            <div class="form-row">
                <div class="form-label"><?php _e('Footer link', 'letgo'); ?></div>
                <div class="form-controls">
                    <div class="form-label-checkbox"><input type="checkbox" name="footer_link" value="1" <?php echo (osc_get_preference('footer_link', 'letgo') ? 'checked' : ''); ?> > Help Osclass by linking to <a href="http://osclass.org/" target="_blank">osclass.org.</a></div>
                    <span class="help-box">Powered by <a title="Osclass web" href="http://osclass.org/">OSCLASS</a></span>
                </div>
            </div>
            <?php } ?>
          
          
          
          <h2 class="render-title"><?php _e('Contacts', 'letgo'); ?></h2>
    <div class="form-row">
                <div class="form-label"><?php _e('Description', 'letgo'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 85px; width: 500px;" name="contact-text" placeholder="Example: We are located in the heart of a superb place in the world. We love to work with classifieds."><?php echo osc_esc_html( osc_get_preference('contact-text', 'letgo') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
          
          <div class="form-row">
                <div class="form-label"><?php _e('Mobile/Phone', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="youtube-top" value="<?php echo osc_esc_html( osc_get_preference('youtube-top', 'letgo') ); ?>" > Ex.: +1237894879
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label"><?php _e('Email', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="email-top" value="<?php echo osc_esc_html( osc_get_preference('email-top', 'letgo') ); ?>" > Example: admin@example.com
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label"><?php _e('Office hours', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="skype-top" value="<?php echo osc_esc_html( osc_get_preference('skype-top', 'letgo') ); ?>" > Ex.: 8am - 5pm
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
          
          <div class="form-row">
                <div class="form-label"><?php _e('Facebook', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="facebook-top" value="<?php echo osc_esc_html( osc_get_preference('facebook-top', 'letgo') ); ?>" > Example: http://www.facebook.com/123456789
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label"><?php _e('Twitter', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="twitter-top" value="<?php echo osc_esc_html( osc_get_preference('twitter-top', 'letgo') ); ?>" > Example: http://www.twitter.com/123456789
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label"><?php _e('Google plus', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="google-plus-top" value="<?php echo osc_esc_html( osc_get_preference('google-plus-top', 'letgo') ); ?>" > Example: https://plus.google.com/123456789
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
          
          <h2 class="render-title"><?php _e('Help', 'letgo'); ?> and <?php _e('Useful information', 'letgo'); ?></h2>
    <div class="form-row">
                <div class="form-label"><?php _e('Write here any help and useful information for your visitors. HTML format is accepted.', 'letgo'); ?></div>
                <div class="form-controls">
                    <textarea style="height: 85px; width: 500px;" name="help-text" placeholder="<strong>For sellers.</strong> <br/> 1. When you publish any listing, we recommend to login with your details. If you don't have an account on our website, please feel free to register a new account for free. <br />2. In the ad use a picture, title and description to better describe your product that you sell. <br />3. Use your active e-mail and correct phone number. <br /> <strong>For buyers.</strong> <br />1. Avoid scams by acting locally or paying with PayPal. <br /> 2. Never pay with Western Union, Moneygram or other anonymous payment services. <br /> 3. Don\'t buy or sell outside of your country. Don\'t accept cashier cheques from outside your country. <br /> 4. This site is never involved in any transaction, and does not handle payments, shipping, guarantee transactions, provide escrow services, or offer 'buyer protection' or 'seller certification'."><?php echo osc_esc_html( osc_get_preference('help-text', 'letgo') ); ?></textarea>
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
          
          
        </div>
      </fieldset>
      <div class="form-actions">
        <input type="submit" value="<?php echo osc_esc_html(__('Save changes', 'letgo')); ?>" class="btn btn-submit btn-success">
      </div>
    </form>
  </div>
  <div id="theme-style">
    <?php include 'theme-style.php'; ?>
  </div>
  <div id="templates">
    <?php include 'templates.php'; ?>
  </div>
  <div id="logo">
    <?php include 'header.php'; ?>
  </div>
  <div id="favicon">
    <?php include 'favicon.php'; ?>
  </div>
  <div id="banner">
    <?php include 'homeimage.php'; ?>
  </div>
  <div id="category-icons">
    <?php include 'category-icons.php'; ?>
  </div>
  <div id="ads">
    <?php include 'ads.php'; ?>
  </div>
   
  
</div>
<script type="text/javascript" src="<?php echo osc_current_web_theme_url('admin/js/jquery.switchButton.js');?>"></script>
<script type="text/javascript" src="<?php echo osc_current_web_theme_url('admin/js/jquery.admin.js');?>"></script>