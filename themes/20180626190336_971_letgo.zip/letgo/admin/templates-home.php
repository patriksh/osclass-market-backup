<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */
?>
<?php if ( (!defined('ABS_PATH')) ) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if ( !OC_ADMIN ) exit('User access is not allowed.'); ?>

<h2 class="render-title">
  <?php _e('Home page settings', 'letgo'); ?>
</h2>
<form action="<?php echo osc_admin_render_theme_url('oc-content/themes/letgo/admin/settings.php'); ?>" method="post" class="nocsrf">
  <input type="hidden" name="action_specific" value="templates_home" />
  <fieldset>
    <div class="form-horizontal">
      <div class="form-row">
        <div class="form-label">
          <?php _e('Show banner', 'letgo'); ?>
        </div>
        <div class="form-controls">
          <div class="form-label-checkbox">
            <input type="checkbox" name="show_banner" value="1" <?php echo ( osc_esc_html( osc_get_preference('show_banner', 'letgo') ) == "1")? "checked": ""; ?>>
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="form-label">
          <?php _e('Search placeholder', 'letgo'); ?>
        </div>
        <div class="form-controls">
          <input type="text" class="xlarge" name="keyword_placeholder" value="<?php echo osc_esc_html( osc_get_preference('keyword_placeholder', 'letgo') ); ?>">
        </div>
      </div>
      <div class="form-row">
        <div class="form-label">
          <?php _e('Listing Location', 'letgo'); ?>
        </div>
        <div class="form-controls">
          <div class="form-label-checkbox">
            <input type="checkbox" class="switch" name="show_search_country" value="1" <?php echo (osc_esc_html( osc_get_preference('show_search_country', 'letgo') ) == "1")? "checked": ""; ?>>
          </div>
        </div>
      </div> 
      <div class="form-row">
        <div class="form-label">
          <?php _e('Premium listings shown', 'letgo'); ?>
        </div>
        <div class="form-controls">
          <input type="number" min="1" max="50" class="xlarge" name="premium_listings_shown_home" value="<?php echo osc_esc_html( osc_get_preference('premium_listings_shown_home', 'letgo') ); ?>">
        </div>
      </div>
      <hr />
      <h2 class="render-title">
  <?php _e('Promo Block', 'letgo'); ?>
</h2>
      <div class="form-row">
                <div class="form-label"><?php _e('Promo Title', 'letgo'); ?>*:</div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="homepage-block1" placeholder="Selling with us is easy!" value="<?php echo osc_esc_html( osc_get_preference('homepage-block1', 'letgo') ); ?>" >
                </div>
            </div>
    <div class="form-row">
                <div class="form-label"><?php _e('Name Block 1', 'letgo'); ?>*:</div>
                <div class="form-controls">
                <input type="text" class="xlarge" name="homepage-block2" placeholder="Create" value="<?php echo osc_esc_html( osc_get_preference('homepage-block2', 'letgo') ); ?>" > Link: <input type="text" class="xlarge" name="homepage-block1l" value="<?php echo osc_esc_html( osc_get_preference('homepage-block1l', 'letgo') ); ?>" >
                </div>
            </div>
      <div class="form-row">
                <div class="form-label"><?php _e('Name Block 2', 'letgo'); ?>*:</div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="homepage-block3" placeholder="Publish" value="<?php echo osc_esc_html( osc_get_preference('homepage-block3', 'letgo') ); ?>" > Link: <input type="text" class="xlarge" name="homepage-block2l" value="<?php echo osc_esc_html( osc_get_preference('homepage-block2l', 'letgo') ); ?>" >
                </div>
            </div>
      <div class="form-row">
                <div class="form-label"><?php _e('Name Block 3', 'letgo'); ?>*:</div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="homepage-block4" placeholder="Share" value="<?php echo osc_esc_html( osc_get_preference('homepage-block4', 'letgo') ); ?>" > Link: <input type="text" class="xlarge" name="homepage-block3l" value="<?php echo osc_esc_html( osc_get_preference('homepage-block3l', 'letgo') ); ?>" >
                </div>
            </div>
      <div class="form-row">
                <div class="form-label"><?php _e('Name Block 4', 'letgo'); ?>*:</div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="homepage-block5" placeholder="Enjoy the money!" value="<?php echo osc_esc_html( osc_get_preference('homepage-block5', 'letgo') ); ?>" > Link: <input type="text" class="xlarge" name="homepage-block6" value="<?php echo osc_esc_html( osc_get_preference('homepage-block6', 'letgo') ); ?>" >
                    <br/><br/>
                    <div class="help-box"></div>
                </div>
            </div>
            
            
            <hr />
      <h2 class="render-title">
  <?php _e('Listings on HomePage by custom category', 'letgo'); ?>
</h2>
    <div class="form-row">
        <div class="form-controls">
            <p><?php _e('In this section you can configure to display listings on home page by custom category.', 'letgo'); ?><br/>Please note that <strong>category name</strong> need to be in <strong>english</strong> and is required to be a <strong>slug</strong> format, for example, in the box: <strong>"Category 1"</strong> you need to write your desired category name, for example: <strong>"for-sale"</strong>, in second box for: <strong>"name to show"</strong> you can write: <strong>"For sale"</strong>, or translated in your desired language.</p>
        </div>
    </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Category 1', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="slidercatname1" placeholder="for-sale" value="<?php echo osc_esc_html( osc_get_preference('slidercatname1', 'letgo') ); ?>" > Name to show: <input type="text" class="xlarge" name="slidercatname1m" placeholder="For sale" value="<?php echo osc_esc_html( osc_get_preference('slidercatname1m', 'letgo') ); ?>" >
                   
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Category 2', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="slidercatname2" placeholder="real-estate" value="<?php echo osc_esc_html( osc_get_preference('slidercatname2', 'letgo') ); ?>" > Name to show: <input type="text" class="xlarge" name="slidercatname2m" placeholder="Real estate" value="<?php echo osc_esc_html( osc_get_preference('slidercatname2m', 'letgo') ); ?>" >
                </div>
            </div>
            <div class="form-row">
                <div class="form-label"><?php _e('Category 3', 'letgo'); ?></div>
                <div class="form-controls">
                    <input type="text" class="xlarge" name="slidercatname3" placeholder="services" value="<?php echo osc_esc_html( osc_get_preference('slidercatname3', 'letgo') ); ?>" > Name to show: <input type="text" class="xlarge" name="slidercatname3m" placeholder="Services" value="<?php echo osc_esc_html( osc_get_preference('slidercatname3m', 'letgo') ); ?>" >
                </div>
            </div>
    </div>
            
  </fieldset>
  <div class="form-actions">
    <input type="submit" value="<?php echo osc_esc_html(__('Save changes', 'letgo')); ?>" class="btn btn-submit">
  </div>
</form>