$(document).ready(function(){
    $(".opt_delete_account a").click(function(){
        $("#dialog-delete-account").dialog('open');
    });

    $("#dialog-delete-account").dialog({
        autoOpen: false,
        modal: true,
        buttons: [
            {
                text: hungary_duna.langs.delete,
                click: function() {
                    window.location = hungary_duna.base_url + '?page=user&action=delete&id=' + hungary_duna.user.id  + '&secret=' + hungary_duna.user.secret;
                }
            },
            {
                text: hungary_duna.langs.cancel,
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    });
});
