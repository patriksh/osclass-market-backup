<div id="sidebar">
    <div class="user-sidebar">
    <?php echo osc_private_user_menu() ; ?>
    </div>
</div>