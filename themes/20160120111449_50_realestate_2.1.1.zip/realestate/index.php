<?php

/*
Theme Name: Osclass realestate Theme
Theme URI: http://osclass.org
Description: This is the Osclass realestate theme
Version: 2.1.1
Author:Osclass team
Author URI: http://osclass.org
Widgets: header,footer
Theme update URI: realestate
*/

    function realestate_theme_info() {
        return array(
             'name'        => 'Osclass realestate Theme'
            ,'version'     => '2.1.1'
            ,'description' => 'This is the Osclass realestate theme'
            ,'author_name' => 'Osclass Team'
            ,'author_url'  => 'http://osclass.org'
            ,'locations'   => array('header', 'footer')
        );
    }

?>
