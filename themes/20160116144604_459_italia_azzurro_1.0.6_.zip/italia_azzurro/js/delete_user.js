$(document).ready(function(){
    $(".opt_delete_account a").click(function(){
        $("#dialog-delete-account").dialog('open');
    });

    $("#dialog-delete-account").dialog({
        autoOpen: false,
        modal: true,
        buttons: [
            {
                text: italia_azzurro.langs.delete,
                click: function() {
                    window.location = italia_azzurro.base_url + '?page=user&action=delete&id=' + italia_azzurro.user.id  + '&secret=' + italia_azzurro.user.secret;
                }
            },
            {
                text: italia_azzurro.langs.cancel,
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    });
});
