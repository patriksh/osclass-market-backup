<?php
/*
Theme Name: Osclass brasil theme
Theme URI: http://www.osclass.org/
Description: This is the Osclass brasil theme
Version: 3.1.0
Author: OSClass team
Author URI: http://www.osclass.org/
Widgets: header,footer
Theme update URI: brasil
*/

    function brasil_theme_info() {
        return array(
            'name'        => 'Osclass brasil theme',
            'version'     => '3.1.0',
            'description' => 'This is the Osclass brasil theme',
            'author_name' => 'Osclass team',
            'author_url'  => 'http://osclass.org',
            'locations'   => array('header', 'footer')
        );
    }

?>
