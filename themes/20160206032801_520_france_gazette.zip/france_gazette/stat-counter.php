<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=9391370; 
var sc_invisible=1; 
var sc_security="7c320e72"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="shopify
analytics" href="http://statcounter.com/shopify/"
target="_blank"><img class="statcounter"
src="http://c.statcounter.com/9391370/0/7c320e72/1/"
alt="shopify analytics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
