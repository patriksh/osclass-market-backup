$(document).ready(function(){
    $(".opt_delete_account a").click(function(){
        $("#dialog-delete-account").dialog('open');
    });

    $("#dialog-delete-account").dialog({
        autoOpen: false,
        modal: true,
        buttons: [
            {
                text: france_gazette.langs.delete,
                click: function() {
                    window.location = france_gazette.base_url + '?page=user&action=delete&id=' + france_gazette.user.id  + '&secret=' + france_gazette.user.secret;
                }
            },
            {
                text: france_gazette.langs.cancel,
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    });
});
