<?php if ((!defined('ABS_PATH'))) exit('ABS_PATH is not loaded. Direct access is not allowed.'); ?>
<?php if (!OC_ADMIN) exit('User access is not allowed.'); ?>
<div id="fb-root"></div>
<script>(function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id))
            return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId=651333508343077";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>
<style type="text/css" media="screen">
    .command { background-color: white; color: #2E2E2E; border: 1px solid black; padding: 8px; }
    .theme-files { min-width: 500px; }
</style>
<style>
    .rights {display: block;
             background: #EBF6F6;
             padding: 10px;
             border: 1px solid #D6FFFF;
             line-height:20px;
             margin-bottom:10px;
    }
    .author {
        display: inline-block;
        background: #EBF6F6;
        border: 1px solid #D6FFFF;
        width:100%;
        margin-top:10px;
    }
    .rights .like{
        width:320px;
        display:inline-block;
        float:left;
        line-height:30px;
        margin-left:15px;
    }
    .rights .donate{   
        display:inline-block;
        line-height:30px;
        margin-left:15px;
    }
</style>
<div class="rights">
    <a style="float:left;" href="http://theme.calinbehtuk.ro" title="Premium theme and plugins for oslcass">
        <img src="<?php echo osc_base_url() ?>oc-content/themes/romania/admin/images/calinbehtuk.png" title="premium theme and plugins for oslcass"/></a>
    <span style="float:right;line-height:40px;font-weight:700;"><?php _e('Follow:', 'telephone'); ?><a target="blank" style="text-decoration:none;" href="https://www.facebook.com/Calinbehtuk-themes-1086739291344584/"> <img style="margin-bottom:-5px;margin-left:5px;" src="<?php echo osc_base_url() ?>oc-content/plugins/telephone/images/facebook.png" title="facebook"/></a></span>
    <div class="like">
        <div class="fb-like" data-href="https://www.facebook.com/Calinbehtuk-themes-1086739291344584/" data-layout="standard" data-action="like" data-show-faces="false" data-share="false"></div>
    </div>
    <div class="donate">
        <form style="display:block;margin-top:10px;" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="hidden" name="hosted_button_id" value="TL5PLDQHJB3XA">
            <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
            <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
        </form>
    </div>
</div>
<?php romania_content(); ?>
<h2 class="render-title"><?php _e('Header logo', 'romania'); ?></h2>
<?php if (is_writable(WebThemes::newInstance()->getCurrentThemePath() . "images/")) { ?>
    <?php if (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg")) { ?>
        <h3 class="render-title"><?php _e('Preview', 'romania') ?></h3>
        <img border="0" alt="<?php echo osc_esc_html(osc_page_title()); ?>" src="<?php echo osc_current_web_theme_url('images/logo.jpg'); ?>" />
        <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/romania/admin/header.php'); ?>" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action_specific" value="remove" />
            <fieldset>
                <div class="form-horizontal">
                    <div class="form-actions">
                        <input id="button_remove" type="submit" value="<?php echo osc_esc_html(__('Remove logo', 'romania')); ?>" class="btn btn-red">
                    </div>
                </div>
            </fieldset>
        </form>
        </p>
    <?php } else { ?>
        <div class="flashmessage flashmessage-warning flashmessage-inline" style="display: block;">
            <p><?php _e("No logo has been uploaded yet", 'romania'); ?></p>
        </div>
    <?php } ?>
    <h2 class="render-title separate-top"><?php _e('Upload logo', 'romania') ?></h2>
    <p>
        <?php _e('The preferred size of the logo is 600x100.', 'romania'); ?>
        <?php if (file_exists(WebThemes::newInstance()->getCurrentThemePath() . "images/logo.jpg")) { ?>
            <?php _e('<strong>Note:</strong> Uploading another logo will overwrite the current logo.', 'romania'); ?>
        <?php } ?>
    </p>
    <form action="<?php echo osc_admin_render_theme_url('oc-content/themes/romania/admin/header.php'); ?>" method="post" enctype="multipart/form-data">
        <input type="hidden" name="action_specific" value="upload_logo" />
        <fieldset>
            <div class="form-horizontal">
                <div class="form-row">
                    <div class="form-label"><?php _e('Logo image (png,gif,jpg)', 'romania'); ?></div>
                    <div class="form-controls">
                        <input type="file" name="logo" id="package" />
                    </div>
                </div>
                <div class="form-actions">
                    <input id="button_save" type="submit" value="<?php echo osc_esc_html(__('Upload', 'romania')); ?>" class="btn btn-submit">
                </div>
            </div>
        </fieldset>
    </form>
<?php } else { ?>
    <div class="flashmessage flashmessage-error" style="display: block;">
        <p>
            <?php
            $msg = sprintf(__('The images folder <strong>%s</strong> is not writable on your server', 'romania'), WebThemes::newInstance()->getCurrentThemePath() . "images/") . ", ";
            $msg .= __("OSClass can't upload the logo image from the administration panel.", 'romania') . ' ';
            $msg .= __("Please make the aforementioned image folder writable.", 'romania') . ' ';
            echo $msg;
            ?>
        </p>
        <p>
            <?php _e('To make a directory writable under UNIX execute this command from the shell:', 'romania'); ?>
        </p>
        <p class="command">
            chmod a+w <?php echo WebThemes::newInstance()->getCurrentThemePath() . "images/"; ?>
        </p>
    </div>
<?php } ?>