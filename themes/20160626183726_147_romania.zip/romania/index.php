<?php
/*
Theme Name: Osclass romania theme
Theme URI: http://www.calinbehtuk.blogspot.ro
Description: This is the Osclass romania theme
Version: 1.1.1
Author: Puiu Calin
Author URI: http://www.osclass.org/
Widgets: header,footer
Theme update URI: romania
*/

    function romania_theme_info() {
        return array(
            'name'        => 'Osclass romania theme',
            'version'     => '1.1.1',
            'description' => 'This is the Osclass romania theme',
            'author_name' => 'Puiu Calin',
            'author_url'  => 'http://calinbehtuk.blogspot.ro',
            'locations'   => array('header', 'footer')
        );
    }

?>
