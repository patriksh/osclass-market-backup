<?php
    /*
     *      Osclass – software for creating and publishing online classified
     *                           advertising platforms
     *
     *                        Copyright (C) 2014 OSCLASS
     *
     *       This program is free software: you can redistribute it and/or
     *     modify it under the terms of the GNU Affero General Public License
     *     as published by the Free Software Foundation, either version 3 of
     *            the License, or (at your option) any later version.
     *
     *     This program is distributed in the hope that it will be useful, but
     *         WITHOUT ANY WARRANTY; without even the implied warranty of
     *        MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *             GNU Affero General Public License for more details.
     *
     *      You should have received a copy of the GNU Affero General Public
     * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
     */

    // meta tag robots
    osc_add_hook('header','sakela_follow_construct');

    $address = '';
    if(osc_user_address()!='') {
        if(osc_user_city_area()!='') {
            $address = osc_user_address().", ".osc_user_city_area();
        } else {
            $address = osc_user_address();
        }
    } else {
        $address = osc_user_city_area();
    }
    $location_array = array();
    if(trim(osc_user_city()." ".osc_user_zip())!='') {
        $location_array[] = trim(osc_user_city()." ".osc_user_zip());
    }
    if(osc_user_region()!='') {
        $location_array[] = osc_user_region();
    }
    if(osc_user_country()!='') {
        $location_array[] = osc_user_country();
    }
    $location = implode(", ", $location_array);
    unset($location_array);

    osc_enqueue_script('jquery-validate');

    sakela_add_body_class('user-public-profile');
    osc_add_hook('after-main','sidebar');

    osc_current_web_theme_path('header.php');
?>
<div id="user-public-profile">
   <div id="item-content">
        <div class="description-header">
            <div class="user_card row">
                <div class="user_card_image">
                    <img src="http://www.gravatar.com/avatar/<?php echo md5( strtolower( trim( osc_user_email() ) ) ); ?>?s=120&d=<?php echo osc_current_web_theme_url('images/user_default.gif') ; ?>" />
                </div>    
                <ul id="user_data" class="col-sm-7">
                    <li class="name"><?php echo osc_user_name(); ?></li>
                    <?php if( osc_user_website() !== '' ) { ?>
                    <li class="website"><a href="<?php echo osc_user_website(); ?>"><?php echo osc_user_website(); ?></a></li>
                    <?php } ?>
                    <?php if( $address !== '' ) { ?>
                    <li class="adress"><?php printf(__('<strong>Address:</strong> %1$s'), $address); ?></li>
                    <?php } ?>
                    <?php if( $location !== '' ) { ?>
                    <li class="location"><?php printf(__('<strong>Location:</strong> %1$s'), $location); ?></li>
                    <?php } ?>
                </ul>
                <?php if ( osc_logged_user_id() != osc_user_id() ) { ?>
                    <div class="col-sm-3 user_contact_modal">
                        <?php osc_current_web_theme_path('user-public-sidebar.php'); ?>
                    </div>    
                <?php } ?> 
            </div>
                <?php if( osc_user_info() !== '' ) { ?>
                <div class="user-description">
                    <h2><?php _e('User Description', 'sakela'); ?></h2>
                    <?php } ?>
                    <?php echo nl2br(osc_user_info()); ?>
                </div>
        </div>    

    <?php if( osc_count_items() > 0 ) { ?>
    <div class="similar_ads">
        <h1 id="list-heading-one"><?php _e('User listings', 'sakela'); ?></h1>
        <?php osc_current_web_theme_path('loop.php'); ?>
        <div class="paginate"><?php echo osc_pagination_items(); ?></div>
        <div class="clear"></div>
    </div>
    <?php } ?>
  </div>   
</div>
<?php osc_current_web_theme_path('footer.php') ; ?>