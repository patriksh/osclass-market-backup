$(document).ready(function(){
    $(".opt_delete_account a").click(function(){
        $("#dialog-delete-account").dialog('open');
    });

    $("#dialog-delete-account").dialog({
        autoOpen: false,
        modal: true,
        buttons: [
            {
                text: india_classifieds.langs.delete,
                click: function() {
                    window.location = india_classifieds.base_url + '?page=user&action=delete&id=' + india_classifieds.user.id  + '&secret=' + india_classifieds.user.secret;
                }
            },
            {
                text: india_classifieds.langs.cancel,
                click: function() {
                    $(this).dialog("close");
                }
            }
        ]
    });
});
