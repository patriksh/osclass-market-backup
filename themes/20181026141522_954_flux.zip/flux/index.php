<?php
    

/*
Theme Name: Flux Theme
Theme URI: https://www.osclasswizards.com/products/themes/
Description: Flux theme
Version: 1.0.0
Author: Osclasswizards
Author URI: http://www.osclasswizards.com/
Widgets:  header, footer
Theme update URI: 
*/

    function flux_theme_info() {
        return array(
             'name'        => 'flux'
            ,'version'     => '1.0.0'
            ,'description' => 'Flux themes'
            ,'author_name' => 'Osclasswizards'
            ,'author_url'  => 'http://www.osclasswizards.com/'
            ,'locations'   => array()
        );
    }

?>