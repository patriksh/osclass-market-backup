<?php
    

    flux_add_body_class('custom');
    osc_current_web_theme_path('header.php') ;
?>
<?php osc_render_file(); ?>
<?php osc_current_web_theme_path('footer.php') ; ?>