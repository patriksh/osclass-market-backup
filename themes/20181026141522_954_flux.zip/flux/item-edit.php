<?php
    

    // meta tag robots
    osc_add_hook('header','flux_nofollow_construct');

    osc_current_web_theme_path('item-post.php');
?>