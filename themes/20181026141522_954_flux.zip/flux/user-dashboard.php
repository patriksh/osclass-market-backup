<?php
    

    // meta tag robots
    osc_current_web_theme_path('user-items.php') ;
?>