<?php
/*
Theme Name: WizEstate
Theme URI: http://www.osclasswizards.com
Description: Free Real Estate Theme for Osclass based on mobile friendly, responsive Bootstrap framework with powerful Theme Settings Options.
Version: 1.0.2
Author: OsclassWizards
Author URI: http://www.osclasswizards.com
Widgets:  header, footer
Theme update URI: wizestate
*/

    function wizestate_theme_info() {
        return array(
             'name'        => OSCLASSWIZARDS_THEME_FOLDER
            ,'version'     => '1.0.2'
            ,'description' => 'Free Real Estate Theme for Osclass based on mobile friendly, responsive Bootstrap framework with powerful Theme Settings Options.'
            ,'author_name' => 'OsclassWizards'
            ,'author_url'  => 'http://www.osclasswizards.com'
            ,'locations'   => array()
        );
    }

?>