
<div class="col-sm-4 col-md-3">
  <div id="sidebar"> <?php echo osc_private_user_menu( get_user_menu() ); ?> </div>
  <div id="dialog-delete-account" title="<?php echo osc_esc_html(__('Delete account', OSCLASSWIZARDS_THEME_FOLDER)); ?>">
    <?php _e('Are you sure you want to delete your account?', OSCLASSWIZARDS_THEME_FOLDER); ?>
  </div>
</div>
