<?php
    // meta tag robots
    osc_add_hook('header','osclasswizards_nofollow_construct');

    osc_current_web_theme_path('item-post.php');
?>