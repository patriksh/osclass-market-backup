<?php
/*
Theme Name: Osclass Bigio Theme
Theme URI: http://www.osclasspremium.themehelp.us/
Description: This is the Osclass Bigio theme
Version: 1.0
Author: Bigiolush
Author URI: http://www.osclasspremium.themehelp.us/
Widgets: header,footer
Theme update URI: bigio
*/

    function modern_theme_info() {
        return array(
            'name'        => 'Osclass Bigio Theme',
            'version'     => '1.0',
            'description' => 'This is the Osclass Bigio theme',
            'author_name' => 'Bigiolush',
            'author_url'  => 'http://osclasspremium.themehelp.us',
            'locations'   => array('header', 'footer')
        );
    }

?>
